<?php
/**
 * Plugin Name: SEO Room
 * Plugin URI: https://theseoroom.com.au
 * Description: SEO tools + complementary speed optimizations. Works alongside BerqWP/cloud cache. Features: JSON-LD schema, 404 monitor, redirects, broken link checker, CLS prevention (image dims), font-display swap, preconnect/prefetch, LCP preload, jQuery delay, unused CSS removal. Dashboard connector for SEO Room v5.
 * Version: 8.4.7
 * Author: The SEO Room
 * Author URI: https://theseoroom.com.au
 * License: GPL v2 or later
 * Text Domain: seoroom
 */

if (!defined('ABSPATH')) exit;

define('SEOROOM_VERSION', '8.4.7');
define('SEOROOM_PATH', plugin_dir_path(__FILE__));
define('SEOROOM_URL', plugin_dir_url(__FILE__));

// ============ DEFAULT OPTIONS ============
function sropt_defaults() {
    return array(
        // === Speed: NON-OVERLAPPING with BerqWP (keep ON) ===
        'enable_image_dims'    => true,   // Add width/height to prevent CLS
        'enable_font_swap'     => true,   // font-display: swap
        'enable_preconnect'    => true,   // Preconnect hints
        'enable_dns_prefetch'  => true,   // DNS prefetch
        'enable_lcp_preload'   => true,   // Preload LCP image/resource
        'enable_js_delay'      => true,   // Delay jQuery until interaction
        'enable_unused_css'    => false,  // Remove unused CSS (heavy — enable per project)
        'unused_css_safelist'  => '',
        'exclude_css'          => '',
        'exclude_js'           => '',
        'safe_mode'            => false,

        // === Speed: OVERLAPPING with BerqWP (OFF by default) ===
        'enable_lazy_load'     => false,  // BerqWP handles this
        'enable_css_minify'    => false,  // BerqWP handles this
        'enable_critical_css'  => false,  // BerqWP handles this
        'enable_css_defer'     => false,  // BerqWP handles this
        'enable_js_defer'      => false,  // BerqWP handles this
        'enable_js_minify'     => false,  // BerqWP handles this
        'enable_gzip'          => false,  // BerqWP / Cloudflare handles this
        'enable_cache_headers' => false,  // BerqWP / Cloudflare handles this
        'enable_image_compress' => false, // BerqWP handles this
        'image_compress_quality' => 82,
        'enable_page_cache'    => false,  // BerqWP handles this
        'page_cache_ttl'       => 86400,
        'cache_exclude_urls'   => '',
        'cache_ttl'            => 604800,
        'enable_webp'          => false,  // BerqWP handles this
        'webp_quality'         => 80,

        // === SEO Tools (always ON) ===
        'enable_404_monitor'   => true,
        'enable_redirects'     => true,
        'enable_link_checker'  => false,  // Manual trigger only
        'enable_schema'        => true,

        // === Dashboard Connection ===
        'dashboard_url'        => 'https://seo-room-v5-production.up.railway.app',
        'project_id'           => '',
        'connection_code'      => '',
        'license_key'          => '',
    );
}

function sropt_get_options() {
    $defaults = sropt_defaults();
    $options = get_option('sropt_options', array());
    return wp_parse_args($options, $defaults);
}

// ============ ACTIVATION / DEACTIVATION ============
register_activation_hook(__FILE__, 'sropt_activate');
function sropt_activate() {
    $options = sropt_get_options();
    update_option('sropt_options', $options);

    // Clear caches on upgrade so new logic takes effect
    $prev_ver = get_option('sropt_version', '0');
    if (version_compare($prev_ver, SEOROOM_VERSION, '<')) {
        foreach (array('critical', 'purged') as $_subdir) {
            $_dir = WP_CONTENT_DIR . '/cache/seoroom/' . $_subdir . '/';
            if (is_dir($_dir)) {
                $files = glob($_dir . '*');
                if ($files) foreach ($files as $f) @unlink($f);
            }
        }
        update_option('sropt_version', SEOROOM_VERSION);
    }

    $dirs = array(
        WP_CONTENT_DIR . '/cache/seoroom/',
        WP_CONTENT_DIR . '/cache/seoroom/pages/',
        WP_CONTENT_DIR . '/cache/seoroom/webp/',
        WP_CONTENT_DIR . '/cache/seoroom/critical/',
        WP_CONTENT_DIR . '/cache/seoroom/purged/',
    );
    foreach ($dirs as $dir) {
        if (!file_exists($dir)) wp_mkdir_p($dir);
    }

    // Clean up old md5-based page cache files (pre-6.2 format)
    $old_pages_dir = WP_CONTENT_DIR . '/cache/seoroom/pages/';
    if (is_dir($old_pages_dir)) {
        foreach (glob($old_pages_dir . '*.html') as $old_cache) @unlink($old_cache);
        @unlink($old_pages_dir . 'config.json');
    }
    // Remove old advanced-cache.php drop-in if ours
    $dropin = WP_CONTENT_DIR . '/advanced-cache.php';
    if (file_exists($dropin) && strpos(file_get_contents($dropin), 'SEO Room') !== false) {
        @unlink($dropin);
    }

    // Create DB tables for 404 monitor, redirects, link checker
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}seoroom_404s (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        url VARCHAR(2048) NOT NULL,
        url_hash CHAR(32) NOT NULL,
        referrer VARCHAR(2048) DEFAULT '',
        user_agent VARCHAR(512) DEFAULT '',
        hit_count INT UNSIGNED DEFAULT 1,
        first_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY url_hash (url_hash),
        KEY last_seen (last_seen)
    ) $charset");

    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}seoroom_redirects (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        source_url VARCHAR(2048) NOT NULL,
        source_hash CHAR(32) NOT NULL,
        target_url VARCHAR(2048) NOT NULL,
        redirect_type SMALLINT DEFAULT 301,
        hit_count INT UNSIGNED DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY source_hash (source_hash)
    ) $charset");

    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}seoroom_broken_links (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        source_url VARCHAR(2048) NOT NULL,
        source_post_id BIGINT UNSIGNED DEFAULT 0,
        target_url VARCHAR(2048) NOT NULL,
        status_code SMALLINT DEFAULT 0,
        anchor_text VARCHAR(512) DEFAULT '',
        link_type VARCHAR(20) DEFAULT 'internal',
        scanned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        KEY source_post (source_post_id),
        KEY status_code (status_code)
    ) $charset");

    flush_rewrite_rules();
}

register_deactivation_hook(__FILE__, 'sropt_deactivate');
function sropt_deactivate() {
    $dirs = array(
        WP_CONTENT_DIR . '/cache/seoroom/critical/',
        WP_CONTENT_DIR . '/cache/seoroom/pages/',
        WP_CONTENT_DIR . '/cache/seoroom/webp/',
        WP_CONTENT_DIR . '/cache/seoroom/',
    );
    foreach ($dirs as $dir) {
        if (file_exists($dir)) {
            $iter = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ($iter as $item) {
                if ($item->isFile()) @unlink($item->getPathname());
                elseif ($item->isDir()) @rmdir($item->getPathname());
            }
            @rmdir($dir);
        }
    }
    sropt_remove_htaccess_rules();
    flush_rewrite_rules();
}

// ============ PLUGIN ACTION LINKS (Settings link on Plugins page) ============
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links) {
    $settings_link = '<a href="' . admin_url('options-general.php?page=seoroom') . '">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
});

// ============ ADMIN MENU & SETTINGS PAGE ============
add_action('admin_menu', 'sropt_admin_menu');
function sropt_admin_menu() {
    add_options_page('SEO Room', 'SEO Room', 'manage_options', 'seoroom', 'sropt_settings_page');
}

add_action('admin_init', 'sropt_register_settings');
function sropt_register_settings() {
    register_setting('sropt_group', 'sropt_options', 'sropt_sanitize');
}

function sropt_sanitize($input) {
    $defaults = sropt_defaults();
    $sanitized = array();
    foreach ($defaults as $key => $default) {
        if (is_bool($default)) {
            $sanitized[$key] = !empty($input[$key]);
        } elseif (is_int($default)) {
            $sanitized[$key] = intval($input[$key] ?? $default);
        } else {
            $sanitized[$key] = sanitize_text_field($input[$key] ?? $default);
        }
    }

    if ($sanitized['enable_gzip'] || $sanitized['enable_cache_headers']) {
        sropt_write_htaccess_rules($sanitized);
    } else {
        sropt_remove_htaccess_rules();
    }

    // Clear all caches on settings save
    sropt_clear_all_caches();

    return $sanitized;
}

function sropt_clear_all_caches() {
    $cache_dir = WP_CONTENT_DIR . '/cache/seoroom/';
    if (file_exists($cache_dir)) {
        array_map('unlink', array_filter(glob("$cache_dir*.css"), 'is_file'));
        array_map('unlink', array_filter(glob("$cache_dir*.js"), 'is_file'));
    }
    $page_dir = WP_CONTENT_DIR . '/cache/seoroom/pages/';
    if (file_exists($page_dir)) {
        array_map('unlink', array_filter(glob("$page_dir*.html"), 'is_file'));
    }
    $critical_dir = WP_CONTENT_DIR . '/cache/seoroom/critical/';
    if (file_exists($critical_dir)) {
        array_map('unlink', array_filter(glob("$critical_dir*.css"), 'is_file'));
    }
    $purged_dir = WP_CONTENT_DIR . '/cache/seoroom/purged/';
    if (file_exists($purged_dir)) {
        array_map('unlink', array_filter(glob("$purged_dir*.css"), 'is_file'));
    }
}

function sropt_settings_page() {
    $options = sropt_get_options();
    ?>
    <div class="wrap">
        <h1>SEO Room</h1>
        <p style="color:#666;">All-in-one SEO optimization. All changes are non-destructive — deactivate to instantly revert.</p>

        <form method="post" action="options.php">
            <?php settings_fields('sropt_group'); ?>

            <?php if ($options['safe_mode']): ?>
            <div style="background:#fff3cd;border:1px solid #ffc107;padding:12px 16px;border-radius:6px;margin-bottom:20px;">
                <strong>⚡ Safe Mode is ON</strong> — Only the safest optimizations are active (lazy load, font swap, preconnect, DNS prefetch, schema).
            </div>
            <?php endif; ?>

            <table class="form-table">
                <!-- DASHBOARD CONNECTION -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">🔗 Dashboard Connection</h2></th></tr>
                <tr>
                    <th>Project ID</th>
                    <td>
                        <input type="number" name="sropt_options[project_id]" id="sropt_project_id" value="<?php echo esc_attr($options['project_id']); ?>" min="1" step="1" style="width:100px;" />
                        <p class="description">Your project ID from SEO Room Dashboard → Settings → Projects.</p>
                    </td>
                </tr>
                <tr>
                    <th>Dashboard URL</th>
                    <td>
                        <input type="url" name="sropt_options[dashboard_url]" id="sropt_dashboard_url" value="<?php echo esc_attr($options['dashboard_url']); ?>" class="regular-text" />
                        <p class="description">Your SEO Room Dashboard URL.</p>
                    </td>
                </tr>
                <tr>
                    <th>Connection Code</th>
                    <td>
                        <input type="text" name="sropt_options[connection_code]" id="sropt_connection_code" value="<?php echo esc_attr($options['connection_code']); ?>" class="regular-text" placeholder="Paste code from Dashboard → Project Settings" />
                        <p class="description">Generated in SEO Room Dashboard → Project Settings → Plugin Connection Code.</p>
                    </td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <span id="sropt_connection_status">
                            <?php if ($options['project_id'] && $options['connection_code']): ?>
                                <span style="color:#22c55e;font-weight:600;">● Connected</span>
                                <span style="color:#666;margin-left:8px;">Project #<?php echo esc_html($options['project_id']); ?></span>
                            <?php elseif ($options['project_id']): ?>
                                <span style="color:#f59e0b;font-weight:600;">● Missing connection code</span>
                            <?php else: ?>
                                <span style="color:#f59e0b;font-weight:600;">● Not configured</span>
                            <?php endif; ?>
                        </span>
                        <br><br>
                        <button type="button" id="sropt_test_connection" class="button button-secondary">Test Connection</button>
                        <button type="button" id="sropt_push_now" class="button button-primary" style="margin-left:8px;">Push Data Now</button>
                        <span id="sropt_test_result" style="margin-left:10px;"></span>
                        <?php
                        $last_push = get_option('sropt_last_push');
                        if ($last_push): ?>
                            <br><br>
                            <span style="color:#666;font-size:12px;">
                                Last push: <?php echo esc_html($last_push['time'] ?? '—'); ?> —
                                <?php if (($last_push['status'] ?? '') === 'ok'): ?>
                                    <span style="color:#22c55e;">✓ <?php echo intval($last_push['pages'] ?? 0); ?> pages sent</span>
                                <?php else: ?>
                                    <span style="color:#ef4444;">✗ <?php echo esc_html($last_push['error'] ?? 'Unknown error'); ?></span>
                                <?php endif; ?>
                            </span>
                        <?php endif; ?>
                        <script>
                        document.getElementById('sropt_test_connection').addEventListener('click', function() {
                            var btn = this;
                            var result = document.getElementById('sropt_test_result');
                            var url = document.getElementById('sropt_dashboard_url').value.replace(/\/$/, '');
                            var pid = document.getElementById('sropt_project_id').value;
                            var code = document.getElementById('sropt_connection_code').value;

                            if (!url || !pid || !code) {
                                result.innerHTML = '<span style="color:#ef4444;">Fill in all fields first.</span>';
                                return;
                            }

                            btn.disabled = true;
                            result.innerHTML = '<span style="color:#666;">Testing...</span>';

                            fetch(url + '/api/projects/' + pid + '/plugin-verify', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ code: code, site_url: '<?php echo esc_url(home_url()); ?>', plugin_version: '<?php echo SEOROOM_VERSION; ?>' })
                            })
                            .then(function(r) { return r.json(); })
                            .then(function(data) {
                                if (data.ok) {
                                    result.innerHTML = '<span style="color:#22c55e;font-weight:600;">✓ Connected to ' + (data.project_name || 'Project #' + pid) + '</span>';
                                    document.getElementById('sropt_connection_status').innerHTML = '<span style="color:#22c55e;font-weight:600;">● Connected</span> <span style="color:#666;margin-left:8px;">' + (data.project_name || 'Project #' + pid) + '</span>';
                                } else {
                                    result.innerHTML = '<span style="color:#ef4444;">✗ ' + (data.error || 'Invalid code or project ID') + '</span>';
                                }
                            })
                            .catch(function(e) {
                                result.innerHTML = '<span style="color:#ef4444;">✗ Could not reach dashboard: ' + e.message + '</span>';
                            })
                            .finally(function() { btn.disabled = false; });
                        });

                        document.getElementById('sropt_push_now').addEventListener('click', function() {
                            var btn = this;
                            var result = document.getElementById('sropt_test_result');
                            btn.disabled = true;
                            result.innerHTML = '<span style="color:#666;">Pushing page data to dashboard...</span>';

                            fetch('<?php echo esc_url(rest_url('seoroom-opt/v1/push-now')); ?>', {
                                method: 'POST',
                                headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                            })
                            .then(function(r) { return r.json(); })
                            .then(function(data) {
                                if (data.ok) {
                                    var pages = data.result && data.result.pages ? data.result.pages : '?';
                                    result.innerHTML = '<span style="color:#22c55e;font-weight:600;">✓ Pushed ' + pages + ' pages to dashboard</span>';
                                } else {
                                    result.innerHTML = '<span style="color:#ef4444;">✗ ' + (data.error || 'Push failed') + '</span>';
                                }
                            })
                            .catch(function(e) {
                                result.innerHTML = '<span style="color:#ef4444;">✗ Push error: ' + e.message + '</span>';
                            })
                            .finally(function() { btn.disabled = false; });
                        });
                        </script>
                    </td>
                </tr>

                <!-- LICENSE -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">🔑 License</h2></th></tr>
                <tr>
                    <th>License Key</th>
                    <td>
                        <input type="text" name="sropt_options[license_key]" value="<?php echo esc_attr($options['license_key'] ?? ''); ?>" class="regular-text" placeholder="SR-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" />
                        <p class="description">Provided by The SEO Room. Required for management features.</p>
                    </td>
                </tr>
                <tr>
                    <th>License Status</th>
                    <td>
                        <?php
                        $lic_info = get_option('sropt_license_info', array());
                        if (empty($options['license_key'])) {
                            echo '<span style="color:#f59e0b;font-weight:600;">● No license key</span>';
                            echo '<p class="description">Enter your license key above and save to activate.</p>';
                        } elseif (!empty($lic_info['valid'])) {
                            echo '<span style="color:#22c55e;font-weight:600;">● Active</span>';
                            if (!empty($lic_info['project_name'])) echo ' <span style="color:#666;">— ' . esc_html($lic_info['project_name']) . '</span>';
                            if (!empty($lic_info['expires'])) {
                                $exp = date('j M Y', strtotime($lic_info['expires']));
                                $days = $lic_info['days_remaining'] ?? '';
                                echo '<br><span style="color:#666;font-size:12px;">Expires: ' . esc_html($exp);
                                if ($days) echo ' (' . intval($days) . ' days remaining)';
                                echo '</span>';
                            }
                        } else {
                            echo '<span style="color:#ef4444;font-weight:600;">● ' . esc_html($lic_info['reason'] ?? 'Expired') . '</span>';
                            echo '<p class="description" style="color:#ef4444;">Management features disabled. Existing redirects and schema continue working.</p>';
                        }
                        if (!empty($lic_info['checked_at'])) {
                            echo '<br><span style="color:#999;font-size:11px;">Last checked: ' . esc_html($lic_info['checked_at']) . '</span>';
                        }
                        ?>
                        <br><br>
                        <button type="button" id="sropt_check_license" class="button button-secondary">Check License Now</button>
                        <span id="sropt_license_result" style="margin-left:10px;"></span>
                        <script>
                        document.getElementById('sropt_check_license').addEventListener('click', function() {
                            var btn = this;
                            var result = document.getElementById('sropt_license_result');
                            var key = document.querySelector('input[name="sropt_options[license_key]"]').value;
                            if (!key) { result.innerHTML = '<span style="color:#ef4444;">Enter license key first.</span>'; return; }
                            btn.disabled = true;
                            result.innerHTML = '<span style="color:#666;">Checking...</span>';
                            var fd = new FormData();
                            fd.append('action', 'sropt_ajax_check_license');
                            fd.append('nonce', '<?php echo wp_create_nonce("sropt_license_nonce"); ?>');
                            fd.append('license_key', key);
                            fetch(ajaxurl, { method: 'POST', body: fd })
                            .then(function(r) { return r.json(); })
                            .then(function(resp) {
                                var data = resp.data || {};
                                if (resp.success && data.valid) {
                                    var msg = '✓ Active';
                                    if (data.project_name) msg += ' — ' + data.project_name;
                                    if (data.days_remaining) msg += ' (' + data.days_remaining + ' days remaining)';
                                    result.innerHTML = '<span style="color:#22c55e;font-weight:600;">' + msg + '</span>';
                                } else {
                                    result.innerHTML = '<span style="color:#ef4444;font-weight:600;">✗ ' + (data.reason || resp.data || 'Invalid') + '</span>';
                                }
                            })
                            .catch(function(e) { result.innerHTML = '<span style="color:#ef4444;">✗ ' + e.message + '</span>'; })
                            .finally(function() { btn.disabled = false; });
                        });
                        </script>
                    </td>
                </tr>

                <!-- SAFETY -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">🛡️ Safety</h2></th></tr>
                <tr>
                    <th>Safe Mode</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[safe_mode]" value="1" <?php checked($options['safe_mode']); ?> /> Enable safe mode (only non-breaking optimizations)</label>
                        <p class="description">When enabled, CSS/JS minification, deferral, and critical CSS are disabled. Schema, lazy load, fonts, and preconnect remain active.</p>
                    </td>
                </tr>

                <!-- SCHEMA -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">📋 Schema (JSON-LD)</h2></th></tr>
                <tr>
                    <th>Schema Injection</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[enable_schema]" value="1" <?php checked($options['enable_schema']); ?> /> Output JSON-LD schema from <code>_seoroom_schema</code> post meta in &lt;head&gt;</label>
                        <p class="description">Works with any page builder (Elementor, Gutenberg, Classic). Schema is written by SEO Room Dashboard via REST API.</p>
                    </td>
                </tr>

                <!-- IMAGES -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">🖼️ Images</h2></th></tr>
                <tr>
                    <th>Lazy Loading</th>
                    <td><label><input type="checkbox" name="sropt_options[enable_lazy_load]" value="1" <?php checked($options['enable_lazy_load']); ?> /> Add loading="lazy" to images and iframes below the fold</label></td>
                </tr>
                <tr>
                    <th>Image Dimensions</th>
                    <td><label><input type="checkbox" name="sropt_options[enable_image_dims]" value="1" <?php checked($options['enable_image_dims']); ?> /> Add missing width/height attributes to prevent CLS</label></td>
                </tr>
                <tr>
                    <th>Image Compression</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[enable_image_compress]" value="1" <?php checked($options['enable_image_compress']); ?> /> Compress images on upload (lossless EXIF strip + lossy quality reduction)</label>
                        <p class="description">Compresses JPEG/PNG on upload. Original quality preserved in WordPress revision. Works alongside WebP conversion.</p>
                    </td>
                </tr>
                <tr>
                    <th>JPEG Quality</th>
                    <td>
                        <input type="number" name="sropt_options[image_compress_quality]" value="<?php echo esc_attr($options['image_compress_quality']); ?>" min="60" max="95" step="1" style="width:80px;" />
                        <p class="description">JPEG compression quality (82 recommended). Lower = smaller files, less quality. PNG uses lossless optimization.</p>
                    </td>
                </tr>
                <tr>
                    <th>LCP Image Preload</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[enable_lcp_preload]" value="1" <?php checked($options['enable_lcp_preload']); ?> /> Auto-detect and preload the largest contentful paint image</label>
                        <p class="description">Adds &lt;link rel="preload"&gt; for the hero/banner image. Reduces LCP time by 200-500ms.</p>
                    </td>
                </tr>

                <!-- CRITICAL CSS -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">⚡ Critical CSS</h2></th></tr>
                <tr>
                    <th>Critical CSS Inlining</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[enable_critical_css]" value="1" <?php checked($options['enable_critical_css']); ?> /> Extract and inline above-the-fold CSS, defer the rest</label>
                        <p class="description">Generates critical CSS per page, inlines it in &lt;head&gt;, and safely defers all other stylesheets. Eliminates render-blocking CSS. <strong>Biggest single performance improvement (10-15 points).</strong></p>
                    </td>
                </tr>

                <!-- UNUSED CSS REMOVAL -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">🧹 Unused CSS Removal</h2></th></tr>
                <tr>
                    <th>Remove Unused CSS</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[enable_unused_css]" value="1" <?php checked($options['enable_unused_css']); ?> /> Parse HTML and remove CSS rules that don't match any element on the page</label>
                        <p class="description">Analyzes each page's HTML elements, classes, and IDs, then strips CSS selectors that aren't used. Cached per page. <strong>Biggest PageSpeed win — typically 15-20 point improvement on mobile.</strong></p>
                    </td>
                </tr>
                <tr>
                    <th>Safelist Classes</th>
                    <td>
                        <input type="text" name="sropt_options[unused_css_safelist]" value="<?php echo esc_attr($options['unused_css_safelist']); ?>" class="regular-text" />
                        <p class="description">Comma-separated class prefixes/patterns to never remove (e.g., <code>swiper-,slick-,popup-,modal-,menu-item</code>). JS-toggled classes that don't exist in initial HTML.</p>
                    </td>
                </tr>

                <!-- CSS -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">📄 CSS</h2></th></tr>
                <tr>
                    <th>Minify CSS</th>
                    <td><label><input type="checkbox" name="sropt_options[enable_css_minify]" value="1" <?php checked($options['enable_css_minify']); ?> /> Minify CSS output (removes comments and whitespace)</label></td>
                </tr>
                <tr>
                    <th>Defer Non-Critical CSS</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[enable_css_defer]" value="1" <?php checked($options['enable_css_defer']); ?> /> Load non-critical CSS asynchronously (legacy — use Critical CSS instead)</label>
                        <p class="description" style="color:#d63384;">⚠️ Only needed if Critical CSS is off. Can cause FOUC without critical CSS inlining.</p>
                    </td>
                </tr>
                <tr>
                    <th>Exclude CSS</th>
                    <td>
                        <input type="text" name="sropt_options[exclude_css]" value="<?php echo esc_attr($options['exclude_css']); ?>" class="regular-text" />
                        <p class="description">Comma-separated CSS handles or filenames to exclude from deferral (e.g., <code>elementor-frontend,style</code>)</p>
                    </td>
                </tr>

                <!-- JS -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">⚡ JavaScript</h2></th></tr>
                <tr>
                    <th>Defer JS</th>
                    <td><label><input type="checkbox" name="sropt_options[enable_js_defer]" value="1" <?php checked($options['enable_js_defer']); ?> /> Add defer attribute to non-critical scripts</label></td>
                </tr>
                <tr>
                    <th>Delay JS Until Interaction</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[enable_js_delay]" value="1" <?php checked($options['enable_js_delay']); ?> /> Don't execute JavaScript until user interacts (scroll, click, touch)</label>
                        <p class="description"><strong>Biggest TBT improvement.</strong> Scripts load only when the user scrolls, clicks, or touches the page. Reduces Total Blocking Time to near zero. Used by WP Rocket, FlyingPress, etc.</p>
                    </td>
                </tr>
                <tr>
                    <th>Minify JS</th>
                    <td><label><input type="checkbox" name="sropt_options[enable_js_minify]" value="1" <?php checked($options['enable_js_minify']); ?> /> Minify inline JavaScript (removes comments and whitespace)</label></td>
                </tr>
                <tr>
                    <th>Exclude JS</th>
                    <td>
                        <input type="text" name="sropt_options[exclude_js]" value="<?php echo esc_attr($options['exclude_js']); ?>" class="regular-text" />
                        <p class="description">Comma-separated JS handles or filenames to exclude (e.g., <code>jquery-core,elementor-frontend</code>)</p>
                    </td>
                </tr>

                <!-- PAGE CACHE -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">🚀 Page Cache</h2></th></tr>
                <tr>
                    <th>HTML Page Cache</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[enable_page_cache]" value="1" <?php checked($options['enable_page_cache']); ?> /> Cache full HTML pages to disk for instant delivery</label>
                        <p class="description">Bypasses PHP on cached pages. Huge TTFB improvement. Logged-in users always get fresh pages.</p>
                    </td>
                </tr>
                <tr>
                    <th>Cache Lifetime</th>
                    <td>
                        <select name="sropt_options[page_cache_ttl]">
                            <option value="3600" <?php selected($options['page_cache_ttl'], 3600); ?>>1 Hour</option>
                            <option value="21600" <?php selected($options['page_cache_ttl'], 21600); ?>>6 Hours</option>
                            <option value="43200" <?php selected($options['page_cache_ttl'], 43200); ?>>12 Hours</option>
                            <option value="86400" <?php selected($options['page_cache_ttl'], 86400); ?>>24 Hours (recommended)</option>
                            <option value="604800" <?php selected($options['page_cache_ttl'], 604800); ?>>7 Days</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Exclude URLs</th>
                    <td>
                        <input type="text" name="sropt_options[cache_exclude_urls]" value="<?php echo esc_attr($options['cache_exclude_urls']); ?>" class="regular-text" />
                        <p class="description">Comma-separated URL paths to never cache (e.g., <code>/cart,/checkout,/my-account</code>)</p>
                    </td>
                </tr>

                <!-- WEBP -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">🖼️ WebP Conversion</h2></th></tr>
                <tr>
                    <th>Serve WebP Images</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[enable_webp]" value="1" <?php checked($options['enable_webp']); ?> /> Convert and serve images as WebP (50-70% smaller)</label>
                        <p class="description">Requires GD or Imagick PHP extension. Original images are untouched — WebP copies are cached separately.</p>
                    </td>
                </tr>
                <tr>
                    <th>WebP Quality</th>
                    <td>
                        <input type="number" name="sropt_options[webp_quality]" value="<?php echo esc_attr($options['webp_quality']); ?>" min="50" max="100" step="5" style="width:80px;" />
                        <p class="description">Quality 80 recommended. Lower = smaller files, less quality.</p>
                    </td>
                </tr>

                <!-- SEO TOOLS -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">🔍 SEO Tools</h2></th></tr>
                <tr>
                    <th>404 Monitor</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[enable_404_monitor]" value="1" <?php checked($options['enable_404_monitor']); ?> /> Log 404 errors with URL, referrer, and hit count</label>
                        <p class="description">Tracks every 404 hit. View and manage in SEO Room Dashboard or via REST API.</p>
                    </td>
                </tr>
                <tr>
                    <th>Redirects</th>
                    <td>
                        <label><input type="checkbox" name="sropt_options[enable_redirects]" value="1" <?php checked($options['enable_redirects']); ?> /> Enable 301/302 redirect manager</label>
                        <p class="description">Create redirects from 404s or manually. Fires before WordPress loads the page for zero overhead.</p>
                    </td>
                </tr>
                <tr>
                    <th>404s Logged</th>
                    <td>
                        <?php
                        global $wpdb;
                        $t404 = $wpdb->prefix . 'seoroom_404s';
                        $count_404 = $wpdb->get_var("SELECT COUNT(*) FROM $t404");
                        $count_redirects = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}seoroom_redirects");
                        ?>
                        <span style="font-size:14px;">📊 <strong><?php echo intval($count_404); ?></strong> unique 404 URLs &nbsp;|&nbsp; ↗️ <strong><?php echo intval($count_redirects); ?></strong> active redirects</span>
                        <br><br>
                        <a href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=sropt_clear_404s'), 'sropt_clear_404s'); ?>" class="button button-small">Clear 404 Log</a>
                    </td>
                </tr>

                <!-- SERVER -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">🌐 Server & Caching</h2></th></tr>
                <tr>
                    <th>GZIP Compression</th>
                    <td><label><input type="checkbox" name="sropt_options[enable_gzip]" value="1" <?php checked($options['enable_gzip']); ?> /> Enable GZIP compression via .htaccess</label></td>
                </tr>
                <tr>
                    <th>Browser Cache Headers</th>
                    <td><label><input type="checkbox" name="sropt_options[enable_cache_headers]" value="1" <?php checked($options['enable_cache_headers']); ?> /> Set long-lived cache headers for static assets via .htaccess</label></td>
                </tr>

                <!-- FONTS -->
                <tr><th colspan="2"><h2 style="margin:0;padding:0;font-size:16px;">🔤 Fonts & Preloading</h2></th></tr>
                <tr>
                    <th>Font Display Swap</th>
                    <td><label><input type="checkbox" name="sropt_options[enable_font_swap]" value="1" <?php checked($options['enable_font_swap']); ?> /> Add font-display:swap to prevent invisible text during font loading</label></td>
                </tr>
                <tr>
                    <th>Preconnect</th>
                    <td><label><input type="checkbox" name="sropt_options[enable_preconnect]" value="1" <?php checked($options['enable_preconnect']); ?> /> Auto-detect and preconnect to external domains</label></td>
                </tr>
                <tr>
                    <th>DNS Prefetch</th>
                    <td><label><input type="checkbox" name="sropt_options[enable_dns_prefetch]" value="1" <?php checked($options['enable_dns_prefetch']); ?> /> DNS prefetch for detected external domains</label></td>
                </tr>
            </table>

            <?php submit_button('Save & Apply'); ?>
        </form>

        <div style="margin-top:30px;padding:16px;background:#f8f9fa;border:1px solid #dee2e6;border-radius:6px;">
            <h3 style="margin-top:0;">Quick Actions</h3>
            <p>
                <a href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=sropt_clear_cache'), 'sropt_clear_cache'); ?>" class="button">Clear All Caches</a>
                <a href="https://pagespeed.web.dev/analysis?url=<?php echo urlencode(home_url('/')); ?>" target="_blank" class="button">Test on PageSpeed Insights</a>
            </p>
            <?php
            $page_count = 0;
            $page_iter = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(WP_CONTENT_DIR . '/cache/seoroom/pages/', RecursiveDirectoryIterator::SKIP_DOTS));
            foreach ($page_iter as $f) { if ($f->isFile() && $f->getFilename() === '_index.html') $page_count++; }
            $webp_count = 0;
            $webp_dir = WP_CONTENT_DIR . '/cache/seoroom/webp/';
            if (file_exists($webp_dir)) {
                $iter = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($webp_dir, RecursiveDirectoryIterator::SKIP_DOTS));
                foreach ($iter as $f) { if ($f->isFile() && pathinfo($f, PATHINFO_EXTENSION) === 'webp') $webp_count++; }
            }
            $critical_count = count(glob(WP_CONTENT_DIR . '/cache/seoroom/critical/*.css') ?: array());
            ?>
            <p style="color:#666;font-size:13px;margin-top:8px;">
                📄 Page cache: <strong><?php echo $page_count; ?></strong> cached pages
                &nbsp;|&nbsp;
                🖼️ WebP cache: <strong><?php echo $webp_count; ?></strong> converted images
                &nbsp;|&nbsp;
                ⚡ Critical CSS: <strong><?php echo $critical_count; ?></strong> cached pages
            </p>
        </div>
    </div>
    <?php
}

// Clear cache action
add_action('admin_post_sropt_clear_cache', function() {
    check_admin_referer('sropt_clear_cache');
    sropt_clear_all_caches();
    // Clear WebP cache
    $webp_dir = WP_CONTENT_DIR . '/cache/seoroom/webp/';
    if (file_exists($webp_dir)) {
        $iter = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($webp_dir, RecursiveDirectoryIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($iter as $item) {
            if ($item->isFile()) @unlink($item->getPathname());
        }
    }
    wp_redirect(admin_url('options-general.php?page=seoroom&cleared=1'));
    exit;
});


// Clear 404 log action
add_action('admin_post_sropt_clear_404s', function() {
    check_admin_referer('sropt_clear_404s');
    global $wpdb;
    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}seoroom_404s");
    wp_redirect(admin_url('options-general.php?page=seoroom&cleared_404s=1'));
    exit;
});


// ================================================================
// SCHEMA INJECTION
// Reads _seoroom_schema post meta and outputs JSON-LD in <head>.
// Works with any page builder (Elementor, Gutenberg, Classic).
// ================================================================

// Register _seoroom_schema meta for REST API access (skip if seoroom-helper already registered it)
add_action('init', function() {
    // Auto-clear CSS caches on version upgrade (covers auto-updates)
    $prev_ver = get_option('sropt_version', '0');
    if (version_compare($prev_ver, SEOROOM_VERSION, '<')) {
        foreach (array('critical', 'purged') as $_subdir) {
            $_dir = WP_CONTENT_DIR . '/cache/seoroom/' . $_subdir . '/';
            if (is_dir($_dir)) {
                $files = glob($_dir . '*');
                if ($files) foreach ($files as $f) @unlink($f);
            }
        }
        update_option('sropt_version', SEOROOM_VERSION);
    }

    if (registered_meta_key_exists('post', '_seoroom_schema', 'page')) return;
    foreach (['page', 'post'] as $type) {
        register_post_meta($type, '_seoroom_schema', [
            'show_in_rest'  => true,
            'single'        => true,
            'type'          => 'string',
            'auth_callback' => function() { return current_user_can('edit_posts'); },
        ]);

        // Register Elementor data for REST API access (Design-Safe preview)
        register_post_meta($type, '_elementor_data', [
            'show_in_rest'  => true,
            'single'        => true,
            'type'          => 'string',
            'auth_callback' => function() { return current_user_can('edit_posts'); },
        ]);

        // Register Yoast meta fields for REST API writes (On-Page Fix)
        $yoast_fields = [
            '_yoast_wpseo_title',
            '_yoast_wpseo_metadesc',
            '_yoast_wpseo_focuskw',
            '_yoast_wpseo_canonical',
            '_yoast_wpseo_meta-robots-noindex',
        ];
        foreach ($yoast_fields as $field) {
            register_post_meta($type, $field, [
                'show_in_rest'  => true,
                'single'        => true,
                'type'          => 'string',
                'auth_callback' => function() { return current_user_can('edit_posts'); },
            ]);
        }
    }
}, 20);

// ================================================================
// ELEMENTOR DESIGN-SAFE PREVIEW
// Accepts modified _elementor_data, stores in transient, serves via
// filter on get_post_metadata so Elementor renders the modified version.
// ================================================================

// REST endpoint: receive modified elementor data and create preview token
add_action('rest_api_init', function() {
    register_rest_route('seoroom-opt/v1', '/elementor-preview/(?P<page_id>\d+)', [
        'methods' => 'POST',
        'callback' => 'sropt_elementor_preview_create',
        'permission_callback' => function() { return current_user_can('edit_posts'); },
        'args' => [
            'page_id' => ['type' => 'integer', 'required' => true],
            'elementor_data' => ['type' => 'string', 'required' => true],
        ]
    ]);
});

function sropt_elementor_preview_create($request) {
    $page_id = $request->get_param('page_id');
    $sections_json = $request->get_param('sections'); // New sections to add/modify
    $elementor_data = $request->get_param('elementor_data'); // Full modified elementor data (fallback)

    if (!$page_id) {
        return new WP_Error('missing_data', 'page_id required', ['status' => 400]);
    }

    $page = get_post($page_id);
    if (!$page) return new WP_Error('not_found', 'Page not found', ['status' => 404]);

    // Store preview data in transient
    $token = wp_generate_password(32, false);
    set_transient('seoroom_preview_' . $token, [
        'page_id' => $page_id,
        'sections' => $sections_json ? json_decode($sections_json, true) : null,
        'elementor_data' => $elementor_data,
        'created' => time(),
    ], 600);

    $preview_url = add_query_arg('seoroom_preview', $token, get_permalink($page_id));

    return rest_ensure_response([
        'ok' => true,
        'preview_url' => $preview_url,
        'token' => $token,
        'expires_in' => 600,
    ]);
}

// Elementor Design-Safe Preview: intercept page output and modify rendered HTML
// This works with ALL widgets (standard + third-party) because we modify AFTER rendering
add_action('template_redirect', 'sropt_elementor_preview_intercept', 1);
function sropt_elementor_preview_intercept() {
    if (empty($_GET['seoroom_preview'])) return;
    if (!is_singular()) return;

    $token = sanitize_text_field($_GET['seoroom_preview']);
    $preview = get_transient('seoroom_preview_' . $token);
    if (!$preview) return;

    $page_id = intval($preview['page_id']);
    if (get_queried_object_id() != $page_id) return;

    // Start output buffering — capture the entire rendered HTML, then modify it
    ob_start(function($html) use ($preview, $page_id) {
        if (empty($html) || strlen($html) < 500) return $html;

        $sections = $preview['sections'] ?? [];

        foreach ($sections as $section) {
            $is_new = !empty($section['is_new']);
            $heading = $section['draft_heading'] ?? $section['heading'] ?? '';
            $content = $section['draft_text'] ?? '';
            $type = $section['type'] ?? '';
            $original_heading = $section['original_heading'] ?? $section['heading'] ?? '';

            if (!$is_new || !$content) continue;

            $is_faq = (stripos($type, 'faq') !== false || stripos($heading, 'faq') !== false);

            // Parse Q&A pairs from content (for FAQ sections)
            $qas = [];
            if ($is_faq) {
                $plain_content = strip_tags($content);
                $parts = preg_split('/\n\n+/', $plain_content);
                if (count($parts) < 2) $parts = preg_split('/(?<=\?)\s+(?=[A-Z])/', $plain_content);
                $current_q = null;
                $current_a = '';
                foreach ($parts as $part) {
                    $part = trim($part);
                    if (strlen($part) < 10) continue;
                    if (strpos($part, '?') !== false && stripos($part, 'frequently') === false && strlen($part) < 200) {
                        if ($current_q) $qas[] = ['q' => $current_q, 'a' => trim($current_a)];
                        $qpos = strpos($part, '?');
                        $current_q = substr($part, 0, $qpos + 1);
                        $current_a = trim(substr($part, $qpos + 1));
                    } else if ($current_q) {
                        $current_a .= ' ' . $part;
                    }
                }
                if ($current_q) $qas[] = ['q' => $current_q, 'a' => trim($current_a)];
            }

            if ($is_faq && !empty($qas)) {
                // CLONE existing accordion HTML structure from the rendered page
                // Find ALL accordion item wrappers — look for common patterns
                $accordion_patterns = [
                    // iElementor accordions (ot-acc)
                    '/<div[^>]*class="[^"]*ot-acc-item[^"]*"[^>]*>(.*?)<\/div>\s*<\/div>/is',
                    // Standard Elementor accordion
                    '/<div[^>]*class="[^"]*elementor-accordion-item[^"]*"[^>]*>(.*?)<\/div>\s*<\/div>\s*<\/div>/is',
                    // Standard Elementor toggle
                    '/<div[^>]*class="[^"]*elementor-toggle-item[^"]*"[^>]*>(.*?)<\/div>\s*<\/div>\s*<\/div>/is',
                ];

                $found_item = false;
                foreach ($accordion_patterns as $pattern) {
                    if (preg_match($pattern, $html, $item_match)) {
                        $template_item_html = $item_match[0];
                        $found_item = true;

                        // Build new items by cloning the template HTML
                        $new_items = '';
                        foreach ($qas as $idx => $qa) {
                            $clone = $template_item_html;
                            // Replace the title text — find the first link or heading-like element
                            $clone = preg_replace_callback('/(<a[^>]*class="[^"]*(?:acc_title|title)[^"]*"[^>]*>)(.*?)(<\/a>)/is', function($m) use ($qa) {
                                return $m[1] . esc_html($qa['q']) . $m[3];
                            }, $clone, 1, $title_replaced);
                            if (!$title_replaced) {
                                // Try span/div title
                                $clone = preg_replace_callback('/(<(?:span|div|h[3-6])[^>]*class="[^"]*(?:title|heading|question)[^"]*"[^>]*>)(.*?)(<\/(?:span|div|h[3-6])>)/is', function($m) use ($qa) {
                                    return $m[1] . esc_html($qa['q']) . $m[3];
                                }, $clone, 1, $title_replaced2);
                            }
                            // Replace the content text
                            $clone = preg_replace_callback('/(<div[^>]*class="[^"]*(?:acc_content|content|answer|body)[^"]*"[^>]*>)(.*?)(<\/div>)/is', function($m) use ($qa) {
                                return $m[1] . '<p>' . esc_html($qa['a']) . '</p>' . $m[3];
                            }, $clone, 1);
                            // Change IDs to avoid duplicates
                            $clone = preg_replace('/id="([^"]+)"/i', 'id="seoroom-faq-' . $idx . '-$1"', $clone);
                            $new_items .= $clone;
                        }

                        // Find the accordion container and insert new items
                        // Look for the parent section that contains the accordion
                        $faq_section_pattern = '/<section[^>]*class="[^"]*elementor-(?:top-)?section[^"]*"[^>]*>(?:(?!<\/section>).)*?' . preg_quote(substr($template_item_html, 0, 60), '/') . '(?:(?!<\/section>).)*<\/section>/is';
                        if (preg_match($faq_section_pattern, $html, $section_match, PREG_OFFSET_CAPTURE)) {
                            $section_end = $section_match[0][1] + strlen($section_match[0][0]);
                            // Insert a cloned section AFTER the existing FAQ section
                            $new_section = '<section class="elementor-section elementor-top-section seoroom-preview-section" style="position:relative;">';
                            $new_section .= '<div style="position:absolute;top:8px;right:20px;font-size:10px;font-weight:700;color:#fff;background:#22c55e;padding:3px 10px;border-radius:4px;z-index:10;">NEW FAQ ITEMS</div>';
                            // Copy the inner structure from the existing section
                            $inner = $section_match[0][0];
                            // Replace all accordion items with our new ones
                            $inner = preg_replace($pattern, '', $inner); // Remove existing items
                            // Find the accordion wrapper and inject new items
                            $inner = preg_replace('/(<div[^>]*class="[^"]*(?:ot-accordions|elementor-accordion|elementor-toggle)[^"]*"[^>]*>)/is', '$1' . $new_items, $inner, 1);
                            $new_section .= '</section>';
                            // Actually, simpler: just duplicate the whole section and replace items
                            $cloned_section = $section_match[0][0];
                            // Remove existing accordion items and add new ones
                            $item_count = 0;
                            $cloned_section = preg_replace_callback($pattern, function($m) use ($qas, $template_item_html, &$item_count) {
                                if ($item_count >= count($qas)) return '';
                                $qa = $qas[$item_count];
                                $clone = $template_item_html;
                                $clone = preg_replace_callback('/(<a[^>]*>)(.*?)(<\/a>)/is', function($m2) use ($qa, $item_count) {
                                    if (stripos($m2[0], 'title') !== false || stripos($m2[0], 'acc_title') !== false || $item_count === 0) {
                                        return $m2[1] . esc_html($qa['q']) . $m2[3];
                                    }
                                    return $m2[0];
                                }, $clone, 1);
                                $clone = preg_replace_callback('/(<div[^>]*class="[^"]*(?:acc_content|content)[^"]*"[^>]*>)(.*?)(<\/div>)/is', function($m2) use ($qa) {
                                    return $m2[1] . '<p>' . esc_html($qa['a']) . '</p>' . $m2[3];
                                }, $clone, 1);
                                $clone = preg_replace('/id="([^"]+)"/i', 'id="sr-' . $item_count . '-$1"', $clone);
                                $item_count++;
                                return $clone;
                            }, $cloned_section);
                            // Add green border to distinguish
                            $cloned_section = preg_replace('/class="elementor-section/', 'style="border-top:4px solid #22c55e;position:relative;" class="elementor-section', $cloned_section, 1);
                            // Insert badge
                            $cloned_section = preg_replace('/(<section[^>]*>)/', '$1<div style="position:absolute;top:8px;right:20px;font-size:10px;font-weight:700;color:#fff;background:#22c55e;padding:3px 10px;border-radius:4px;z-index:10;">NEW FAQ</div>', $cloned_section, 1);
                            // Insert after existing FAQ
                            $html = substr($html, 0, $section_end) . $cloned_section . substr($html, $section_end);
                        }
                        break; // Found and processed
                    }
                }

                if ($found_item) continue; // Skip the generic section builder
            }

            // Generic new section (text content) — insert with page container styling
            $new_html = '<div class="seoroom-preview-section" style="position:relative;padding:50px 0;border-top:3px solid #22c55e;">';
            $new_html .= '<div style="position:absolute;top:-14px;right:20px;font-size:10px;font-weight:700;color:#fff;background:#22c55e;padding:3px 10px;border-radius:4px;z-index:10;">NEW SECTION</div>';
            $new_html .= '<div class="elementor-container" style="max-width:1140px;margin:0 auto;padding:0 20px;">';
            if ($heading) $new_html .= '<h2>' . esc_html($heading) . '</h2>';
            $new_html .= $content;
            $new_html .= '</div></div>';

            $footer_pos = stripos($html, '<footer');
            if (!$footer_pos) $footer_pos = stripos($html, '</main>');
            if ($footer_pos) {
                $html = substr($html, 0, $footer_pos) . $new_html . substr($html, $footer_pos);
            } else {
                $html = str_replace('</body>', $new_html . '</body>', $html);
            }
        }

        // Preview bar
        $original_url = get_permalink($page_id);
        $bar = '<div style="position:fixed;bottom:0;left:0;right:0;z-index:999999;background:linear-gradient(135deg,#6366f1,#a855f7);color:#fff;padding:14px 24px;font-size:14px;display:flex;align-items:center;gap:16px;box-shadow:0 -4px 20px rgba(0,0,0,0.3);font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;">'
            . '<strong style="font-size:15px;">SEO Room Preview</strong>'
            . '<span style="background:rgba(255,255,255,0.2);padding:3px 10px;border-radius:5px;font-size:12px;">Design-Safe Mode</span>'
            . '<span style="opacity:0.9;">Content changes are temporary — not published</span>'
            . '<a href="' . esc_url($original_url) . '" style="margin-left:auto;color:#e0e7ff;text-decoration:underline;font-size:13px;">View original &rarr;</a>'
            . '</div>';
        $html = str_replace('</body>', $bar . '</body>', $html);

        return $html;
    });
}

// Add preview bar to the page when in preview mode
add_action('wp_footer', 'sropt_elementor_preview_bar');
function sropt_elementor_preview_bar() {
    if (empty($_GET['seoroom_preview'])) return;
    $token = sanitize_text_field($_GET['seoroom_preview']);
    $preview = get_transient('seoroom_preview_' . $token);
    if (!$preview) return;

    $original_url = get_permalink($preview['page_id']);
    ?>
    <div style="position:fixed;bottom:0;left:0;right:0;z-index:999999;background:linear-gradient(135deg,#6366f1,#a855f7);color:#fff;padding:14px 24px;font-size:14px;display:flex;align-items:center;gap:16px;box-shadow:0 -4px 20px rgba(0,0,0,0.3);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
        <strong style="font-size:15px;">SEO Room Preview</strong>
        <span style="background:rgba(255,255,255,0.2);padding:3px 10px;border-radius:5px;font-size:12px;">Design-Safe Mode</span>
        <span style="opacity:0.9;">Content changes are temporary — not published</span>
        <a href="<?php echo esc_url($original_url); ?>" style="margin-left:auto;color:#e0e7ff;text-decoration:underline;font-size:13px;">View original &rarr;</a>
    </div>
    <?php
}

// Output JSON-LD in <head>
add_action('wp_head', 'sropt_output_schema', 5);
function sropt_output_schema() {
    $options = sropt_get_options();
    if (!$options['enable_schema']) return;
    if (!is_singular()) return;

    $post_id = get_the_ID();
    if (!$post_id) return;

    $schema = get_post_meta($post_id, '_seoroom_schema', true);
    if (empty($schema)) return;

    $decoded = json_decode($schema);
    if (json_last_error() !== JSON_ERROR_NONE) return;

    $clean = wp_json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if (!$clean) return;

    echo "\n<!-- SEO Room Schema -->\n";
    echo '<script type="application/ld+json">' . $clean . '</script>' . "\n";
}


// ================================================================
// IMAGE OPTIMIZATION
// ================================================================

// Lazy loading — skip first 2 images (above fold / LCP)
add_filter('the_content', 'sropt_lazy_load', 999);
add_filter('post_thumbnail_html', 'sropt_lazy_load', 999);
add_filter('widget_text', 'sropt_lazy_load', 999);

function sropt_lazy_load($content) {
    if (is_admin() || is_feed() || wp_doing_ajax()) return $content;
    $options = sropt_get_options();
    if (!$options['enable_lazy_load']) return $content;

    $count = 0;
    $skip_first = 2;

    $content = preg_replace_callback('/<img\b([^>]*)>/i', function($matches) use (&$count, $skip_first) {
        $count++;
        $attrs = $matches[1];
        if (preg_match('/\bloading\s*=/i', $attrs)) return $matches[0];

        if ($count <= $skip_first) {
            if ($count === 1 && !preg_match('/fetchpriority/i', $attrs)) {
                return '<img' . $attrs . ' fetchpriority="high">';
            }
            return $matches[0];
        }
        return '<img' . $attrs . ' loading="lazy">';
    }, $content);

    $content = preg_replace_callback('/<iframe\b([^>]*)>/i', function($matches) {
        $attrs = $matches[1];
        if (preg_match('/\bloading\s*=/i', $attrs)) return $matches[0];
        return '<iframe' . $attrs . ' loading="lazy">';
    }, $content);

    return $content;
}

// Add missing width/height to images to prevent CLS
add_filter('the_content', 'sropt_image_dimensions', 998);
function sropt_image_dimensions($content) {
    if (is_admin() || is_feed()) return $content;
    $options = sropt_get_options();
    if (!$options['enable_image_dims']) return $content;

    $content = preg_replace_callback('/<img\b([^>]*)>/i', function($matches) {
        $attrs = $matches[1];
        if (preg_match('/\bwidth\s*=/i', $attrs) && preg_match('/\bheight\s*=/i', $attrs)) return $matches[0];
        if (!preg_match('/\bsrc\s*=\s*["\']([^"\']+)["\']/i', $attrs, $src_match)) return $matches[0];

        $src = $src_match[1];
        $attachment_id = attachment_url_to_postid($src);
        if ($attachment_id) {
            $meta = wp_get_attachment_metadata($attachment_id);
            if ($meta && !empty($meta['width']) && !empty($meta['height'])) {
                $w = $meta['width'];
                $h = $meta['height'];
                if (preg_match('/-(\d+)x(\d+)\.\w+$/', $src, $size_match)) {
                    $w = $size_match[1];
                    $h = $size_match[2];
                }
                if (!preg_match('/\bwidth\s*=/i', $attrs)) $attrs .= ' width="' . $w . '"';
                if (!preg_match('/\bheight\s*=/i', $attrs)) $attrs .= ' height="' . $h . '"';
                return '<img' . $attrs . '>';
            }
        }
        return $matches[0];
    }, $content);

    return $content;
}


// ================================================================
// IMAGE COMPRESSION ON UPLOAD
// Compress JPEG/PNG on upload — strip EXIF, reduce quality.
// Non-destructive: WP keeps original in revision history.
// ================================================================

add_filter('wp_handle_upload', 'sropt_compress_uploaded_image');
function sropt_compress_uploaded_image($upload) {
    $options = sropt_get_options();
    if (!$options['enable_image_compress']) return $upload;

    $file = $upload['file'];
    $type = $upload['type'] ?? '';

    if ($type === 'image/jpeg' || $type === 'image/jpg') {
        sropt_compress_jpeg($file, (int)$options['image_compress_quality']);
    } elseif ($type === 'image/png') {
        sropt_compress_png($file);
    }

    return $upload;
}

function sropt_compress_jpeg($file, $quality = 82) {
    if (!function_exists('imagecreatefromjpeg')) return false;

    $img = @imagecreatefromjpeg($file);
    if (!$img) return false;

    // Strip EXIF by re-encoding (imagecreatefromjpeg doesn't preserve EXIF)
    // Save with target quality
    $result = @imagejpeg($img, $file, $quality);
    imagedestroy($img);
    return $result;
}

function sropt_compress_png($file) {
    if (!function_exists('imagecreatefrompng')) return false;

    $img = @imagecreatefrompng($file);
    if (!$img) return false;

    // Preserve transparency
    imagealphablending($img, false);
    imagesavealpha($img, true);

    // PNG compression level 6 (0=none, 9=max compression)
    // Level 6 is good balance of speed vs size
    $result = @imagepng($img, $file, 6);
    imagedestroy($img);
    return $result;
}

// Also compress generated thumbnails/sizes
add_filter('wp_generate_attachment_metadata', 'sropt_compress_thumbnails', 10, 2);
function sropt_compress_thumbnails($metadata, $attachment_id) {
    $options = sropt_get_options();
    if (!$options['enable_image_compress']) return $metadata;

    $upload_dir = wp_upload_dir();
    $base_dir = $upload_dir['basedir'];
    $file_dir = dirname($metadata['file']);

    if (!empty($metadata['sizes'])) {
        foreach ($metadata['sizes'] as $size => $data) {
            $file_path = $base_dir . '/' . $file_dir . '/' . $data['file'];
            if (!file_exists($file_path)) continue;

            $mime = $data['mime-type'] ?? '';
            if ($mime === 'image/jpeg' || $mime === 'image/jpg') {
                sropt_compress_jpeg($file_path, (int)$options['image_compress_quality']);
            } elseif ($mime === 'image/png') {
                sropt_compress_png($file_path);
            }
        }
    }

    return $metadata;
}


// ================================================================
// HTML OUTPUT BUFFER — Critical CSS, CSS/JS minification, font-swap, preconnect
// ================================================================

// Speed optimization output buffer DISABLED — BerqWP handles all speed optimizations.
// Plugin focuses on: schema injection, 404 monitor, redirects, broken links, dashboard connector.
// add_action('template_redirect', 'sropt_start_buffer', 1);
function sropt_start_buffer() {
    // Disabled — BerqWP conflicts with output buffer HTML rewriting
    return;
}

function sropt_process_html($html) {
    if (empty($html) || strlen($html) < 100) return $html;
    if (stripos($html, '<html') === false && stripos($html, '<!DOCTYPE') === false) return $html;

    $options = sropt_get_options();
    $is_safe = $options['safe_mode'];

    // ---- UNUSED CSS REMOVAL ---- (must run BEFORE critical CSS so critical extraction works on purged CSS)
    if ($options['enable_unused_css'] && !$is_safe) {
        $html = sropt_remove_unused_css($html, $options);
    }

    // ---- CRITICAL CSS INJECTION ----
    if ($options['enable_critical_css'] && !$is_safe) {
        $html = sropt_inject_critical_css($html, $options);
    }

    // CSS minification (inline <style> blocks)
    if ($options['enable_css_minify'] && !$is_safe) {
        $html = preg_replace_callback('/<style\b([^>]*)>(.*?)<\/style>/is', function($m) {
            $css = $m[2];
            $css = preg_replace('!/\*.*?\*/!s', '', $css);
            $css = preg_replace('/\s+/', ' ', $css);
            $css = preg_replace('/\s*([{}:;,>~+])\s*/', '$1', $css);
            $css = preg_replace('/;}/', '}', $css);
            return '<style' . $m[1] . '>' . trim($css) . '</style>';
        }, $html);
    }

    // JS minification (inline <script> blocks only)
    if ($options['enable_js_minify'] && !$is_safe) {
        $html = preg_replace_callback('/<script\b([^>]*)>(.*?)<\/script>/is', function($m) {
            $attrs = $m[1];
            $js = $m[2];
            if (preg_match('/\bsrc\s*=/i', $attrs)) return $m[0];
            if (preg_match('/type\s*=\s*["\'](?:application\/(?:ld\+json|json)|text\/(?:template|html))/i', $attrs)) return $m[0];
            if (empty(trim($js))) return $m[0];
            $js = preg_replace('#^\s*//[^\n]*$#m', '', $js);
            $js = preg_replace('/\s+/', ' ', $js);
            return '<script' . $attrs . '>' . trim($js) . '</script>';
        }, $html);
    }

    // Font-display: swap
    if ($options['enable_font_swap']) {
        $html = preg_replace_callback('/@font-face\s*\{([^}]+)\}/i', function($m) {
            if (stripos($m[1], 'font-display') !== false) return $m[0];
            return '@font-face{' . rtrim($m[1], '; ') . ';font-display:swap;}';
        }, $html);

        $html = preg_replace_callback('/href\s*=\s*["\']([^"\']*fonts\.googleapis\.com[^"\']*)["\']/', function($m) {
            $url = $m[1];
            if (strpos($url, 'display=') !== false) return $m[0];
            $sep = strpos($url, '?') !== false ? '&' : '?';
            return str_replace($url, $url . $sep . 'display=swap', $m[0]);
        }, $html);
    }

    // Auto preconnect + DNS prefetch
    if ($options['enable_preconnect'] || $options['enable_dns_prefetch']) {
        $external_domains = array();
        $site_host = parse_url(home_url(), PHP_URL_HOST);

        preg_match_all('/(?:href|src)\s*=\s*["\']https?:\/\/([^"\'\/]+)/i', $html, $domain_matches);
        if (!empty($domain_matches[1])) {
            foreach ($domain_matches[1] as $domain) {
                $domain = strtolower($domain);
                if ($domain !== $site_host && !isset($external_domains[$domain])) {
                    $external_domains[$domain] = true;
                }
            }
        }

        $preconnect_priority = array(
            'fonts.googleapis.com', 'fonts.gstatic.com', 'www.googletagmanager.com',
            'www.google-analytics.com', 'cdnjs.cloudflare.com', 'ajax.googleapis.com',
            'maps.googleapis.com', 'www.google.com',
        );

        $tags = '';
        foreach ($external_domains as $domain => $v) {
            $url = 'https://' . $domain;
            if (preg_match('/rel\s*=\s*["\'](?:preconnect|dns-prefetch)["\'][^>]*' . preg_quote($domain, '/') . '/', $html)) continue;

            if ($options['enable_preconnect'] && in_array($domain, $preconnect_priority)) {
                $crossorigin = (strpos($domain, 'gstatic.com') !== false) ? ' crossorigin' : '';
                $tags .= '<link rel="preconnect" href="' . esc_url($url) . '"' . $crossorigin . '>' . "\n";
            }
            if ($options['enable_dns_prefetch']) {
                $tags .= '<link rel="dns-prefetch" href="' . esc_url($url) . '">' . "\n";
            }
        }

        if ($tags) {
            if (preg_match('/<meta[^>]*charset[^>]*>/i', $html, $meta_match, PREG_OFFSET_CAPTURE)) {
                $pos = $meta_match[0][1] + strlen($meta_match[0][0]);
                $html = substr($html, 0, $pos) . "\n" . $tags . substr($html, $pos);
            } elseif (($head_pos = stripos($html, '<head>')) !== false) {
                $pos = $head_pos + 6;
                $html = substr($html, 0, $pos) . "\n" . $tags . substr($html, $pos);
            }
        }
    }

    // LCP preload injection (runs on fully rendered HTML)
    $html = sropt_lcp_buffer_handler($html);

    return $html;
}


// ================================================================
// CRITICAL CSS — Extract above-fold CSS, inline in <head>, defer rest
// ================================================================

function sropt_inject_critical_css($html, $options) {
    // Generate a cache key from the request URI
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $cache_key = md5(($_SERVER['HTTP_HOST'] ?? '') . $uri);
    $cache_dir = WP_CONTENT_DIR . '/cache/seoroom/critical/';
    $cache_file = $cache_dir . $cache_key . '.css';

    // Check if we have cached critical CSS
    $critical_css = '';
    if (file_exists($cache_file) && (time() - filemtime($cache_file)) < 604800) { // 7-day TTL
        $critical_css = file_get_contents($cache_file);
    }

    if (empty($critical_css)) {
        // Generate critical CSS from stylesheets in the HTML
        $critical_css = sropt_generate_critical_css($html);

        // Cache it
        if (!file_exists($cache_dir)) wp_mkdir_p($cache_dir);
        if (!empty($critical_css)) {
            @file_put_contents($cache_file, $critical_css);
        }
    }

    if (empty($critical_css)) return $html;

    // Minify the critical CSS
    $critical_css = preg_replace('!/\*.*?\*/!s', '', $critical_css);
    $critical_css = preg_replace('/\s+/', ' ', $critical_css);
    $critical_css = preg_replace('/\s*([{}:;,>~+])\s*/', '$1', $critical_css);
    $critical_css = preg_replace('/;}/', '}', $critical_css);
    $critical_css = trim($critical_css);

    // Cap at 60KB to avoid bloating HTML
    if (strlen($critical_css) > 40960) {
        $critical_css = substr($critical_css, 0, 40960);
        // Find the last complete rule
        $last_brace = strrpos($critical_css, '}');
        if ($last_brace !== false) $critical_css = substr($critical_css, 0, $last_brace + 1);
    }

    // Inject critical CSS inline in <head>
    $critical_tag = "\n<style id=\"seoroom-critical-css\">" . $critical_css . "</style>\n";

    // Find insertion point — after <meta charset> or right after <head>
    if (preg_match('/<meta[^>]*charset[^>]*>/i', $html, $meta_match, PREG_OFFSET_CAPTURE)) {
        $pos = $meta_match[0][1] + strlen($meta_match[0][0]);
        $html = substr($html, 0, $pos) . $critical_tag . substr($html, $pos);
    } elseif (($head_pos = stripos($html, '<head>')) !== false) {
        $pos = $head_pos + 6;
        $html = substr($html, 0, $pos) . $critical_tag . substr($html, $pos);
    }

    // Defer non-critical stylesheets — convert <link rel="stylesheet"> to async loading
    $excludes = array_filter(array_map('trim', explode(',', $options['exclude_css'])));
    $never_defer_css = array('admin-bar', 'dashicons', 'wp-admin');

    $html = preg_replace_callback('/<link\b([^>]*rel\s*=\s*["\']stylesheet["\'][^>]*)>/i', function($matches) use ($excludes, $never_defer_css) {
        $attrs = $matches[1];

        // Extract handle/href for exclusion checking
        $href = '';
        if (preg_match('/href\s*=\s*["\']([^"\']+)["\']/i', $attrs, $href_match)) {
            $href = $href_match[1];
        }
        $handle = '';
        if (preg_match('/id\s*=\s*["\']([^"\']+)-css["\']/i', $attrs, $id_match)) {
            $handle = $id_match[1];
        }

        // Check exclusions
        if (in_array($handle, $never_defer_css)) return $matches[0];
        foreach ($excludes as $exc) {
            if ($handle === $exc || strpos($href, $exc) !== false) return $matches[0];
        }

        // Already deferred?
        if (preg_match('/media\s*=\s*["\']print["\']/i', $attrs)) return $matches[0];

        // Convert to async loading with print/onload pattern
        $deferred = $matches[0];
        $deferred = preg_replace("/media\s*=\s*['\"]all['\"]/i", "media=\"print\" onload=\"this.media='all'\"", $deferred);
        // If no media attribute was present, add one
        if (!preg_match('/onload/i', $deferred)) {
            $deferred = str_replace('rel="stylesheet"', 'rel="stylesheet" media="print" onload="this.media=\'all\'"', $deferred);
            $deferred = str_replace("rel='stylesheet'", "rel='stylesheet' media='print' onload=\"this.media='all'\"", $deferred);
        }

        // Add noscript fallback
        $noscript = '<noscript>' . $matches[0] . '</noscript>';
        return $deferred . "\n" . $noscript;
    }, $html);

    return $html;
}

function sropt_generate_critical_css($html) {
    // 1. Extract all stylesheet URLs from HTML
    $stylesheet_urls = array();
    preg_match_all('/<link\b[^>]*rel\s*=\s*["\']stylesheet["\'][^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*>/i', $html, $m1);
    if (!empty($m1[1])) $stylesheet_urls = array_merge($stylesheet_urls, $m1[1]);
    preg_match_all('/<link\b[^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*rel\s*=\s*["\']stylesheet["\'][^>]*>/i', $html, $m2);
    if (!empty($m2[1])) $stylesheet_urls = array_merge($stylesheet_urls, $m2[1]);
    $stylesheet_urls = array_unique($stylesheet_urls);

    // 2. Read stylesheet files from disk
    $all_css = '';
    foreach ($stylesheet_urls as $url) {
        $path = sropt_url_to_local_path($url);
        if ($path && file_exists($path) && is_readable($path)) {
            $content = @file_get_contents($path);
            if ($content) {
                // Resolve relative URLs in CSS (url(../images/...) etc.)
                $css_dir_url = dirname($url);
                $content = preg_replace_callback('/url\s*\(\s*["\']?(?!data:|https?:|\/\/)([^"\')\s]+)["\']?\s*\)/i', function($m) use ($css_dir_url) {
                    $resolved = $css_dir_url . '/' . $m[1];
                    return 'url(' . $resolved . ')';
                }, $content);
                $all_css .= $content . "\n";
            }
        }
    }

    // 3. Also extract inline <style> blocks from the HTML
    preg_match_all('/<style\b[^>]*>(.*?)<\/style>/is', $html, $style_matches);
    if (!empty($style_matches[1])) {
        foreach ($style_matches[1] as $inline) {
            // Skip JSON-LD and template styles
            if (strpos($inline, 'application/ld+json') !== false) continue;
            $all_css .= $inline . "\n";
        }
    }

    if (empty(trim($all_css))) return '';

    // 4. Extract critical rules
    return sropt_extract_critical_rules($all_css);
}

function sropt_url_to_local_path($url) {
    // Remove query string
    $url = preg_replace('/\?.*$/', '', $url);

    // Handle protocol-relative URLs
    if (strpos($url, '//') === 0) $url = 'https:' . $url;

    $site_url = site_url();
    $abspath = rtrim(ABSPATH, '/');

    // Check if it's a local URL
    if (strpos($url, $site_url) === 0) {
        $relative = str_replace($site_url, '', $url);
        return $abspath . $relative;
    }

    // Try wp-content path
    if (preg_match('#/wp-content/(.+)#', $url, $m)) {
        return WP_CONTENT_DIR . '/' . $m[1];
    }

    // Try wp-includes path
    if (preg_match('#/wp-includes/(.+)#', $url, $m)) {
        return ABSPATH . 'wp-includes/' . $m[1];
    }

    return false;
}

function sropt_extract_critical_rules($all_css) {
    $critical = '';
    $max_size = 40960; // 40KB max — lean critical CSS for fast first paint

    // BLACKLIST approach: include rules EXCEPT known below-fold patterns
    $exclude_selectors = 'footer|\.footer|#footer|\.site-footer|\.widget-area|\.sidebar|#sidebar|\.comment|#comments|#respond|\.pagination|\.wp-pagenavi|\.post-navigation|\.screen-reader|\.sr-only|\.hidden|\.d-none|\.invisible|\.print-only|\.no-js|\.noprint|\.swiper-|\.slick-|\.owl-|\.carousel|\.modal|\.popup|\.lightbox|\.cookie|\.banner-close';

    // Always keep :root / CSS custom properties (small, essential)
    if (preg_match_all('/:root\s*\{[^}]+\}/i', $all_css, $roots)) {
        foreach ($roots[0] as $r) {
            $critical .= $r . "\n";
        }
    }

    // SMART @font-face: only keep fonts actually used in critical selectors
    // Extract font-family names used in the CSS body (not in @font-face itself)
    $css_no_fontface = preg_replace('/@font-face\s*\{[^}]+\}/i', '', $all_css);
    $used_fonts = array();
    if (preg_match_all('/font-family\s*:\s*([^;}{]+)/i', $css_no_fontface, $ff_uses)) {
        foreach ($ff_uses[1] as $ff_val) {
            // Extract first font in stack (the primary one)
            $fonts = explode(',', $ff_val);
            foreach ($fonts as $f) {
                $f = trim($f, " \t\n\r\"'");
                $f_lower = strtolower($f);
                // Skip generic families
                if (in_array($f_lower, array('serif', 'sans-serif', 'monospace', 'cursive', 'fantasy', 'system-ui', 'inherit', 'initial', 'unset'))) continue;
                $used_fonts[$f_lower] = true;
            }
        }
    }

    // Now include only @font-face for fonts that are actually used, limit to woff2 format
    if (preg_match_all('/@font-face\s*\{[^}]+\}/i', $all_css, $font_faces)) {
        $font_count = 0;
        $max_fonts = 6; // Max 6 @font-face declarations (typically 2-3 families × 2 weights)
        foreach ($font_faces[0] as $ff) {
            if ($font_count >= $max_fonts) break;
            // Extract font-family from this @font-face
            if (preg_match('/font-family\s*:\s*["\']?([^"\';}]+)/i', $ff, $ffn)) {
                $face_name = strtolower(trim($ffn[1], " \t\n\r\"'"));
                // Only include if this font is actually referenced in styles
                if (isset($used_fonts[$face_name])) {
                    // Prefer woff2 only — strip other format src if woff2 exists
                    if (strpos($ff, 'woff2') !== false) {
                        $critical .= $ff . "\n";
                        $font_count++;
                    }
                }
            }
        }
    }

    // SKIP @keyframes entirely — animations are NOT critical for first paint
    // They load with the deferred stylesheets after critical CSS renders

    // Remove @font-face, @keyframes from CSS before parsing rules
    $css_no_at = preg_replace('/@font-face\s*\{[^}]+\}/i', '', $all_css);
    $css_no_at = preg_replace('/@keyframes\s+[\w-]+\s*\{(?:[^{}]*\{[^}]*\})*[^}]*\}/i', '', $css_no_at);

    // Extract @media blocks separately
    $media_blocks = array();
    $css_no_media = preg_replace_callback('/@media\s*([^{]+)\{((?:[^{}]*\{[^}]*\})*[^}]*)\}/i', function($m) use (&$media_blocks) {
        $media_blocks[] = array('query' => trim($m[1]), 'content' => $m[2]);
        return '';
    }, $css_no_at);

    // Parse individual CSS rules — INCLUDE ALL except blacklisted
    preg_match_all('/([^{}@]+)\{([^{}]+)\}/', $css_no_media, $rules, PREG_SET_ORDER);

    foreach ($rules as $rule) {
        if (strlen($critical) > $max_size) break;

        $selector = trim($rule[1]);
        $declarations = trim($rule[2]);

        if (preg_match('/^\d+%$|^from$|^to$/i', $selector)) continue;
        if (empty($declarations)) continue;

        // BLACKLIST: skip known below-fold and non-critical selectors
        if (preg_match('/(?:^|\s|,)(' . $exclude_selectors . ')\b/i', $selector)) continue;

        // Skip animation-only declarations (they reference keyframes we didn't include)
        if (preg_match('/^\s*animation\s*:/i', $declarations) && substr_count($declarations, ':') === 1) continue;

        $critical .= $selector . '{' . $declarations . "}\n";
    }

    // Process @media blocks — only include screen-relevant ones
    foreach ($media_blocks as $mb) {
        if (strlen($critical) > $max_size) break;

        // Skip print-only media queries
        if (preg_match('/\bprint\b/i', $mb['query']) && !preg_match('/\bscreen\b/i', $mb['query'])) continue;

        // Skip very large viewport media queries (likely tablet/desktop overrides on mobile-first)
        // Keep mobile and general responsive rules
        $inner_critical = '';
        preg_match_all('/([^{}@]+)\{([^{}]+)\}/', $mb['content'], $inner_rules, PREG_SET_ORDER);

        foreach ($inner_rules as $ir) {
            $sel = trim($ir[1]);
            $decl = trim($ir[2]);
            if (preg_match('/^\d+%$|^from$|^to$/i', $sel)) continue;
            if (empty($decl)) continue;
            if (preg_match('/(?:^|\s|,)(' . $exclude_selectors . ')\b/i', $sel)) continue;

            $inner_critical .= $sel . '{' . $decl . "}\n";
        }

        if (!empty($inner_critical)) {
            $critical .= '@media ' . $mb['query'] . '{' . $inner_critical . "}\n";
        }
    }

    return $critical;
}


// ================================================================
// UNUSED CSS REMOVAL — Parse HTML, keep only matching CSS selectors
// ================================================================

function sropt_remove_unused_css($html, $options) {
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $cache_key = md5(($_SERVER['HTTP_HOST'] ?? '') . $uri);
    $purge_dir = WP_CONTENT_DIR . '/cache/seoroom/purged/';
    $purge_file = $purge_dir . $cache_key . '.css';
    $purge_url = content_url('cache/seoroom/purged/' . $cache_key . '.css');

    // Check cache (7-day TTL)
    if (file_exists($purge_file) && (time() - filemtime($purge_file)) < 604800) {
        // Replace all local stylesheets with single purged CSS file
        return sropt_replace_stylesheets_with_purged($html, $purge_url, $options);
    }

    // ---- STEP 1: Extract used tokens from HTML ----
    $used = sropt_extract_html_tokens($html);
    if (empty($used['classes']) && empty($used['ids']) && empty($used['tags'])) return $html;

    // ---- STEP 2: Collect all local CSS ----
    // Extract stylesheet URLs
    preg_match_all('/<link\b[^>]*rel\s*=\s*["\']stylesheet["\'][^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*>/i', $html, $m1);
    preg_match_all('/<link\b[^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*rel\s*=\s*["\']stylesheet["\'][^>]*>/i', $html, $m2);
    $stylesheet_urls = array_unique(array_merge($m1[1] ?? [], $m2[1] ?? []));

    $all_css = '';
    $local_urls = array();
    foreach ($stylesheet_urls as $url) {
        $path = sropt_url_to_local_path($url);
        if ($path && file_exists($path) && is_readable($path)) {
            $content = @file_get_contents($path);
            if ($content) {
                // Resolve relative URLs
                $css_dir_url = dirname($url);
                $content = preg_replace_callback('/url\s*\(\s*["\']?(?!data:|https?:|\/\/)([^"\')\s]+)["\']?\s*\)/i', function($m) use ($css_dir_url) {
                    return 'url(' . $css_dir_url . '/' . $m[1] . ')';
                }, $content);
                $all_css .= $content . "\n";
                $local_urls[] = $url;
            }
        }
    }

    // Also include inline <style> blocks
    preg_match_all('/<style\b[^>]*>(.*?)<\/style>/is', $html, $style_matches);
    if (!empty($style_matches[1])) {
        foreach ($style_matches[1] as $inline) {
            if (strpos($inline, 'application/ld+json') !== false) continue;
            if (strpos($inline, 'seoroom-critical-css') !== false) continue;
            $all_css .= $inline . "\n";
        }
    }

    if (empty(trim($all_css))) return $html;

    // ---- STEP 3: Build safelist ----
    $safelist = sropt_build_safelist($options);

    // ---- STEP 4: Purge unused rules ----
    $purged_css = sropt_purge_css($all_css, $used, $safelist);

    if (empty($purged_css)) return $html;

    // ---- STEP 5: Cache the purged CSS ----
    if (!file_exists($purge_dir)) wp_mkdir_p($purge_dir);
    @file_put_contents($purge_file, $purged_css);

    // ---- STEP 6: Replace stylesheets with purged file ----
    return sropt_replace_stylesheets_with_purged($html, $purge_url, $options);
}


/**
 * Extract all element tags, classes, and IDs from the HTML.
 */
function sropt_extract_html_tokens($html) {
    $tags = array();
    $classes = array();
    $ids = array();
    $attrs = array();

    // Extract all HTML tags and their attributes
    preg_match_all('/<([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>/s', $html, $tag_matches, PREG_SET_ORDER);

    foreach ($tag_matches as $tm) {
        $tag = strtolower($tm[1]);
        $tags[$tag] = true;
        $attr_str = $tm[2] ?? '';

        // Extract classes
        if (preg_match('/\bclass\s*=\s*["\']([^"\']*)["\']/', $attr_str, $cls)) {
            $class_list = preg_split('/\s+/', trim($cls[1]));
            foreach ($class_list as $c) {
                $c = trim($c);
                if ($c !== '') $classes[$c] = true;
            }
        }

        // Extract IDs
        if (preg_match('/\bid\s*=\s*["\']([^"\']*)["\']/', $attr_str, $id)) {
            $id_val = trim($id[1]);
            if ($id_val !== '') $ids[$id_val] = true;
        }

        // Extract data attributes (for attribute selectors)
        if (preg_match_all('/\b(data-[a-zA-Z0-9_-]+)/', $attr_str, $data_attrs)) {
            foreach ($data_attrs[1] as $da) $attrs[strtolower($da)] = true;
        }

        // Extract role, type, aria attributes
        if (preg_match_all('/\b(role|type|aria-[a-zA-Z0-9_-]+)\s*=\s*["\']([^"\']*)["\']/', $attr_str, $attr_vals, PREG_SET_ORDER)) {
            foreach ($attr_vals as $av) {
                $attrs[strtolower($av[1]) . '=' . $av[2]] = true;
                $attrs[strtolower($av[1])] = true;
            }
        }
    }

    return array(
        'tags'    => $tags,
        'classes' => $classes,
        'ids'     => $ids,
        'attrs'   => $attrs,
    );
}


/**
 * Build safelist of patterns that should never be removed.
 * Includes dynamic classes added by JS (menus, popups, sliders, etc.)
 */
function sropt_build_safelist($options) {
    // Default safelist: common JS-toggled classes and state classes
    $defaults = array(
        // State classes (toggled by JS)
        'active', 'open', 'show', 'visible', 'hidden', 'expanded', 'collapsed',
        'is-active', 'is-open', 'is-visible', 'is-hidden', 'is-expanded', 'is-collapsed',
        'has-', 'no-', 'not-',
        // WordPress
        'menu-item', 'sub-menu', 'current-menu', 'page-item', 'widget',
        'wp-block', 'wp-element', 'has-', 'is-layout',
        'logged-in', 'admin-bar',
        // Elementor
        'elementor-', 'e-', 'eicon-', 'dialog-', 'flatpickr-',
        // Common JS libraries
        'swiper-', 'slick-', 'owl-', 'fancybox-', 'magnific-', 'lightbox',
        'modal', 'popup', 'dropdown', 'tooltip', 'toast',
        // Animations / transitions
        'animate-', 'aos-', 'wow-', 'fade', 'slide',
        // Accessibility
        'screen-reader', 'sr-only', 'visually-hidden', 'aria-',
        // Common responsive
        'mobile-', 'tablet-', 'desktop-',
        // Forms
        'wpcf7', 'form-', 'input-', 'select2', 'chosen-',
    );

    // Add user-defined safelist
    $user_safelist = array_filter(array_map('trim', explode(',', $options['unused_css_safelist'] ?? '')));
    $all_patterns = array_merge($defaults, $user_safelist);

    return $all_patterns;
}


/**
 * Core CSS purging: remove selectors that don't match anything in the HTML.
 */
function sropt_purge_css($all_css, $used, $safelist) {
    $purged = '';

    // Always keep :root, *, html, body, @font-face, @keyframes, @charset, @import
    if (preg_match_all('/:root\s*\{[^}]+\}/i', $all_css, $roots)) {
        foreach ($roots[0] as $r) $purged .= $r . "\n";
    }

    // Keep @font-face declarations
    if (preg_match_all('/@font-face\s*\{[^}]+\}/i', $all_css, $fonts)) {
        foreach ($fonts[0] as $f) $purged .= $f . "\n";
    }

    // Keep @keyframes (animations may be triggered by JS)
    if (preg_match_all('/@keyframes\s+[\w-]+\s*\{(?:[^{}]*\{[^}]*\})*[^}]*\}/i', $all_css, $kfs)) {
        foreach ($kfs[0] as $kf) $purged .= $kf . "\n";
    }

    // Keep @charset, @import
    if (preg_match_all('/@(?:charset|import)\s[^;]+;/i', $all_css, $at_rules)) {
        foreach ($at_rules[0] as $r) $purged .= $r . "\n";
    }

    // Strip @font-face, @keyframes, @charset, @import from working CSS
    $work_css = preg_replace('/@font-face\s*\{[^}]+\}/i', '', $all_css);
    $work_css = preg_replace('/@keyframes\s+[\w-]+\s*\{(?:[^{}]*\{[^}]*\})*[^}]*\}/i', '', $work_css);
    $work_css = preg_replace('/@(?:charset|import)\s[^;]+;/i', '', $work_css);
    $work_css = preg_replace('/:root\s*\{[^}]+\}/i', '', $work_css);

    // Extract @media blocks
    $media_blocks = array();
    $work_css = preg_replace_callback('/@media\s*([^{]+)\{((?:[^{}]*\{[^}]*\})*[^}]*)\}/i', function($m) use (&$media_blocks) {
        $media_blocks[] = array('query' => trim($m[1]), 'content' => $m[2]);
        return '';
    }, $work_css);

    // Process non-media rules
    preg_match_all('/([^{}@]+)\{([^{}]+)\}/', $work_css, $rules, PREG_SET_ORDER);
    foreach ($rules as $rule) {
        $selector = trim($rule[1]);
        $declarations = trim($rule[2]);
        if (empty($selector) || empty($declarations)) continue;
        if (preg_match('/^\d+%$|^from$|^to$/i', $selector)) continue;

        if (sropt_selector_is_used($selector, $used, $safelist)) {
            $purged .= $selector . '{' . $declarations . "}\n";
        }
    }

    // Process @media blocks
    foreach ($media_blocks as $mb) {
        // Skip print-only
        if (preg_match('/\bprint\b/i', $mb['query']) && !preg_match('/\bscreen\b/i', $mb['query'])) continue;

        $inner_purged = '';
        preg_match_all('/([^{}@]+)\{([^{}]+)\}/', $mb['content'], $inner_rules, PREG_SET_ORDER);
        foreach ($inner_rules as $ir) {
            $sel = trim($ir[1]);
            $decl = trim($ir[2]);
            if (empty($sel) || empty($decl)) continue;
            if (preg_match('/^\d+%$|^from$|^to$/i', $sel)) continue;

            if (sropt_selector_is_used($sel, $used, $safelist)) {
                $inner_purged .= $sel . '{' . $decl . "}\n";
            }
        }

        if (!empty($inner_purged)) {
            $purged .= '@media ' . $mb['query'] . '{' . $inner_purged . "}\n";
        }
    }

    return $purged;
}


/**
 * Check if a CSS selector group matches anything in the HTML.
 * A selector group like "h1, .hero, #main" is used if ANY part matches.
 */
function sropt_selector_is_used($selector_group, $used, $safelist) {
    // Universal selectors always match
    if (preg_match('/^\s*\*\s*$/', $selector_group)) return true;

    // Split compound selectors (comma-separated)
    $selectors = explode(',', $selector_group);

    foreach ($selectors as $selector) {
        $selector = trim($selector);
        if (empty($selector)) continue;

        // Always keep: html, body, *, ::before, ::after, :root
        if (preg_match('/^(?:html|body|\*|:root)\b/i', $selector)) return true;
        if (strpos($selector, '::') !== false) {
            // Pseudo-element — check if the base selector is used
            $base = preg_replace('/::[\w-]+.*$/', '', $selector);
            if (empty(trim($base)) || preg_match('/^(?:html|body|\*|:root)\b/i', trim($base))) return true;
            if (sropt_single_selector_matches(trim($base), $used, $safelist)) return true;
            continue;
        }

        if (sropt_single_selector_matches($selector, $used, $safelist)) return true;
    }

    return false;
}


/**
 * Check if a single selector (not comma-separated) matches the HTML tokens.
 */
function sropt_single_selector_matches($selector, $used, $safelist) {
    // Check safelist patterns first
    foreach ($safelist as $pattern) {
        if (empty($pattern)) continue;
        // Check if any part of the selector matches a safelist pattern
        if (strpos($selector, $pattern) !== false) return true;
    }

    // Extract all classes from selector (.classname)
    if (preg_match_all('/\.([a-zA-Z_][a-zA-Z0-9_-]*)/', $selector, $cls_matches)) {
        $all_match = true;
        foreach ($cls_matches[1] as $cls) {
            if (!isset($used['classes'][$cls])) {
                $all_match = false;
                break;
            }
        }
        if ($all_match && !empty($cls_matches[1])) return true;
        // If classes don't match, this selector might still match via other parts
        // but classes are the primary indicator — if a class doesn't exist, skip
        if (!empty($cls_matches[1])) return false;
    }

    // Extract IDs from selector (#idname)
    if (preg_match_all('/#([a-zA-Z_][a-zA-Z0-9_-]*)/', $selector, $id_matches)) {
        foreach ($id_matches[1] as $id) {
            if (isset($used['ids'][$id])) return true;
        }
        // ID specified but not found
        return false;
    }

    // Extract tag names from selector
    if (preg_match('/^([a-zA-Z][a-zA-Z0-9]*)/', $selector, $tag_match)) {
        $tag = strtolower($tag_match[1]);
        if (isset($used['tags'][$tag])) return true;
    }

    // Attribute selectors [data-xxx], [role=...], etc.
    if (preg_match_all('/\[([^\]]+)\]/', $selector, $attr_matches)) {
        foreach ($attr_matches[1] as $attr_expr) {
            $attr_name = preg_replace('/[~|^$*]?=.*$/', '', $attr_expr);
            $attr_name = strtolower(trim($attr_name, '"\''));
            if (isset($used['attrs'][$attr_name])) return true;
        }
    }

    // If we couldn't parse the selector, keep it (safe default)
    return true;
}


/**
 * Replace local <link rel="stylesheet"> tags with a single purged CSS file.
 */
function sropt_replace_stylesheets_with_purged($html, $purge_url, $options) {
    $excludes = array_filter(array_map('trim', explode(',', $options['exclude_css'])));
    $never_replace = array('admin-bar', 'dashicons', 'wp-admin');
    $site_host = parse_url(home_url(), PHP_URL_HOST);
    $replaced_count = 0;
    $insert_pos = null;

    $html = preg_replace_callback('/<link\b([^>]*rel\s*=\s*["\']stylesheet["\'][^>]*)>/i', function($matches) use ($excludes, $never_replace, $site_host, &$replaced_count, &$insert_pos) {
        $attrs = $matches[1];
        $href = '';
        if (preg_match('/href\s*=\s*["\']([^"\']+)["\']/i', $attrs, $href_match)) {
            $href = $href_match[1];
        }
        $handle = '';
        if (preg_match('/id\s*=\s*["\']([^"\']+)-css["\']/i', $attrs, $id_match)) {
            $handle = $id_match[1];
        }

        // Don't replace excluded, admin, or external stylesheets
        if (in_array($handle, $never_replace)) return $matches[0];
        foreach ($excludes as $exc) {
            if ($handle === $exc || strpos($href, $exc) !== false) return $matches[0];
        }

        // Only replace local stylesheets
        $href_host = parse_url($href, PHP_URL_HOST);
        if ($href_host && $href_host !== $site_host) return $matches[0];

        // Can we resolve this to a local file?
        $path = sropt_url_to_local_path($href);
        if (!$path || !file_exists($path)) return $matches[0];

        $replaced_count++;

        // Keep first replaced tag position for inserting purged link
        if ($replaced_count === 1) {
            return '<!--SEOROOM_PURGED_CSS_PLACEHOLDER-->';
        }

        // Remove subsequent local stylesheets (they're all merged into purged file)
        return '';
    }, $html);

    if ($replaced_count > 0) {
        // Insert the single purged CSS link where the first stylesheet was
        $purged_link = '<link rel="stylesheet" id="seoroom-purged-css" href="' . esc_url($purge_url) . '?v=' . SEOROOM_VERSION . '" media="all" />';
        $html = str_replace('<!--SEOROOM_PURGED_CSS_PLACEHOLDER-->', $purged_link, $html);
    }

    return $html;
}


// ================================================================
// JS OPTIMIZATION — DEFER/ASYNC
// ================================================================

add_filter('script_loader_tag', 'sropt_defer_js', 10, 3);
function sropt_defer_js($tag, $handle, $src) {
    if (is_admin()) return $tag;
    $options = sropt_get_options();
    if (!$options['enable_js_defer'] || $options['safe_mode']) return $tag;

    // jQuery will be delayed (not deferred) — skip defer for it so delay handler takes over
    $never_defer = array('jquery-core', 'jquery', 'jquery-migrate', 'wp-polyfill', 'wp-hooks', 'wp-i18n', 'underscore', 'backbone');
    if (in_array($handle, $never_defer)) return $tag;

    $excludes = array_filter(array_map('trim', explode(',', $options['exclude_js'])));
    foreach ($excludes as $exc) {
        if ($handle === $exc || strpos($src, $exc) !== false) return $tag;
    }

    if (preg_match('/\b(defer|async)\b/i', $tag)) return $tag;

    return str_replace(' src=', ' defer src=', $tag);
}


// ================================================================
// JS DELAY — Don't execute JS until user interaction (scroll/click/touch)
// Biggest single TBT improvement. Used by WP Rocket, FlyingPress, etc.
// ================================================================

// JS delay DISABLED — BerqWP handles JS optimization.
// add_action('template_redirect', 'sropt_delay_js_start', 2);
function sropt_delay_js_start() {
    // Disabled — BerqWP handles JS delay/defer
    return;

    $options = sropt_get_options();
    if (!$options['enable_js_delay'] || $options['safe_mode']) return;

    // Use output buffer to rewrite script tags
    ob_start('sropt_delay_js_rewrite');
}

function sropt_delay_js_rewrite($html) {
    if (empty($html) || strlen($html) < 200) return $html;
    if (stripos($html, '<html') === false && stripos($html, '<!DOCTYPE') === false) return $html;

    $options = sropt_get_options();
    $excludes = array_filter(array_map('trim', explode(',', $options['exclude_js'])));

    // Scripts that must NEVER be delayed (core functionality)
    // NOTE: jQuery IS delayed now — it loads first in the delay queue on user interaction
    // This is safe because all jQuery-dependent scripts are also delayed
    $never_delay = array(
        'wp-polyfill',
        'seoroom', // our own scripts
    );

    // Also never delay inline scripts that are critical for page rendering
    $never_delay_inline = array(
        'var wpApiSettings', 'var wc_', 'var elementorFrontendConfig',
        'window._wpemojiSettings', 'document.documentElement.className',
    );

    // Rewrite external scripts: change type to prevent execution
    $html = preg_replace_callback('/<script\b([^>]*)>(.*?)<\/script>/is', function($matches) use ($excludes, $never_delay, $never_delay_inline) {
        $attrs = $matches[1];
        $content = $matches[2];

        // Skip if already has our delay attribute
        if (strpos($attrs, 'data-seoroom-delay') !== false) return $matches[0];

        // Skip non-JS types (JSON-LD, templates, etc.)
        if (preg_match('/type\s*=\s*["\'](?!text\/javascript|application\/javascript|module)[^"\']*["\']/i', $attrs)) return $matches[0];

        // Check if it's an external script
        $is_external = preg_match('/\bsrc\s*=\s*["\']([^"\']+)["\']/i', $attrs, $src_match);
        $src = $is_external ? $src_match[1] : '';

        // Check never-delay list for external scripts
        if ($is_external) {
            foreach ($never_delay as $nd) {
                if (strpos($src, $nd) !== false) return $matches[0];
            }
            foreach ($excludes as $exc) {
                if (strpos($src, $exc) !== false) return $matches[0];
            }
        }

        // Check never-delay list for inline scripts
        if (!$is_external && !empty(trim($content))) {
            foreach ($never_delay_inline as $ndi) {
                if (strpos($content, $ndi) !== false) return $matches[0];
            }
            // Don't delay very short inline scripts (config/settings)
            if (strlen(trim($content)) < 100) return $matches[0];
        }

        // Skip scripts in <head> that set critical config (heuristic: before </head>)
        // We handle this via the never_delay_inline list above

        // Rewrite: change type to prevent execution, add data attribute
        if ($is_external) {
            // External: change type to text/seoroom-delay
            $new_attrs = preg_replace('/type\s*=\s*["\'][^"\']*["\']/i', '', $attrs);
            $new_attrs .= ' data-seoroom-delay="1" type="text/seoroom-delay"';
            return '<script' . $new_attrs . '>' . $content . '</script>';
        } else {
            // Inline: wrap in type=text/seoroom-delay
            $new_attrs = preg_replace('/type\s*=\s*["\'][^"\']*["\']/i', '', $attrs);
            $new_attrs .= ' data-seoroom-delay="1" type="text/seoroom-delay"';
            return '<script' . $new_attrs . '>' . $content . '</script>';
        }
    }, $html);

    // Inject the loader script right before </body>
    // jQuery loads first (priority sort), then all others sequentially
    $loader = '
<script id="seoroom-delay-loader">
(function(){
  var loaded=false;
  function loadAll(){
    if(loaded)return;loaded=true;
    var all=document.querySelectorAll("script[data-seoroom-delay]");
    // Sort: jQuery first, then jquery-migrate, then everything else
    var scripts=Array.prototype.slice.call(all);
    scripts.sort(function(a,b){
      var as=a.src||"",bs=b.src||"";
      var ap=as.indexOf("jquery.min")>-1||as.indexOf("jquery-core")>-1?0:as.indexOf("jquery-migrate")>-1?1:2;
      var bp=bs.indexOf("jquery.min")>-1||bs.indexOf("jquery-core")>-1?0:bs.indexOf("jquery-migrate")>-1?1:2;
      return ap-bp;
    });
    var i=0;
    function next(){
      if(i>=scripts.length)return;
      var s=scripts[i++];
      var n=document.createElement("script");
      if(s.src){n.src=s.src;n.onload=next;n.onerror=next;}
      else{n.textContent=s.textContent;setTimeout(next,0);}
      var attrs=s.attributes;
      for(var j=0;j<attrs.length;j++){
        var a=attrs[j].name;
        if(a!=="type"&&a!=="data-seoroom-delay")n.setAttribute(a,attrs[j].value);
      }
      s.parentNode.replaceChild(n,s);
      if(!s.src)next();
    }
    next();
  }
  var events=["mouseover","keydown","touchstart","touchmove","wheel","scroll","click"];
  events.forEach(function(e){window.addEventListener(e,loadAll,{once:true,passive:true});});
  // Fallback: load after 3 seconds (Lighthouse measures at ~3-5s mark)
  setTimeout(loadAll,3000);
})();
</script>';

    // Insert before </body>
    $body_close = strripos($html, '</body>');
    if ($body_close !== false) {
        $html = substr($html, 0, $body_close) . $loader . "\n" . substr($html, $body_close);
    }

    return $html;
}


// ================================================================
// CSS OPTIMIZATION — DEFER NON-CRITICAL (legacy, use Critical CSS instead)
// ================================================================

add_filter('style_loader_tag', 'sropt_optimize_css_tag', 10, 4);
function sropt_optimize_css_tag($tag, $handle, $href, $media) {
    if (is_admin()) return $tag;
    $options = sropt_get_options();
    if ($options['safe_mode']) return $tag;

    // If critical CSS is enabled, it handles deferral in the output buffer — skip here
    if ($options['enable_critical_css']) return $tag;

    // Legacy CSS defer (only active when critical CSS is off)
    if (!$options['enable_css_defer']) return $tag;

    $excludes = array_filter(array_map('trim', explode(',', $options['exclude_css'])));
    foreach ($excludes as $exc) {
        if ($handle === $exc || strpos($href, $exc) !== false) return $tag;
    }

    $never_defer_css = array(
        'wp-block-library', 'global-styles', 'theme-style', 'style',
        'elementor-frontend', 'elementor-common', 'elementor-icons',
        'astra-theme-css', 'generatepress',
    );
    if (in_array($handle, $never_defer_css)) return $tag;

    $tag = str_replace("media='all'", "media='print' onload=\"this.media='all'\"", $tag);
    $tag = str_replace('media="all"', 'media="print" onload="this.media=\'all\'"', $tag);
    return $tag;
}


// ================================================================
// HTACCESS — GZIP & BROWSER CACHE HEADERS
// ================================================================

function sropt_write_htaccess_rules($options = null) {
    if (!$options) $options = sropt_get_options();
    if (!function_exists('get_home_path')) require_once ABSPATH . 'wp-admin/includes/file.php';

    $htaccess_file = get_home_path() . '.htaccess';
    if (!file_exists($htaccess_file) || !is_writable($htaccess_file)) return false;

    $rules = "\n# BEGIN SEO Room\n";

    // Page Cache — serve cached HTML directly from Apache (zero PHP)
    if ($options['enable_page_cache'] && !$options['safe_mode']) {
        $cache_path = str_replace(ABSPATH, '', WP_CONTENT_DIR) . '/cache/seoroom/pages';
        $rules .= "# Page Cache — zero-PHP serving\n";
        $rules .= "<IfModule mod_rewrite.c>\n";
        $rules .= "  RewriteEngine On\n";
        $rules .= "  # Skip logged-in users\n";
        $rules .= "  RewriteCond %{HTTP_COOKIE} !wordpress_logged_in_ [NC]\n";
        $rules .= "  RewriteCond %{HTTP_COOKIE} !comment_author_ [NC]\n";
        $rules .= "  RewriteCond %{HTTP_COOKIE} !wp-postpass_ [NC]\n";
        $rules .= "  # Only GET requests\n";
        $rules .= "  RewriteCond %{REQUEST_METHOD} GET\n";
        $rules .= "  # Skip admin, login, API, feeds\n";
        $rules .= "  RewriteCond %{REQUEST_URI} !^/wp-admin [NC]\n";
        $rules .= "  RewriteCond %{REQUEST_URI} !^/wp-login [NC]\n";
        $rules .= "  RewriteCond %{REQUEST_URI} !^/wp-json [NC]\n";
        $rules .= "  RewriteCond %{REQUEST_URI} !^/wp-cron [NC]\n";
        $rules .= "  RewriteCond %{REQUEST_URI} !/feed [NC]\n";
        $rules .= "  RewriteCond %{REQUEST_URI} !/cart [NC]\n";
        $rules .= "  RewriteCond %{REQUEST_URI} !/checkout [NC]\n";
        $rules .= "  RewriteCond %{REQUEST_URI} !/my-account [NC]\n";
        $rules .= "  # Check if cache file exists (directory-based: /host/path/_index.html)\n";
        $rules .= "  RewriteCond %{DOCUMENT_ROOT}/" . $cache_path . "/%{HTTP_HOST}%{REQUEST_URI}/_index.html -f\n";
        $rules .= "  RewriteRule ^(.*)$ /" . $cache_path . "/%{HTTP_HOST}%{REQUEST_URI}/_index.html [L,T=text/html]\n";
        $rules .= "</IfModule>\n\n";
    }

    if ($options['enable_gzip']) {
        $rules .= "<IfModule mod_deflate.c>\n";
        $rules .= "  AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript\n";
        $rules .= "  AddOutputFilterByType DEFLATE application/javascript application/x-javascript application/json\n";
        $rules .= "  AddOutputFilterByType DEFLATE application/xml application/xhtml+xml application/rss+xml\n";
        $rules .= "  AddOutputFilterByType DEFLATE image/svg+xml image/x-icon\n";
        $rules .= "  AddOutputFilterByType DEFLATE font/ttf font/otf font/woff font/woff2\n";
        $rules .= "</IfModule>\n\n";
    }

    if ($options['enable_cache_headers']) {
        $rules .= "<IfModule mod_expires.c>\n";
        $rules .= "  ExpiresActive On\n";
        $rules .= "  ExpiresByType text/css \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType application/javascript \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType application/x-javascript \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType image/jpeg \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType image/png \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType image/gif \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType image/webp \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType image/avif \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType image/svg+xml \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType image/x-icon \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType font/woff2 \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType font/woff \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType font/ttf \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType font/otf \"access plus 1 year\"\n";
        $rules .= "  ExpiresByType text/html \"access plus 1 hour\"\n";
        $rules .= "</IfModule>\n\n";

        $rules .= "<IfModule mod_headers.c>\n";
        $rules .= "  <FilesMatch \"\\.(css|js|jpg|jpeg|png|gif|webp|avif|svg|ico|woff2|woff|ttf|otf)$\">\n";
        $rules .= "    Header set Cache-Control \"public, max-age=31536000, immutable\"\n";
        $rules .= "  </FilesMatch>\n";
        $rules .= "  <FilesMatch \"\\.(html|htm)$\">\n";
        $rules .= "    Header set Cache-Control \"public, max-age=3600, must-revalidate\"\n";
        $rules .= "  </FilesMatch>\n";
        $rules .= "</IfModule>\n";
    }

    $rules .= "# END SEO Room\n";

    $existing = file_get_contents($htaccess_file);
    $existing = preg_replace('/\n?# BEGIN SEO Room\b.*?# END SEO Room\n?/s', '', $existing);

    if (($wp_pos = strpos($existing, '# BEGIN WordPress')) !== false) {
        $existing = substr($existing, 0, $wp_pos) . $rules . "\n" . substr($existing, $wp_pos);
    } else {
        $existing = $rules . "\n" . $existing;
    }

    file_put_contents($htaccess_file, $existing);
    return true;
}

function sropt_remove_htaccess_rules() {
    if (!function_exists('get_home_path')) require_once ABSPATH . 'wp-admin/includes/file.php';
    $htaccess_file = get_home_path() . '.htaccess';
    if (!file_exists($htaccess_file) || !is_writable($htaccess_file)) return;
    $existing = file_get_contents($htaccess_file);
    $existing = preg_replace('/\n?# BEGIN SEO Room\b.*?# END SEO Room\n?/s', '', $existing);
    file_put_contents($htaccess_file, $existing);
}

add_action('admin_init', function() {
    if (get_transient('sropt_htaccess_written')) return;
    $options = sropt_get_options();
    if ($options['enable_gzip'] || $options['enable_cache_headers']) {
        if (!function_exists('get_home_path')) require_once ABSPATH . 'wp-admin/includes/file.php';
        sropt_write_htaccess_rules($options);
        set_transient('sropt_htaccess_written', true, DAY_IN_SECONDS);
    }
});


// ================================================================
// PRELOAD LCP IMAGE — Rendered HTML detection (universal)
// ================================================================
// Instead of guessing at wp_head time, we inject the preload tag via
// the output buffer AFTER the full HTML is rendered. This catches:
//   - Elementor background images (inline style or data-settings)
//   - Theme page-header backgrounds (Onum, Astra, etc.)
//   - Featured images, hero <img> tags
//   - Any CSS background-image in the above-fold area
// The wp_head hook is kept as an early hint for simple cases.

add_action('wp_head', 'sropt_preload_hints', 1);
function sropt_preload_hints() {
    if (is_admin()) return;
    $options = sropt_get_options();
    if (!$options['enable_lcp_preload']) return;

    $preload_url = '';

    if (is_singular()) {
        $post = get_post();

        // 1. Check Elementor data for hero background image
        if (!$preload_url && $post) {
            $elementor_data = get_post_meta($post->ID, '_elementor_data', true);
            if ($elementor_data && is_string($elementor_data)) {
                $data = json_decode($elementor_data, true);
                if (is_array($data)) {
                    $checked = 0;
                    foreach ($data as $element) {
                        if ($checked >= 3) break;
                        $bg_url = sropt_find_elementor_bg($element, 0);
                        if ($bg_url) { $preload_url = $bg_url; break; }
                        $checked++;
                    }
                }
            }
        }

        // 2. Try post thumbnail (featured image)
        if (!$preload_url && has_post_thumbnail()) {
            $thumb_id = get_post_thumbnail_id();
            $thumb_url = wp_get_attachment_image_url($thumb_id, 'full');
            if ($thumb_url) $preload_url = $thumb_url;
        }
    }

    // Store early-detected URL for the output buffer to use/override
    $GLOBALS['sropt_lcp_early'] = $preload_url;

    // Check if the output buffer will run (it handles the real detection)
    $options2 = sropt_get_options();
    $is_safe = $options2['safe_mode'];
    $buffer_active = (!$is_safe && ($options2['enable_css_minify'] || $options2['enable_js_minify'] || $options2['enable_critical_css'] || $options2['enable_unused_css']))
        || $options2['enable_font_swap'] || $options2['enable_preconnect'] || $options2['enable_dns_prefetch'];

    // Only emit from wp_head if the output buffer WON'T run (safe mode, no options)
    // When buffer runs, it will inject the preload after seeing the full HTML
    if (!$buffer_active && $preload_url) {
        $type = '';
        if (preg_match('/\.webp(\?|$)/i', $preload_url)) $type = ' type="image/webp"';
        elseif (preg_match('/\.png(\?|$)/i', $preload_url)) $type = ' type="image/png"';
        echo '<link rel="preload" as="image" href="' . esc_url($preload_url) . '"' . $type . ' fetchpriority="high">' . "\n";
    }
}

/**
 * Output buffer handler: scan rendered HTML for the actual LCP image.
 * Runs AFTER the full page is rendered so we can see theme headers,
 * inline styles, and all images.
 */
function sropt_lcp_buffer_handler($html) {
    // LCP handler disabled — the regex-based HTML rewriting causes layout shifts
    // and performance regressions on sites with BerqWP. The wp_head hook
    // (sropt_lcp_preload_head) handles simple preload cases instead.
    return $html;

    if (is_admin() || empty($html)) return $html;
    $options = sropt_get_options();
    if (!$options['enable_lcp_preload']) return $html;

    $debug_info = array('handler' => 'running');

    // Don't skip even if BerqWP has a preload — BerqWP may preload the wrong image
    // and still lazy-load the hero background via lazy-berqwpbg class.
    // We check later to avoid duplicate preload tags.
    $has_existing_preload = preg_match('/<link[^>]*rel=["\']preload["\'][^>]*fetchpriority=["\']high["\']/i', $html);

    $preload_url = '';

    // Strategy 1: Find background-image in page-header/hero/banner sections
    // Use a simpler, more robust approach: first find the hero element, then extract URL from it
    $hero_element = '';
    if (preg_match('/<(?:div|section|header)\b[^>]*class="[^"]*(?:page-header|hero|banner|masthead)[^"]*"[^>]*>/i', $html, $hero_match)) {
        $hero_element = $hero_match[0];
        $debug_info['hero_found'] = substr($hero_element, 0, 80);
        // Extract background-image URL from the hero element's style attribute
        // Handle: url("..."), url('...'), url(...), url(&quot;...&quot;)
        if (preg_match('/background-image:\s*url\((?:&quot;|["\'])?([^"\')\s&>]+)/i', $hero_element, $url_match)) {
            $url = $url_match[1];
            $debug_info['hero_url'] = substr($url, 0, 60);
            if (preg_match('/\.(jpg|jpeg|png|webp|avif)/i', $url)) {
                $preload_url = $url;
                $debug_info['strategy'] = 1;
            }
        } else {
            $debug_info['hero_no_bg'] = true;
        }
    }

    // Also check Elementor sections
    if (!$preload_url) {
        if (preg_match('/<(?:div|section)\b[^>]*class="[^"]*elementor-(?:section|top-section|element)[^"]*"[^>]*style="[^"]*background-image:\s*url\((?:&quot;|["\'])?([^"\')\s&>]+)/i', $html, $el_match)) {
            $url = $el_match[1];
            if (preg_match('/\.(jpg|jpeg|png|webp|avif)/i', $url)) {
                $preload_url = $url;
                $debug_info['strategy'] = '1e';
            }
        }
    }

    // Strategy 2: Find theme CSS background in <style> tags for page-header
    if (!$preload_url) {
        $q = '(?:&quot;|["\'])';
        if (preg_match('/\.page-header\s*\{[^}]*background(?:-image)?\s*:[^}]*url\(' . $q . '?([^"\')\s&]+)' . $q . '?\)/i', $html, $m)) {
            if (preg_match('/\.(jpg|jpeg|png|webp|avif)/i', $m[1])) {
                $preload_url = $m[1];
            }
        }
    }

    // Strategy 3: Use the early-detected URL (Elementor data or featured image)
    if (!$preload_url && !empty($GLOBALS['sropt_lcp_early'])) {
        $preload_url = $GLOBALS['sropt_lcp_early'];
    }

    // Strategy 4: First large <img> in the top portion of HTML (first 5000 chars after <body>)
    if (!$preload_url) {
        $body_pos = stripos($html, '<body');
        $top_html = $body_pos !== false ? substr($html, $body_pos, 5000) : substr($html, 0, 8000);
        if (preg_match_all('/<img\b[^>]*\bsrc\s*=\s*["\']([^"\']+)["\'][^>]*>/i', $top_html, $img_matches)) {
            foreach ($img_matches[1] as $src) {
                // Skip tiny/icon images by filename pattern
                if (preg_match('/(\d+)x(\d+)/', $src, $dims)) {
                    if (intval($dims[1]) < 400 && intval($dims[2]) < 400) continue;
                }
                if (preg_match('/(gravatar|avatar|icon|logo|pixel|tracking|badge|button|spinner)/i', $src)) continue;
                $preload_url = $src;
                break;
            }
        }
    }

    // === CRITICAL: Strip BerqWP lazy-bg classes from hero/LCP elements ===
    // BerqWP adds lazy-berqwpbg (and similar) to background-image elements,
    // lazy-loading them via JS. This adds ~600ms resource load delay to LCP.
    // Strip these classes from page-header/hero/banner containers ALWAYS,
    // regardless of whether we found a preload_url.
    $lazy_bg_classes = 'lazy-berqwpbg|lazy-bg|lazyload-bg';
    $hero_selectors = 'page-header|single-page-header|hero|banner|masthead';
    $html = preg_replace_callback(
        '/<(div|section|header)\b([^>]*class="[^"]*(?:' . $hero_selectors . ')[^"]*"[^>]*)>/i',
        function($m) use ($lazy_bg_classes) {
            $tag = $m[1];
            $attrs = $m[2];
            // Strip lazy-bg class names
            $attrs = preg_replace('/\b(' . $lazy_bg_classes . ')\b/i', '', $attrs);
            // Clean up double spaces in class attr
            $attrs = preg_replace('/class="([^"]*)"/i', '', $attrs, -1, $count, 0);
            // Re-extract and clean class value
            if (preg_match('/class="([^"]*)"/i', $m[2], $cls)) {
                $clean = preg_replace('/\b(' . $lazy_bg_classes . ')\b/i', '', $cls[1]);
                $clean = preg_replace('/\s+/', ' ', trim($clean));
                $attrs = preg_replace('/class="[^"]*"/i', 'class="' . $clean . '"', $m[2]);
            }
            return '<' . $tag . $attrs . '>';
        },
        $html
    );

    // Also strip lazy-berqwpbg from ANY element that has the LCP background-image URL
    if ($preload_url) {
        $escaped_bg = preg_quote($preload_url, '/');
        $html = preg_replace_callback(
            '/<(div|section|header)\b([^>]*style="[^"]*' . $escaped_bg . '[^"]*"[^>]*)>/i',
            function($m) use ($lazy_bg_classes) {
                $tag = $m[1];
                $attrs = $m[2];
                if (preg_match('/class="([^"]*)"/i', $attrs, $cls)) {
                    $clean = preg_replace('/\b(' . $lazy_bg_classes . ')\b/i', '', $cls[1]);
                    $clean = preg_replace('/\s+/', ' ', trim($clean));
                    $attrs = preg_replace('/class="[^"]*"/i', 'class="' . $clean . '"', $attrs);
                }
                return '<' . $tag . $attrs . '>';
            },
            $html
        );
    }

    // === LCP BOOST: modify HTML for faster LCP ===
    if ($preload_url) {
        // Add preconnect to BerqWP CDN if the LCP URL is from their CDN
        $preconnect = '';
        if (preg_match('#https?://([^/]+\.cdn\.digitaloceanspaces\.com)#i', $preload_url, $cdn_m)) {
            $cdn_origin = 'https://' . $cdn_m[1];
            // Only add if not already present
            if (stripos($html, $cdn_origin) === false || !preg_match('/<link[^>]*rel=["\']preconnect["\'][^>]*' . preg_quote($cdn_m[1], '/') . '/i', $html)) {
                $preconnect = '<link rel="preconnect" href="' . $cdn_origin . '" crossorigin>' . "\n";
            }
        }

        $type = '';
        if (preg_match('/\.webp(\?|$)/i', $preload_url)) $type = ' type="image/webp"';
        elseif (preg_match('/\.png(\?|$)/i', $preload_url)) $type = ' type="image/png"';
        elseif (preg_match('/\.svg(\?|$)/i', $preload_url)) $type = ' type="image/svg+xml"';

        // Only add preload if BerqWP doesn't already have one for this URL
        $skip_preload = false;
        if ($has_existing_preload) {
            $escaped_check = preg_quote($preload_url, '/');
            if (preg_match('/<link[^>]*rel=["\']preload["\'][^>]*href=["\'][^"\']*' . $escaped_check . '/i', $html)) {
                $skip_preload = true; // BerqWP already preloads this exact URL
            }
        }

        if (!$skip_preload) {
            $tag = '<link rel="preload" as="image" href="' . esc_url($preload_url) . '"' . $type . ' fetchpriority="high">' . "\n";
        } else {
            $tag = '';
        }

        // Insert preconnect + preload after <meta charset> or at start of <head>
        $inject = $preconnect . $tag;
        if ($inject) {
            if (preg_match('/<meta[^>]*charset[^>]*>/i', $html, $meta_match, PREG_OFFSET_CAPTURE)) {
                $pos = $meta_match[0][1] + strlen($meta_match[0][0]);
                $html = substr($html, 0, $pos) . "\n" . $inject . substr($html, $pos);
            } elseif (($head_pos = stripos($html, '<head>')) !== false) {
                $html = substr($html, 0, $head_pos + 6) . "\n" . $inject . substr($html, $head_pos + 6);
            }
        }

        // A) Add fetchpriority="high" to the actual LCP <img> element (if LCP is an image tag)
        //    Also remove loading="lazy" which kills LCP
        $escaped_url = preg_quote($preload_url, '/');
        if (preg_match('/<img\b[^>]*src=["\']' . $escaped_url . '["\'][^>]*>/i', $html, $img_match, PREG_OFFSET_CAPTURE)) {
            $img_tag = $img_match[0][0];
            $img_pos = $img_match[0][1];
            $new_tag = $img_tag;
            $new_tag = preg_replace('/\s*loading\s*=\s*["\']lazy["\']/i', '', $new_tag);
            if (!preg_match('/fetchpriority/i', $new_tag)) {
                $new_tag = preg_replace('/<img\b/i', '<img fetchpriority="high"', $new_tag);
            }
            if (!preg_match('/loading\s*=/i', $new_tag)) {
                $new_tag = preg_replace('/<img\b/i', '<img loading="eager"', $new_tag);
            }
            if ($new_tag !== $img_tag) {
                $html = substr($html, 0, $img_pos) . $new_tag . substr($html, $img_pos + strlen($img_tag));
            }
        }

        // B) Inject hidden <img> for background-image LCP elements
        //    If the LCP is a CSS background-image (not an <img> tag), inject a hidden
        //    <img> right after <body> with fetchpriority="high". The browser discovers
        //    it immediately, starts loading, and it's cached by the time the
        //    background-image renders. Zero visual/layout impact.
        // Check if LCP is a background-image (not an <img> tag)
        $is_bg_lcp = !empty($hero_element) || preg_match('/\.page-header\s*\{[^}]*background(?:-image)?\s*:[^}]*url\(/i', $html);
        if ($is_bg_lcp) {
            $hidden_img = '<img src="' . esc_url($preload_url) . '" fetchpriority="high" loading="eager" aria-hidden="true" alt="" style="position:absolute;width:0;height:0;overflow:hidden;clip:rect(0,0,0,0);pointer-events:none">';
            // Insert right after the opening <body...> tag
            if (preg_match('/<body\b[^>]*>/i', $html, $body_match, PREG_OFFSET_CAPTURE)) {
                $body_end = $body_match[0][1] + strlen($body_match[0][0]);
                $html = substr($html, 0, $body_end) . "\n" . $hidden_img . "\n" . substr($html, $body_end);
            }
        }

        // C) For ALL above-fold images (first 2 after <body>): remove lazy, add eager
        $body_start = stripos($html, '<body');
        if ($body_start !== false) {
            $above_fold = substr($html, $body_start, 6000);
            $af_count = 0;
            $above_fold = preg_replace_callback('/<img\b([^>]*)>/i', function($m) use (&$af_count) {
                $af_count++;
                if ($af_count > 2) return $m[0];
                $attrs = $m[1];
                $attrs = preg_replace('/\s*loading\s*=\s*["\']lazy["\']/i', '', $attrs);
                if (!preg_match('/loading\s*=/i', $attrs)) {
                    $attrs = ' loading="eager"' . $attrs;
                }
                if ($af_count === 1 && !preg_match('/fetchpriority/i', $attrs)) {
                    $attrs = ' fetchpriority="high"' . $attrs;
                }
                return '<img' . $attrs . '>';
            }, $above_fold);
            $html = substr($html, 0, $body_start) . $above_fold . substr($html, $body_start + 6000);
        }
    }

    // Debug comment (remove after testing)
    $debug_info['preload_url'] = $preload_url ? substr($preload_url, -30) : 'none';
    $html = str_replace('</head>', '<meta name="sropt-lcp-debug" content="' . esc_attr(json_encode($debug_info)) . '">' . "\n" . '</head>', $html);

    return $html;
}

// Note: sropt_lcp_buffer_handler is called from sropt_process_html (output buffer).
// When the buffer isn't active (safe mode), the wp_head hook handles simple cases.

/**
 * Recursively search Elementor element data for a background image URL.
 */
function sropt_find_elementor_bg($element, $depth) {
    if ($depth > 2 || !is_array($element)) return '';
    $settings = isset($element['settings']) ? $element['settings'] : array();

    if (!empty($settings['background_image']['url'])) {
        $url = $settings['background_image']['url'];
        if (preg_match('/\.(jpg|jpeg|png|webp|avif)/i', $url)) return $url;
    }

    if (!empty($settings['background_slideshow_gallery']) && is_array($settings['background_slideshow_gallery'])) {
        $first = $settings['background_slideshow_gallery'][0];
        if (!empty($first['url']) && preg_match('/\.(jpg|jpeg|png|webp|avif)/i', $first['url'])) return $first['url'];
    }

    if (!empty($element['elements']) && is_array($element['elements'])) {
        $checked = 0;
        foreach ($element['elements'] as $child) {
            if ($checked >= 3) break;
            $url = sropt_find_elementor_bg($child, $depth + 1);
            if ($url) return $url;
            $checked++;
        }
    }
    return '';
}


// ================================================================
// REMOVE WORDPRESS BLOAT
// ================================================================

add_action('init', 'sropt_remove_bloat');
function sropt_remove_bloat() {
    if (is_admin()) return;

    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'rsd_link');
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'wp_shortlink_wp_head');

    add_action('pre_ping', function(&$links) {
        $home = home_url();
        foreach ($links as $l => $link) {
            if (strpos($link, $home) === 0) unset($links[$l]);
        }
    });
}

add_filter('emoji_svg_url', '__return_false');

// Remove jQuery Migrate
add_action('wp_default_scripts', function($scripts) {
    if (is_admin()) return;
    if (isset($scripts->registered['jquery'])) {
        $script = $scripts->registered['jquery'];
        if ($script->deps) {
            $script->deps = array_diff($script->deps, array('jquery-migrate'));
        }
    }
});


// ================================================================
// ADMIN BAR STATUS
// ================================================================

add_action('admin_bar_menu', 'sropt_admin_bar', 999);
function sropt_admin_bar($wp_admin_bar) {
    if (!current_user_can('manage_options')) return;
    $options = sropt_get_options();
    $status = $options['safe_mode'] ? '⚡ Safe' : '⚡ Active';
    $wp_admin_bar->add_node(array(
        'id'    => 'seoroom',
        'title' => 'SEO Room: ' . $status,
        'href'  => admin_url('options-general.php?page=seoroom'),
        'meta'  => array('title' => 'SEO Room v' . SEOROOM_VERSION . ' — Speed + Schema + Critical CSS'),
    ));
}


// ================================================================
// PAGE CACHE — .htaccess mod_rewrite (serves cached HTML with ZERO PHP)
// ================================================================

// Strip tracking params from URI for consistent cache keys
function sropt_clean_uri($uri) {
    $path = parse_url($uri, PHP_URL_PATH);
    $query = parse_url($uri, PHP_URL_QUERY);
    if (empty($query)) return $path;
    // Remove tracking params — keep functional params only
    $tracking = array('utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content',
        'fbclid', 'gclid', 'gclsrc', 'msclkid', 'dclid', 'wbraid', 'gbraid',
        'mc_cid', 'mc_eid', 'ref', '_ga', 'hsa_acc', 'hsa_cam', 'hsa_grp',
        'hsa_ad', 'hsa_src', 'hsa_net', 'hsa_ver', 'hsa_la', 'hsa_ol', 'hsa_mt', 'hsa_kw', 'hsa_tgt');
    parse_str($query, $params);
    foreach ($tracking as $t) unset($params[$t]);
    if (empty($params)) return $path;
    return $path . '?' . http_build_query($params);
}

// Cache path helper — directory-based so Apache mod_rewrite can serve directly
function sropt_page_cache_path() {
    $clean_uri = sropt_clean_uri($_SERVER['REQUEST_URI']);
    $path = parse_url($clean_uri, PHP_URL_PATH);
    $host = preg_replace('/[^a-zA-Z0-9._-]/', '', $_SERVER['HTTP_HOST'] ?? 'default');
    // Convert /path/to/page/ into /path/to/page/_index.html
    $safe_path = rtrim($path, '/');
    if (empty($safe_path)) $safe_path = '';
    $dir = WP_CONTENT_DIR . '/cache/seoroom/pages/' . $host . $safe_path . '/';
    if (!file_exists($dir)) wp_mkdir_p($dir);
    return $dir . '_index.html';
}

// After the output buffer processes HTML, save to page cache
add_action('shutdown', 'sropt_page_cache_save', 999);
function sropt_page_cache_save() {
    if (is_admin() || is_user_logged_in()) return;
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') return;
    if (defined('DOING_CRON') && DOING_CRON) return;
    if (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) return;

    $options = sropt_get_options();
    if (!$options['enable_page_cache'] || $options['safe_mode']) return;

    // Skip if already served from cache
    $headers = headers_list();
    foreach ($headers as $h) {
        if (stripos($h, 'X-SEORoom-Cache: HIT') !== false) return;
    }

    $request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $excludes = array_filter(array_map('trim', explode(',', $options['cache_exclude_urls'])));
    foreach ($excludes as $exc) {
        if ($exc && strpos($request_uri, $exc) !== false) return;
    }
    $never_cache = array('/wp-admin', '/wp-login', '/cart', '/checkout', '/my-account', '/wp-json', '/feed', '/wp-cron', '/xmlrpc');
    foreach ($never_cache as $nc) {
        if (strpos($request_uri, $nc) !== false) return;
    }

    // Skip non-200 responses
    $status = http_response_code();
    if ($status && $status !== 200) return;

    $cache_file = sropt_page_cache_path();
    if (!$cache_file) return;

    $content = '';
    $levels = ob_get_level();
    if ($levels > 0) {
        $content = ob_get_contents();
    }

    if (empty($content) || strlen($content) < 200) return;
    if (stripos($content, '<html') === false) return;
    // Don't cache pages with no-cache headers
    foreach ($headers as $h) {
        if (stripos($h, 'no-cache') !== false || stripos($h, 'no-store') !== false) return;
    }

    $content .= "\n<!-- Cached by SEO Room v" . SEOROOM_VERSION . " at " . gmdate('Y-m-d H:i:s') . " UTC -->";
    @file_put_contents($cache_file, $content);
}

// Serve cached page early (fallback if .htaccess rewrite isn't available — e.g. Nginx)
add_action('template_redirect', 'sropt_page_cache_serve_fallback', 0);
function sropt_page_cache_serve_fallback() {
    if (is_admin() || is_feed() || wp_doing_ajax()) return;
    if (defined('DOING_CRON') && DOING_CRON) return;
    if (is_user_logged_in()) return;
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') return;

    $options = sropt_get_options();
    if (!$options['enable_page_cache'] || $options['safe_mode']) return;

    $request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $never_cache = array('/wp-admin', '/wp-login', '/cart', '/checkout', '/my-account', '/wp-json', '/feed');
    foreach ($never_cache as $nc) {
        if (strpos($request_uri, $nc) !== false) return;
    }

    $cache_file = sropt_page_cache_path();
    if ($cache_file && file_exists($cache_file)) {
        $age = time() - filemtime($cache_file);
        if ($age < (int)$options['page_cache_ttl']) {
            header('X-SEORoom-Cache: HIT');
            header('X-SEORoom-Cache-Age: ' . $age . 's');
            readfile($cache_file);
            exit;
        } else {
            @unlink($cache_file);
        }
    }
}

// Clear page cache when content is updated
add_action('save_post', 'sropt_clear_page_cache', 10, 1);
add_action('comment_post', 'sropt_clear_page_cache');
add_action('transition_comment_status', 'sropt_clear_page_cache');
function sropt_clear_page_cache($post_id = 0) {
    $base_dir = WP_CONTENT_DIR . '/cache/seoroom/pages/';
    if (!file_exists($base_dir)) return;

    if ($post_id && is_numeric($post_id)) {
        $host = preg_replace('/[^a-zA-Z0-9._-]/', '', parse_url(home_url(), PHP_URL_HOST));
        // Clear specific page cache
        $url = get_permalink($post_id);
        if ($url) {
            $uri = rtrim(parse_url($url, PHP_URL_PATH), '/');
            $cache_file = $base_dir . $host . $uri . '/_index.html';
            if (file_exists($cache_file)) @unlink($cache_file);
        }
        // Also clear homepage
        $home_file = $base_dir . $host . '/_index.html';
        if (file_exists($home_file)) @unlink($home_file);
    } else {
        // Clear all page cache (recursive)
        $iter = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($base_dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($iter as $item) {
            if ($item->isFile() && $item->getExtension() === 'html') @unlink($item->getPathname());
        }
    }

    // Also clear critical CSS cache on content update
    $critical_dir = WP_CONTENT_DIR . '/cache/seoroom/critical/';
    if (file_exists($critical_dir)) {
        $files = glob($critical_dir . '*.css');
        if ($files) array_map('unlink', $files);
    }
}



// ================================================================
// WEBP IMAGE CONVERSION — Convert on-the-fly, cache to disk
// ================================================================

add_filter('the_content', 'sropt_webp_images', 997);
add_filter('post_thumbnail_html', 'sropt_webp_images', 997);
add_filter('widget_text', 'sropt_webp_images', 997);

function sropt_webp_images($content) {
    if (is_admin() || is_feed() || wp_doing_ajax()) return $content;
    $options = sropt_get_options();
    if (!$options['enable_webp']) return $content;

    if (!sropt_can_create_webp()) return $content;

    $content = preg_replace_callback('/<img\b([^>]*)\bsrc\s*=\s*["\']([^"\']+)["\']([^>]*)>/i', function($matches) use ($options) {
        $before = $matches[1];
        $src = $matches[2];
        $after = $matches[3];

        if (!preg_match('/\.(jpe?g|png)(\?.*)?$/i', $src)) return $matches[0];
        $upload_dir = wp_upload_dir();
        $upload_url = $upload_dir['baseurl'];
        if (strpos($src, $upload_url) === false && strpos($src, '/wp-content/uploads/') === false) return $matches[0];

        $webp_url = sropt_get_webp_url($src, (int)$options['webp_quality']);
        if (!$webp_url) return $matches[0];

        $full_attrs = $before . ' src="' . $src . '"' . $after;
        $srcset_webp = '';
        if (preg_match('/\bsrcset\s*=\s*["\']([^"\']+)["\']/i', $full_attrs, $srcset_match)) {
            $srcset_entries = explode(',', $srcset_match[1]);
            $webp_entries = array();
            foreach ($srcset_entries as $entry) {
                $entry = trim($entry);
                $parts = preg_split('/\s+/', $entry);
                if (count($parts) >= 2 && preg_match('/\.(jpe?g|png)/i', $parts[0])) {
                    $w_url = sropt_get_webp_url($parts[0], (int)$options['webp_quality']);
                    if ($w_url) $parts[0] = $w_url;
                }
                $webp_entries[] = implode(' ', $parts);
            }
            $srcset_webp = implode(', ', $webp_entries);
        }

        $picture = '<picture>';
        if ($srcset_webp) {
            $picture .= '<source type="image/webp" srcset="' . esc_attr($srcset_webp) . '"';
            if (preg_match('/\bsizes\s*=\s*["\']([^"\']+)["\']/i', $full_attrs, $sizes_match)) {
                $picture .= ' sizes="' . esc_attr($sizes_match[1]) . '"';
            }
            $picture .= '>';
        } else {
            $picture .= '<source type="image/webp" srcset="' . esc_attr($webp_url) . '">';
        }
        $picture .= $matches[0];
        $picture .= '</picture>';
        return $picture;
    }, $content);

    return $content;
}

function sropt_can_create_webp() {
    static $can = null;
    if ($can !== null) return $can;

    if (function_exists('imagewebp') && function_exists('imagecreatefromjpeg')) {
        $can = true;
    } elseif (class_exists('Imagick')) {
        $formats = Imagick::queryFormats('WEBP');
        $can = !empty($formats);
    } else {
        $can = false;
    }
    return $can;
}

function sropt_get_webp_url($src_url, $quality = 80) {
    $upload_dir = wp_upload_dir();
    $upload_url = $upload_dir['baseurl'];
    $upload_path = $upload_dir['basedir'];

    if (strpos($src_url, $upload_url) !== false) {
        $relative = str_replace($upload_url, '', $src_url);
    } elseif (preg_match('#/wp-content/uploads/(.+)#', $src_url, $m)) {
        $relative = '/' . $m[1];
    } else {
        return false;
    }

    $relative = preg_replace('/\?.*$/', '', $relative);
    $src_path = $upload_path . $relative;
    if (!file_exists($src_path)) return false;

    $webp_relative = preg_replace('/\.(jpe?g|png)$/i', '.webp', $relative);
    $webp_dir = WP_CONTENT_DIR . '/cache/seoroom/webp';
    $webp_path = $webp_dir . $webp_relative;

    if (file_exists($webp_path) && filemtime($webp_path) >= filemtime($src_path)) {
        return content_url('/cache/seoroom/webp' . $webp_relative);
    }

    $webp_subdir = dirname($webp_path);
    if (!file_exists($webp_subdir)) wp_mkdir_p($webp_subdir);

    $ext = strtolower(pathinfo($src_path, PATHINFO_EXTENSION));
    $created = false;

    if (function_exists('imagewebp')) {
        if ($ext === 'png') {
            $img = @imagecreatefrompng($src_path);
            if ($img) {
                imagepalettetotruecolor($img);
                imagealphablending($img, true);
                imagesavealpha($img, true);
            }
        } else {
            $img = @imagecreatefromjpeg($src_path);
        }
        if ($img) {
            $created = @imagewebp($img, $webp_path, $quality);
            imagedestroy($img);
        }
    } elseif (class_exists('Imagick')) {
        try {
            $im = new Imagick($src_path);
            $im->setImageFormat('webp');
            $im->setImageCompressionQuality($quality);
            $created = $im->writeImage($webp_path);
            $im->clear();
            $im->destroy();
        } catch (Exception $e) {
            $created = false;
        }
    }

    if (!$created || !file_exists($webp_path)) return false;

    if (filesize($webp_path) >= filesize($src_path)) {
        @unlink($webp_path);
        return false;
    }

    return content_url('/cache/seoroom/webp' . $webp_relative);
}


// ================================================================
// REST API STATUS ENDPOINT
// ================================================================

add_action('rest_api_init', function() {
    register_rest_route('seoroom-opt/v1', '/status', array(
        'methods'  => 'GET',
        'callback' => function() {
            $options = sropt_get_options();
            $is_safe = $options['safe_mode'];
            $critical_count = count(glob(WP_CONTENT_DIR . '/cache/seoroom/critical/*.css') ?: array());
            return new WP_REST_Response(array(
                'active'     => true,
                'version'    => SEOROOM_VERSION,
                'safe_mode'  => $is_safe,
                'project_id' => $options['project_id'] ?: null,
                'features'  => array(
                    'schema'          => $options['enable_schema'],
                    'lazy_load'       => $options['enable_lazy_load'],
                    'image_dims'      => $options['enable_image_dims'],
                    'image_compress'  => $options['enable_image_compress'],
                    'critical_css'    => $options['enable_critical_css'] && !$is_safe,
                    'css_minify'      => $options['enable_css_minify'] && !$is_safe,
                    'css_defer'       => ($options['enable_critical_css'] || $options['enable_css_defer']) && !$is_safe,
                    'js_defer'        => $options['enable_js_defer'] && !$is_safe,
                    'js_delay'        => $options['enable_js_delay'] && !$is_safe,
                    'js_minify'       => $options['enable_js_minify'] && !$is_safe,
                    'gzip'            => $options['enable_gzip'],
                    'cache_headers'   => $options['enable_cache_headers'],
                    'font_swap'       => $options['enable_font_swap'],
                    'preconnect'      => $options['enable_preconnect'],
                    'dns_prefetch'    => $options['enable_dns_prefetch'],
                    'lcp_preload'     => $options['enable_lcp_preload'],
                    'page_cache'      => $options['enable_page_cache'] && !$is_safe,
                    'webp'            => $options['enable_webp'],
                    '404_monitor'     => $options['enable_404_monitor'],
                    'redirects'       => $options['enable_redirects'],
                    'link_checker'    => true,
                ),
                'cache_stats' => array(
                    'critical_css_pages' => $critical_count,
                ),
            ), 200);
        },
        'permission_callback' => '__return_true',
    ));

    // ---- 404 Monitor REST Endpoints ----
    register_rest_route('seoroom-opt/v1', '/404s', array(
        'methods'  => 'GET',
        'callback' => function($request) {
            global $wpdb;
            $table = $wpdb->prefix . 'seoroom_404s';
            $limit = intval($request->get_param('limit') ?: 100);
            $offset = intval($request->get_param('offset') ?: 0);
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table ORDER BY hit_count DESC, last_seen DESC LIMIT %d OFFSET %d", $limit, $offset
            ));
            $total = $wpdb->get_var("SELECT COUNT(*) FROM $table");
            return new WP_REST_Response(array('items' => $rows, 'total' => intval($total)), 200);
        },
        'permission_callback' => '__return_true',
    ));

    register_rest_route('seoroom-opt/v1', '/404s/(?P<id>\d+)', array(
        'methods'  => 'DELETE',
        'callback' => function($request) {
            global $wpdb;
            $wpdb->delete($wpdb->prefix . 'seoroom_404s', array('id' => $request['id']));
            return new WP_REST_Response(array('ok' => true), 200);
        },
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ));

    register_rest_route('seoroom-opt/v1', '/404s/clear', array(
        'methods'  => 'POST',
        'callback' => function() {
            global $wpdb;
            $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}seoroom_404s");
            return new WP_REST_Response(array('ok' => true), 200);
        },
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ));

    // ---- Redirects REST Endpoints ----
    register_rest_route('seoroom-opt/v1', '/redirects', array(
        'methods'  => 'GET',
        'callback' => function($request) {
            global $wpdb;
            $table = $wpdb->prefix . 'seoroom_redirects';
            $limit = intval($request->get_param('limit') ?: 100);
            $offset = intval($request->get_param('offset') ?: 0);
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table ORDER BY updated_at DESC LIMIT %d OFFSET %d", $limit, $offset
            ));
            $total = $wpdb->get_var("SELECT COUNT(*) FROM $table");
            return new WP_REST_Response(array('items' => $rows, 'total' => intval($total)), 200);
        },
        'permission_callback' => '__return_true',
    ));

    register_rest_route('seoroom-opt/v1', '/redirects', array(
        'methods'  => 'POST',
        'callback' => function($request) {
            global $wpdb;
            $table = $wpdb->prefix . 'seoroom_redirects';
            $source = trim($request->get_param('source_url'));
            $type = intval($request->get_param('redirect_type') ?: 301);
            $target = $type === 410 ? '' : trim($request->get_param('target_url'));
            if (empty($source) || ($type !== 410 && empty($target))) {
                return new WP_REST_Response(array('error' => 'source_url and target_url required'), 400);
            }
            // Normalize source to path only
            $parsed = parse_url($source);
            $source_path = $parsed['path'] ?? $source;
            $hash = md5($source_path);
            $wpdb->query($wpdb->prepare(
                "INSERT INTO $table (source_url, source_hash, target_url, redirect_type) VALUES (%s, %s, %s, %d)
                 ON DUPLICATE KEY UPDATE target_url=%s, redirect_type=%d, updated_at=NOW()",
                $source_path, $hash, $target, $type, $target, $type
            ));
            $id = $wpdb->insert_id ?: $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE source_hash=%s", $hash));
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d", $id));
            return new WP_REST_Response(array('redirect' => $row), 201);
        },
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ));

    register_rest_route('seoroom-opt/v1', '/redirects/(?P<id>\d+)', array(
        'methods'  => 'PUT',
        'callback' => function($request) {
            global $wpdb;
            $table = $wpdb->prefix . 'seoroom_redirects';
            $updates = array();
            $formats = array();
            if ($request->get_param('target_url') !== null) { $updates['target_url'] = $request->get_param('target_url'); $formats[] = '%s'; }
            if ($request->get_param('redirect_type') !== null) { $updates['redirect_type'] = intval($request->get_param('redirect_type')); $formats[] = '%d'; }
            if (!empty($updates)) {
                $updates['updated_at'] = current_time('mysql');
                $formats[] = '%s';
                $wpdb->update($table, $updates, array('id' => $request['id']), $formats, array('%d'));
            }
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d", $request['id']));
            return new WP_REST_Response(array('redirect' => $row), 200);
        },
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ));

    register_rest_route('seoroom-opt/v1', '/redirects/(?P<id>\d+)', array(
        'methods'  => 'DELETE',
        'callback' => function($request) {
            global $wpdb;
            $wpdb->delete($wpdb->prefix . 'seoroom_redirects', array('id' => $request['id']));
            return new WP_REST_Response(array('ok' => true), 200);
        },
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ));

    // ---- Create redirect from 404 (convenience) ----
    register_rest_route('seoroom-opt/v1', '/404s/(?P<id>\d+)/redirect', array(
        'methods'  => 'POST',
        'callback' => function($request) {
            global $wpdb;
            $t404 = $wpdb->prefix . 'seoroom_404s';
            $tred = $wpdb->prefix . 'seoroom_redirects';
            $row404 = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t404 WHERE id=%d", $request['id']));
            if (!$row404) return new WP_REST_Response(array('error' => '404 not found'), 404);
            $type = intval($request->get_param('redirect_type') ?: 301);
            $target = $type === 410 ? '' : trim($request->get_param('target_url') ?: '/');
            $hash = md5($row404->url);
            $wpdb->query($wpdb->prepare(
                "INSERT INTO $tred (source_url, source_hash, target_url, redirect_type) VALUES (%s, %s, %s, %d)
                 ON DUPLICATE KEY UPDATE target_url=%s, redirect_type=%d, updated_at=NOW()",
                $row404->url, $hash, $target, $type, $target, $type
            ));
            // Remove from 404 log
            $wpdb->delete($t404, array('id' => $request['id']));
            return new WP_REST_Response(array('ok' => true), 201);
        },
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ));

    // ---- Internal Link Checker REST Endpoints ----
    register_rest_route('seoroom-opt/v1', '/link-check', array(
        'methods'  => 'POST',
        'callback' => 'sropt_run_link_check',
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ));

    register_rest_route('seoroom-opt/v1', '/broken-links', array(
        'methods'  => 'GET',
        'callback' => function($request) {
            global $wpdb;
            $table = $wpdb->prefix . 'seoroom_broken_links';
            $limit = intval($request->get_param('limit') ?: 100);
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table ORDER BY status_code ASC, scanned_at DESC LIMIT %d", $limit
            ));
            $total = $wpdb->get_var("SELECT COUNT(*) FROM $table");
            return new WP_REST_Response(array('items' => $rows, 'total' => intval($total)), 200);
        },
        'permission_callback' => '__return_true',
    ));

    register_rest_route('seoroom-opt/v1', '/broken-links/clear', array(
        'methods'  => 'POST',
        'callback' => function() {
            global $wpdb;
            $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}seoroom_broken_links");
            return new WP_REST_Response(array('ok' => true), 200);
        },
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ));

    // ---- Page Audit — Internal crawl (bypasses Cloudflare) ----
    register_rest_route('seoroom-opt/v1', '/page-audit', array(
        'methods'  => 'GET',
        'callback' => 'sropt_page_audit',
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ));
});

/**
 * Page Audit endpoint — crawls all published pages/posts from inside WordPress.
 * Returns structured data matching what the dashboard website audit expects.
 * No Cloudflare issues since it reads directly from DB + renders internally.
 */
function sropt_page_audit() {
    $start = microtime(true);
    $pages = array();
    $site_url = trailingslashit(get_site_url());
    $domain = parse_url($site_url, PHP_URL_HOST);

    // Get all published pages and posts
    $args = array(
        'post_type'      => array('page', 'post'),
        'post_status'    => 'publish',
        'posts_per_page' => 200,
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
    );
    $query = new WP_Query($args);

    foreach ($query->posts as $post) {
        $url = get_permalink($post);
        $path = str_replace($site_url, '/', $url);
        $path = '/' . ltrim($path, '/');

        // Get Yoast meta if available
        $meta_title = '';
        $meta_desc  = '';
        if (class_exists('WPSEO_Meta')) {
            $meta_title = WPSEO_Meta::get_value('title', $post->ID) ?: '';
            $meta_desc  = WPSEO_Meta::get_value('metadesc', $post->ID) ?: '';
        }
        if (!$meta_title) $meta_title = get_post_meta($post->ID, '_yoast_wpseo_title', true) ?: $post->post_title;
        if (!$meta_desc)  $meta_desc  = get_post_meta($post->ID, '_yoast_wpseo_metadesc', true) ?: '';

        // Render content to get accurate word count (includes shortcodes, blocks, etc.)
        $content = apply_filters('the_content', $post->post_content);
        $text = wp_strip_all_tags($content);
        $word_count = str_word_count($text);

        // H1/H2 from rendered content
        $h1s = array();
        $h2s = array();
        if (preg_match_all('/<h1[^>]*>(.*?)<\/h1>/is', $content, $m)) {
            $h1s = array_map('wp_strip_all_tags', $m[1]);
        }
        if (preg_match_all('/<h2[^>]*>(.*?)<\/h2>/is', $content, $m)) {
            $h2s = array_map('wp_strip_all_tags', $m[1]);
        }

        // Images
        $images_total = 0;
        $images_missing_alt = 0;
        $missing_alt_srcs = array();
        if (preg_match_all('/<img[^>]*>/i', $content, $img_matches)) {
            $images_total = count($img_matches[0]);
            foreach ($img_matches[0] as $img_tag) {
                $has_alt = preg_match('/alt=["\']([^"\']+)["\']/i', $img_tag, $am);
                if (!$has_alt || trim($am[1]) === '') {
                    $images_missing_alt++;
                    if (preg_match('/src=["\']([^"\']+)["\']/i', $img_tag, $sm)) {
                        $missing_alt_srcs[] = $sm[1];
                    }
                }
            }
        }

        // Schema from SEO Room plugin
        $seoroom_schema = get_post_meta($post->ID, '_seoroom_schema', true);
        $schemas = array();
        $schema_sources = array();
        if ($seoroom_schema) {
            $parsed = json_decode($seoroom_schema, true);
            if ($parsed && isset($parsed['@type'])) {
                $types = (array)$parsed['@type'];
                foreach ($types as $t) {
                    $schemas[] = $t;
                    $schema_sources[] = array('type' => $t, 'source' => 'seoroom');
                }
            }
        }

        // Check Yoast schema too
        $yoast_json = get_post_meta($post->ID, '_yoast_wpseo_schema_page_type', true);
        if ($yoast_json) {
            $schemas[] = $yoast_json;
            $schema_sources[] = array('type' => $yoast_json, 'source' => 'yoast');
        }

        // Canonical
        $canonical = '';
        if (class_exists('WPSEO_Meta')) {
            $canonical = WPSEO_Meta::get_value('canonical', $post->ID) ?: '';
        }
        if (!$canonical) $canonical = $url; // self-referencing

        // Noindex
        $noindex_val = get_post_meta($post->ID, '_yoast_wpseo_meta-robots-noindex', true);
        $is_noindex = ($noindex_val === '1');

        // Robots meta
        $robots_meta = $is_noindex ? 'noindex' : '';

        // Internal/external links
        $internal_links = 0;
        $external_links = 0;
        if (preg_match_all('/href=["\']([^"\'#]+)["\']/i', $content, $link_matches)) {
            foreach ($link_matches[1] as $href) {
                if (strpos($href, 'mailto:') === 0 || strpos($href, 'tel:') === 0) continue;
                if (strpos($href, $domain) !== false || strpos($href, '/') === 0) {
                    $internal_links++;
                } elseif (strpos($href, 'http') === 0) {
                    $external_links++;
                }
            }
        }

        // OG tags (check if Yoast generates them — it does by default)
        $has_og = class_exists('WPSEO_Options');

        // FAQ detection
        $question_headings = 0;
        if (preg_match_all('/<h[2-4][^>]*>[^<]*\?[^<]*<\/h[2-4]>/i', $content, $qm)) {
            $question_headings = count($qm[0]);
        }
        $has_faq = (bool)preg_match('/<h[1-4][^>]*>[^<]*(faq|frequently asked|common questions)[^<]*<\/h[1-4]>/i', $content);

        $pages[] = array(
            'url'              => $url,
            'path'             => $path,
            'title'            => $post->post_title,
            'type'             => $post->post_type, // 'page' or 'post'
            'id'               => $post->ID,
            'slug'             => $post->post_name,
            'statusCode'       => 200,
            'elapsed'          => 0, // internal read, no HTTP latency
            'metaTitle'        => $meta_title,
            'metaTitleLength'  => strlen($meta_title),
            'metaDesc'         => $meta_desc,
            'metaDescLength'   => strlen($meta_desc),
            'h1s'              => $h1s,
            'h2s'              => $h2s,
            'wordCount'        => $word_count,
            'images'           => $images_total,
            'imagesWithoutAlt' => $images_missing_alt,
            'imagesMissingAlt' => $missing_alt_srcs,
            'internalLinks'    => $internal_links,
            'externalLinks'    => $external_links,
            'schemas'          => $schemas,
            'schemaSources'    => $schema_sources,
            'canonical'        => $canonical,
            'hasViewport'      => true, // WordPress themes always have viewport
            'robotsMeta'       => $robots_meta,
            'isNoindex'        => $is_noindex,
            'isHttps'          => (strpos($site_url, 'https') === 0),
            'hasOG'            => $has_og,
            'questionHeadings' => $question_headings,
            'hasFAQSection'    => $has_faq,
            'wasRedirected'    => false,
        );
    }

    $elapsed = round((microtime(true) - $start) * 1000);
    return new WP_REST_Response(array(
        'success' => true,
        'pages'   => $pages,
        'total'   => count($pages),
        'elapsed_ms' => $elapsed,
    ), 200);
}


// ================================================================
// PUSH TO DASHBOARD — Sends page audit data to SEO Room Dashboard
// Outbound from WP → Railway (bypasses Cloudflare)
// ================================================================

/**
 * Push page audit data to the dashboard connector-push endpoint.
 * Called by WP-Cron (daily) and manually from settings page.
 */
function sropt_push_to_dashboard() {
    $options = sropt_get_options();
    $dashboard_url = rtrim($options['dashboard_url'] ?? '', '/');
    $project_id    = $options['project_id'] ?? '';
    $token         = $options['connection_code'] ?? '';

    if (!$dashboard_url || !$project_id || !$token) {
        return new WP_Error('config', 'Dashboard URL, Project ID, and Connection Code are required.');
    }

    // Collect page audit data using the same function as the REST endpoint
    $audit_response = sropt_page_audit();
    $audit_data = $audit_response->get_data();

    if (empty($audit_data['pages'])) {
        return new WP_Error('no_pages', 'No pages found to push.');
    }

    // Push to dashboard
    $push_url = $dashboard_url . '/api/connector-push/' . $project_id;
    $response = wp_remote_post($push_url, array(
        'timeout'  => 60,
        'headers'  => array(
            'Content-Type'  => 'application/json',
            'Authorization' => 'Bearer ' . $token,
        ),
        'body' => wp_json_encode(array(
            'success' => true,
            'pages'   => $audit_data['pages'],
        )),
    ));

    if (is_wp_error($response)) {
        update_option('sropt_last_push', array(
            'status' => 'error',
            'error'  => $response->get_error_message(),
            'time'   => current_time('mysql'),
        ));
        return $response;
    }

    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    $result = array(
        'status'     => ($code === 200 && !empty($body['success'])) ? 'ok' : 'error',
        'http_code'  => $code,
        'pages'      => count($audit_data['pages']),
        'time'       => current_time('mysql'),
    );
    if ($result['status'] === 'error') {
        $result['error'] = $body['error'] ?? "HTTP $code";
    }

    update_option('sropt_last_push', $result);
    return $result;
}

// REST endpoint for manual push from settings page
add_action('rest_api_init', function() {
    register_rest_route('seoroom-opt/v1', '/push-now', array(
        'methods'  => 'POST',
        'callback' => function() {
            $result = sropt_push_to_dashboard();
            if (is_wp_error($result)) {
                return new WP_REST_Response(array('ok' => false, 'error' => $result->get_error_message()), 500);
            }
            return new WP_REST_Response(array('ok' => true, 'result' => $result), 200);
        },
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ));
});

// WP-Cron: schedule daily push
add_action('sropt_daily_push', 'sropt_push_to_dashboard');
register_activation_hook(__FILE__, function() {
    if (!wp_next_scheduled('sropt_daily_push')) {
        wp_schedule_event(time(), 'daily', 'sropt_daily_push');
    }
});
register_deactivation_hook(__FILE__, function() {
    wp_clear_scheduled_hook('sropt_daily_push');
});
// Ensure cron is scheduled (in case plugin was already active)
add_action('init', function() {
    if (!wp_next_scheduled('sropt_daily_push')) {
        wp_schedule_event(time(), 'daily', 'sropt_daily_push');
    }
});

// Also push on plugin activation after tables are created
add_action('admin_init', function() {
    $options = sropt_get_options();
    $last_push = get_option('sropt_last_push');
    // Auto-push on first activation if connected
    if ($options['project_id'] && $options['connection_code'] && !$last_push) {
        sropt_push_to_dashboard();
    }
});


// ================================================================
// REDIRECT MANAGER — Fires before WordPress loads anything
// ================================================================

add_action('template_redirect', 'sropt_check_redirects', -1);
function sropt_check_redirects() {
    $options = sropt_get_options();
    if (!$options['enable_redirects']) return;

    global $wpdb;
    $table = $wpdb->prefix . 'seoroom_redirects';

    // Check if table exists (avoid errors before activation)
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) return;

    $request_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $hash = md5($request_path);

    $redirect = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table WHERE source_hash = %s LIMIT 1", $hash
    ));

    if ($redirect) {
        // Increment hit count
        $wpdb->query($wpdb->prepare(
            "UPDATE $table SET hit_count = hit_count + 1 WHERE id = %d", $redirect->id
        ));
        $rtype = intval($redirect->redirect_type);
        if ($rtype === 410) {
            // 410 Gone — tell search engines this page is permanently removed
            status_header(410);
            nocache_headers();
            echo '<!DOCTYPE html><html><head><title>410 Gone</title></head><body><h1>410 Gone</h1><p>This page has been permanently removed.</p></body></html>';
            exit;
        }
        wp_redirect($redirect->target_url, $rtype);
        exit;
    }
}


// ================================================================
// 404 MONITOR — Log every 404 hit
// ================================================================

add_action('template_redirect', 'sropt_monitor_404', 99);
function sropt_monitor_404() {
    if (!is_404()) return;

    $options = sropt_get_options();
    if (!$options['enable_404_monitor']) return;

    global $wpdb;
    $table = $wpdb->prefix . 'seoroom_404s';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) return;

    $url = $_SERVER['REQUEST_URI'];
    $url_lower = strtolower($url);
    $url_path = strtok($url_lower, '?');

    // ---- STRICT FILTER: only log real page-like URLs ----
    // Skip anything with a file extension (images, scripts, styles, media, cache files, etc.)
    if (preg_match('/\.\w{1,10}$/', $url_path)) return;
    // Skip WordPress internals
    $skip_prefixes = array('/wp-login', '/wp-admin', '/wp-includes/', '/wp-content/', '/wp-json/', '/wp-cron', '/xmlrpc', '/feed/', '/trackback/');
    foreach ($skip_prefixes as $prefix) {
        if (strpos($url_lower, $prefix) !== false) return;
    }
    // Skip dotfiles, admin paths, scanner probes
    if (preg_match('#/\.|/admin|/cgi-bin|/phpmyadmin|/vendor/|/node_modules/#i', $url_lower)) return;
    // Skip URLs with protocol-like prefixes used as paths (e.g. /tel:, /mailto:)
    if (preg_match('#^/(tel|mailto|javascript|data):#i', $url_path)) return;
    // Skip suspicious query strings
    if (preg_match('/[<>\{\}]|eval\(|base64|SELECT\s|UNION\s|DROP\s/i', $url)) return;
    // ---- END FILTER ----

    $referrer = $_SERVER['HTTP_REFERER'] ?? '';
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512);

    // ---- AUTO-REDIRECT: try to match to an existing page ----
    $matched_url = sropt_find_matching_page($url_path);
    if ($matched_url) {
        // Auto-create a 301 redirect
        $red_table = $wpdb->prefix . 'seoroom_redirects';
        $source_path = parse_url($url, PHP_URL_PATH);
        $source_hash = md5($source_path);
        // Only create if redirect doesn't already exist
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $red_table WHERE source_hash = %s", $source_hash));
        if (!$exists) {
            $wpdb->insert($red_table, array(
                'source_url'    => $source_path,
                'source_hash'   => $source_hash,
                'target_url'    => $matched_url,
                'redirect_type' => 301,
                'hit_count'     => 0,
                'created_at'    => current_time('mysql'),
                'updated_at'    => current_time('mysql'),
            ));
        }
        // Redirect immediately
        wp_redirect($matched_url, 301);
        exit;
    }

    // No match found — log the 404 for manual review
    $hash = md5($url);
    $wpdb->query($wpdb->prepare(
        "INSERT INTO $table (url, url_hash, referrer, user_agent, hit_count, first_seen, last_seen)
         VALUES (%s, %s, %s, %s, 1, NOW(), NOW())
         ON DUPLICATE KEY UPDATE hit_count = hit_count + 1, last_seen = NOW(), referrer = IF(%s != '', %s, referrer)",
        $url, $hash, $referrer, $ua, $referrer, $referrer
    ));
}

/**
 * Find a matching published page/post for a 404 URL using slug similarity.
 * Returns the matched permalink or false.
 */
function sropt_find_matching_page($url_path) {
    global $wpdb;

    // Extract slug parts from the 404 URL
    $path = trim($url_path, '/');
    if (empty($path)) return false;

    $segments = explode('/', $path);
    $last_slug = end($segments);  // Most specific part (e.g., "seo-audit-perth")
    $slug_words = explode('-', $last_slug);
    if (count($slug_words) < 1) return false;

    // Strategy 1: Exact slug match (handles moved pages, e.g., /old-parent/page-slug → /page-slug)
    $exact = $wpdb->get_row($wpdb->prepare(
        "SELECT ID, post_name, post_type FROM {$wpdb->posts}
         WHERE post_name = %s AND post_status = 'publish' AND post_type IN ('page', 'post')
         LIMIT 1",
        $last_slug
    ));
    if ($exact) {
        return get_permalink($exact->ID);
    }

    // Strategy 2: Partial slug match — find pages containing the key words
    // Build a LIKE query for pages whose slug shares words with the 404 slug
    // Only try if slug has 2+ words (avoid matching single common words like "services")
    if (count($slug_words) >= 2) {
        $like_clauses = array();
        $like_values = array();
        foreach ($slug_words as $word) {
            if (strlen($word) < 3) continue;  // Skip short words (and, the, of, etc.)
            $like_clauses[] = "post_name LIKE %s";
            $like_values[] = '%' . $wpdb->esc_like($word) . '%';
        }
        if (count($like_clauses) >= 2) {
            $sql = "SELECT ID, post_name FROM {$wpdb->posts}
                    WHERE post_status = 'publish' AND post_type IN ('page', 'post')
                    AND " . implode(' AND ', $like_clauses) . "
                    LIMIT 5";
            $candidates = $wpdb->get_results($wpdb->prepare($sql, ...$like_values));
            if ($candidates && count($candidates) === 1) {
                // Only auto-redirect if there's exactly one confident match
                return get_permalink($candidates[0]->ID);
            }
            // If multiple matches, pick the one with highest slug similarity
            if ($candidates && count($candidates) > 1) {
                $best = null;
                $best_score = 0;
                foreach ($candidates as $c) {
                    similar_text($last_slug, $c->post_name, $score);
                    if ($score > $best_score) {
                        $best_score = $score;
                        $best = $c;
                    }
                }
                if ($best && $best_score >= 60) {
                    return get_permalink($best->ID);
                }
            }
        }
    }

    // Strategy 3: For parent/child URL structures, try matching the full path
    if (count($segments) > 1) {
        $full_slug = implode('/', $segments);
        $page = get_page_by_path($full_slug, OBJECT, array('page', 'post'));
        if ($page && $page->post_status === 'publish') {
            return get_permalink($page->ID);
        }
    }

    return false;
}


// ================================================================
// INTERNAL LINK CHECKER — Scan pages for broken internal links
// ================================================================

function sropt_run_link_check($request) {
    global $wpdb;
    $table = $wpdb->prefix . 'seoroom_broken_links';

    // Clear previous results
    $wpdb->query("TRUNCATE TABLE $table");

    $site_url = home_url();
    $site_host = parse_url($site_url, PHP_URL_HOST);

    // Get all published pages and posts
    $posts = $wpdb->get_results(
        "SELECT ID, post_title, post_content, guid FROM {$wpdb->posts}
         WHERE post_status = 'publish' AND post_type IN ('page', 'post')
         ORDER BY ID ASC LIMIT 200"
    );

    $checked_urls = array(); // Cache: url => status_code
    $broken = 0;
    $total_links = 0;
    $max_checks = intval($request->get_param('max_checks') ?: 500);

    foreach ($posts as $post) {
        $content = $post->post_content;
        if (empty($content)) continue;

        // Extract all links from content
        preg_match_all('/<a\b[^>]*href\s*=\s*["\']([^"\'#]+)["\'][^>]*>(.*?)<\/a>/is', $content, $matches, PREG_SET_ORDER);

        foreach ($matches as $match) {
            if ($total_links >= $max_checks) break 2;

            $href = $match[1];
            $anchor = wp_strip_all_tags($match[2]);

            // Normalize URL
            if (strpos($href, '//') === 0) $href = 'https:' . $href;
            if (strpos($href, '/') === 0) $href = $site_url . $href;

            // Determine link type
            $link_host = parse_url($href, PHP_URL_HOST);
            $is_internal = ($link_host === $site_host || empty($link_host));
            $link_type = $is_internal ? 'internal' : 'external';

            // Only check internal links by default (external is slow)
            $check_external = $request->get_param('check_external');
            if (!$is_internal && !$check_external) continue;

            // Skip mailto, tel, javascript, and malformed URLs
            if (preg_match('/^(mailto:|tel:|javascript:)/i', $href)) continue;
            if (preg_match('/^https?:\/\/?$/i', $href)) continue; // bare https:// with no host

            $total_links++;

            // Check cache first
            if (isset($checked_urls[$href])) {
                $status = $checked_urls[$href];
            } else {
                $status = sropt_check_url_status($href);
                $checked_urls[$href] = $status;
            }

            // Log broken links (non-200 status)
            if ($status >= 400 || $status === 0) {
                $broken++;
                $page_url = get_permalink($post->ID) ?: $post->guid;
                $wpdb->insert($table, array(
                    'source_url'     => $page_url,
                    'source_post_id' => $post->ID,
                    'target_url'     => $href,
                    'status_code'    => $status,
                    'anchor_text'    => substr($anchor, 0, 512),
                    'link_type'      => $link_type,
                    'scanned_at'     => current_time('mysql'),
                ));
            }
        }
    }

    return new WP_REST_Response(array(
        'ok'           => true,
        'pages_scanned' => count($posts),
        'links_checked' => $total_links,
        'broken_found'  => $broken,
    ), 200);
}

function sropt_check_url_status($url) {
    $args = array(
        'timeout'     => 10,
        'redirection' => 5,
        'sslverify'   => false,
        'method'      => 'HEAD', // Fast — don't download body
        'user-agent'  => 'SEORoom Link Checker/1.0',
    );

    $response = wp_remote_head($url, $args);

    if (is_wp_error($response)) {
        // HEAD might be blocked, try GET
        $response = wp_remote_get($url, array_merge($args, array('method' => 'GET')));
        if (is_wp_error($response)) return 0;
    }

    return wp_remote_retrieve_response_code($response);
}


// ================================================================
// AUTO-UPDATE — Check Railway server for new versions
// ================================================================

add_filter('pre_set_site_transient_update_plugins', 'sropt_check_for_update');
function sropt_check_for_update($transient) {
    if (empty($transient->checked)) return $transient;

    $options = sropt_get_options();
    $dashboard_url = rtrim($options['dashboard_url'], '/');
    if (empty($dashboard_url)) return $transient;

    $response = wp_remote_get($dashboard_url . '/api/plugin/update-check', array(
        'timeout' => 10,
        'headers' => array('Accept' => 'application/json'),
    ));

    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) return $transient;

    $data = json_decode(wp_remote_retrieve_body($response));
    if (!$data || !isset($data->version)) return $transient;

    $plugin_file = plugin_basename(__FILE__);

    if (version_compare(SEOROOM_VERSION, $data->version, '<')) {
        $transient->response[$plugin_file] = (object) array(
            'slug'        => $data->slug ?? 'seoroom',
            'plugin'      => $plugin_file,
            'new_version' => $data->version,
            'url'         => $dashboard_url,
            'package'     => $data->download_url,
            'requires'    => $data->requires ?? '5.8',
            'tested'      => $data->tested ?? '6.7',
        );
    } else {
        // No update — still register so WP doesn't show "update available" from wp.org
        $transient->no_update[$plugin_file] = (object) array(
            'slug'        => $data->slug ?? 'seoroom',
            'plugin'      => $plugin_file,
            'new_version' => SEOROOM_VERSION,
            'url'         => $dashboard_url,
        );
    }

    return $transient;
}

// Plugin info popup (when user clicks "View details")
add_filter('plugins_api', 'sropt_plugin_info', 20, 3);
function sropt_plugin_info($result, $action, $args) {
    if ($action !== 'plugin_information' || ($args->slug ?? '') !== 'seoroom') return $result;

    $options = sropt_get_options();
    $dashboard_url = rtrim($options['dashboard_url'], '/');
    if (empty($dashboard_url)) return $result;

    $response = wp_remote_get($dashboard_url . '/api/plugin/update-check', array('timeout' => 10));
    if (is_wp_error($response)) return $result;

    $data = json_decode(wp_remote_retrieve_body($response));
    if (!$data) return $result;

    return (object) array(
        'name'          => 'SEO Room',
        'slug'          => 'seoroom',
        'version'       => $data->version,
        'author'        => '<a href="https://theseoroom.com.au">The SEO Room</a>',
        'homepage'      => 'https://theseoroom.com.au',
        'download_link' => $data->download_url,
        'requires'      => $data->requires ?? '5.8',
        'tested'        => $data->tested ?? '6.7',
        'sections'      => array(
            'description' => 'SEO Room — Local SEO automation plugin. Schema, 404 monitor, redirects, speed optimizations, dashboard connector.',
            'changelog'   => $data->changelog ?? 'See dashboard for changelog.',
        ),
    );
}

// After update, clear transient so next check is fresh
add_action('upgrader_process_complete', 'sropt_after_update', 10, 2);
function sropt_after_update($upgrader, $options) {
    if ($options['action'] === 'update' && $options['type'] === 'plugin') {
        delete_site_transient('update_plugins');
    }
}


// ================================================================
// LICENSE SYSTEM — Yearly renewal, read-only on expire
// ================================================================

// AJAX handler for "Check License Now" button (server-side call, no CORS)
add_action('wp_ajax_sropt_ajax_check_license', 'sropt_ajax_check_license');
function sropt_ajax_check_license() {
    check_ajax_referer('sropt_license_nonce', 'nonce');

    $license_key = sanitize_text_field($_POST['license_key'] ?? '');
    if (empty($license_key)) {
        wp_send_json_error('No license key provided');
    }

    $options = sropt_get_options();
    $dashboard_url = rtrim($options['dashboard_url'] ?? '', '/');
    if (empty($dashboard_url)) {
        wp_send_json_error('Dashboard URL not set');
    }

    // Clear cached status so we get fresh result
    delete_transient('sropt_license_status');

    $response = wp_remote_post($dashboard_url . '/api/plugin/license-check', array(
        'timeout' => 15,
        'headers' => array('Content-Type' => 'application/json'),
        'body'    => json_encode(array(
            'license_key' => $license_key,
            'domain'      => home_url(),
        )),
    ));

    if (is_wp_error($response)) {
        wp_send_json_error('Connection failed: ' . $response->get_error_message());
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!$data) {
        wp_send_json_error('Invalid response from dashboard (HTTP ' . wp_remote_retrieve_response_code($response) . ')');
    }

    // Update stored license info
    if (!empty($data['valid'])) {
        set_transient('sropt_license_status', 'valid', DAY_IN_SECONDS);
    }
    update_option('sropt_license_info', array(
        'valid'          => !empty($data['valid']),
        'reason'         => $data['reason'] ?? '',
        'project_name'   => $data['project_name'] ?? '',
        'expires'        => $data['expires'] ?? '',
        'days_remaining' => $data['days_remaining'] ?? null,
        'checked_at'     => current_time('mysql'),
    ));

    wp_send_json_success($data);
}

// Check if license is valid (cached for 24 hours)
function sropt_is_license_valid() {
    $cached = get_transient('sropt_license_status');
    if ($cached !== false) return $cached === 'valid';

    $options = sropt_get_options();
    $dashboard_url = rtrim($options['dashboard_url'], '/');
    $license_key = $options['license_key'] ?? '';

    if (empty($dashboard_url) || empty($license_key)) {
        set_transient('sropt_license_status', 'no_key', DAY_IN_SECONDS);
        return false;
    }

    $response = wp_remote_post($dashboard_url . '/api/plugin/license-check', array(
        'timeout' => 10,
        'headers' => array('Content-Type' => 'application/json'),
        'body'    => json_encode(array(
            'license_key' => $license_key,
            'domain'      => home_url(),
        )),
    ));

    if (is_wp_error($response)) {
        // Network error — grace period, assume valid
        set_transient('sropt_license_status', 'valid', HOUR_IN_SECONDS);
        return true;
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    $valid = !empty($data['valid']);

    set_transient('sropt_license_status', $valid ? 'valid' : 'expired', DAY_IN_SECONDS);

    // Store extra info for admin display
    if ($data) {
        update_option('sropt_license_info', array(
            'valid'          => $valid,
            'reason'         => $data['reason'] ?? '',
            'project_name'   => $data['project_name'] ?? '',
            'expires'        => $data['expires'] ?? '',
            'days_remaining' => $data['days_remaining'] ?? null,
            'checked_at'     => current_time('mysql'),
        ));
    }

    return $valid;
}

// Schedule daily license check via wp_cron
add_action('wp', 'sropt_schedule_license_check');
function sropt_schedule_license_check() {
    if (!wp_next_scheduled('sropt_daily_license_check')) {
        wp_schedule_event(time(), 'daily', 'sropt_daily_license_check');
    }
}
add_action('sropt_daily_license_check', 'sropt_run_license_check');
function sropt_run_license_check() {
    delete_transient('sropt_license_status');
    sropt_is_license_valid();
}

// Admin notice when license is expired
add_action('admin_notices', 'sropt_license_admin_notice');
function sropt_license_admin_notice() {
    $options = sropt_get_options();
    if (empty($options['license_key'])) return; // No key set yet, don't nag

    if (!sropt_is_license_valid()) {
        $info = get_option('sropt_license_info', array());
        $reason = $info['reason'] ?? 'expired';
        echo '<div class="notice notice-error"><p>';
        echo '<strong>SEO Room:</strong> License ' . esc_html($reason) . '. ';
        echo 'The plugin is in read-only mode — existing redirects and schema continue working, but management features are disabled. ';
        echo 'Contact <a href="https://theseoroom.com.au">The SEO Room</a> to renew.';
        echo '</p></div>';
    } else {
        $info = get_option('sropt_license_info', array());
        $days = $info['days_remaining'] ?? null;
        if ($days !== null && $days <= 30 && $days > 0) {
            echo '<div class="notice notice-warning"><p>';
            echo '<strong>SEO Room:</strong> License expires in ' . intval($days) . ' days. Contact The SEO Room to renew.';
            echo '</p></div>';
        }
    }
}

// Gate management features behind license check
// These functions return true if the feature should be BLOCKED
function sropt_is_management_blocked() {
    $options = sropt_get_options();
    if (empty($options['license_key'])) return false; // No license system yet, don't block
    return !sropt_is_license_valid();
}

// Block REST API management endpoints when license expired
add_filter('rest_pre_dispatch', 'sropt_license_gate_rest', 10, 3);
function sropt_license_gate_rest($result, $server, $request) {
    $route = $request->get_route();

    // Only gate seoroom management endpoints (not read-only ones)
    if (strpos($route, 'seoroom-opt/v1/') === false) return $result;

    // Allow read-only endpoints always
    $read_only_patterns = array('/status', '/update-check');
    foreach ($read_only_patterns as $p) {
        if (strpos($route, $p) !== false) return $result;
    }

    // Allow GET requests (reading data is always OK)
    if ($request->get_method() === 'GET') return $result;

    // Block write operations when license expired
    if (sropt_is_management_blocked()) {
        return new WP_Error(
            'license_expired',
            'SEO Room license expired. Management features are disabled. Existing redirects and schema continue working. Contact The SEO Room to renew.',
            array('status' => 403)
        );
    }

    return $result;
}
