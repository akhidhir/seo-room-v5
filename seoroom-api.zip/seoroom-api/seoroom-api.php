<?php
/**
 * Plugin Name: SEO Room API
 * Description: Custom REST endpoints for SEO Room Dashboard — bypasses hosting auth header issues.
 * Version: 1.0
 * Author: SEO Room
 */

defined('ABSPATH') || exit;

// Secret key for authentication (dashboard sends this in POST body)
// Generate a unique key for each install
if (!get_option('seoroom_api_key')) {
    update_option('seoroom_api_key', wp_generate_password(32, false));
}

// Register REST routes
add_action('rest_api_init', function() {
    // Test auth
    register_rest_route('seoroom/v1', '/test', [
        'methods' => 'GET',
        'callback' => 'seoroom_api_test',
        'permission_callback' => '__return_true',
    ]);

    // Create Elementor page
    register_rest_route('seoroom/v1', '/create-page', [
        'methods' => 'POST',
        'callback' => 'seoroom_api_create_page',
        'permission_callback' => '__return_true',
    ]);

    // Get API key (only visible to logged-in admins via browser)
    register_rest_route('seoroom/v1', '/get-key', [
        'methods' => 'GET',
        'callback' => function() {
            if (!current_user_can('manage_options')) {
                return new WP_Error('forbidden', 'Admin only', ['status' => 403]);
            }
            return ['key' => get_option('seoroom_api_key')];
        },
        'permission_callback' => '__return_true',
    ]);
});

function seoroom_verify_key($request) {
    $key = $request->get_param('api_key');
    if (!$key || $key !== get_option('seoroom_api_key')) {
        return new WP_Error('unauthorized', 'Invalid API key', ['status' => 401]);
    }
    return true;
}

function seoroom_api_test($request) {
    $key_check = seoroom_verify_key($request);
    if (is_wp_error($key_check)) return $key_check;
    $user = get_users(['role' => 'administrator', 'number' => 1]);
    return [
        'ok' => true,
        'wp_version' => get_bloginfo('version'),
        'admin_user' => $user ? $user[0]->user_login : 'none',
        'elementor' => defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : 'not installed',
    ];
}

function seoroom_api_create_page($request) {
    $key_check = seoroom_verify_key($request);
    if (is_wp_error($key_check)) return $key_check;

    $title = sanitize_text_field($request->get_param('title') ?: 'New Page');
    $slug = sanitize_title($request->get_param('slug') ?: $title);
    $tree = $request->get_param('tree');
    $status = $request->get_param('status') ?: 'draft';

    if (empty($tree)) {
        return new WP_Error('missing_tree', 'Elementor tree data required', ['status' => 400]);
    }

    // Get first admin user to set as author
    $admins = get_users(['role' => 'administrator', 'number' => 1]);
    $author_id = $admins ? $admins[0]->ID : 1;

    // Create the page
    $page_id = wp_insert_post([
        'post_title'  => $title,
        'post_name'   => $slug,
        'post_status' => $status,
        'post_type'   => 'page',
        'post_author' => $author_id,
    ], true);

    if (is_wp_error($page_id)) {
        return $page_id;
    }

    // Set Elementor data
    $tree_json = is_string($tree) ? $tree : wp_json_encode($tree);
    update_post_meta($page_id, '_elementor_data', wp_slash($tree_json));
    update_post_meta($page_id, '_elementor_edit_mode', 'builder');
    update_post_meta($page_id, '_elementor_page_settings', wp_json_encode(['hide_title' => 'yes']));
    update_post_meta($page_id, '_wp_page_template', 'elementor_header_footer');

    // Tell Elementor this page uses the builder
    update_post_meta($page_id, '_elementor_version', defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : '3.0.0');
    update_post_meta($page_id, '_elementor_template_type', 'wp-page');

    return [
        'id' => $page_id,
        'slug' => $slug,
        'link' => get_permalink($page_id),
        'edit_link' => admin_url("post.php?post={$page_id}&action=elementor"),
    ];
}
