<?php
/**
 * Plugin Name: SEO Room API
 * Description: Custom REST endpoints for SEO Room Dashboard.
 * Version: 5.1
 * Author: SEO Room
 */
defined('ABSPATH') || exit;
define('SEOROOM_API_KEY', 'sr_2026_kX9mNpQ4wR7vBz');

add_action('rest_api_init', function() {
    $routes = [
        ['/test',                    'GET',  'seoroom_test'],
        ['/create-page',             'POST', 'seoroom_create_page'],
        ['/delete-pages',            'POST', 'seoroom_delete_pages'],
        ['/list-pages',              'GET',  'seoroom_list_pages'],
        ['/read-meta/(?P<id>\d+)',   'GET',  'seoroom_read_meta'],
        ['/fix-page/(?P<id>\d+)',    'GET',  'seoroom_fix_page'],
        ['/test-minimal',            'GET',  'seoroom_test_minimal'],
        ['/extract-widgets/(?P<id>\d+)', 'GET', 'seoroom_extract_widgets'],
    ];
    foreach ($routes as $r) {
        register_rest_route('seoroom/v1', $r[0], [
            'methods' => $r[1], 'callback' => $r[2], 'permission_callback' => '__return_true',
        ]);
    }
});

function seoroom_auth($req) {
    return $req->get_param('api_key') === SEOROOM_API_KEY;
}

/* ── Test ────────────────────────────────────────────────────── */
function seoroom_test($req) {
    if (!seoroom_auth($req)) return new WP_Error('unauthorized','Bad key',['status'=>401]);
    return [
        'ok'        => true,
        'elementor' => defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : 'not installed',
        'php'       => PHP_VERSION,
        'wp'        => get_bloginfo('version'),
    ];
}

/* ── Helper: save via Elementor native API ───────────────────── */
function seoroom_native_save($page_id, $elements, $settings = []) {
    if (!class_exists('\Elementor\Plugin')) return false;
    try {
        $admins = get_users(['role'=>'administrator','number'=>1]);
        if ($admins) wp_set_current_user($admins[0]->ID);
        $document = \Elementor\Plugin::$instance->documents->get($page_id);
        if (!$document) return false;
        $save_data = ['elements' => $elements];
        if (!empty($settings)) $save_data['settings'] = $settings;
        $document->save($save_data);
        return true;
    } catch (\Throwable $e) {
        return $e->getMessage();
    }
}

/* ── Create Page ─────────────────────────────────────────────── */
function seoroom_create_page($req) {
    if (!seoroom_auth($req)) return new WP_Error('unauthorized','Bad key',['status'=>401]);
    $title = sanitize_text_field($req->get_param('title') ?: 'New Page');
    $slug  = sanitize_title($req->get_param('slug') ?: $title);

    // Accept pre-encoded JSON string to avoid PHP object/array encoding issues
    $tree_json = $req->get_param('tree_json');
    if (!$tree_json) {
        $tree = $req->get_param('tree');
        if (empty($tree)) return new WP_Error('missing_tree','tree or tree_json required',['status'=>400]);
        $tree_json = is_string($tree) ? $tree : wp_json_encode($tree);
    }
    // Fix: empty settings must be {} not [] (PHP json_decode converts {} to [] in assoc mode)
    $tree_json = str_replace('"settings":[]', '"settings":{}', $tree_json);

    $admins  = get_users(['role'=>'administrator','number'=>1]);
    $page_id = wp_insert_post([
        'post_title'=>$title, 'post_name'=>$slug,
        'post_status'=>'draft', 'post_type'=>'page',
        'post_author'=>$admins ? $admins[0]->ID : 1,
    ], true);
    if (is_wp_error($page_id)) return $page_id;

    // Always use raw meta — native save strips section styling on frontend
    $method = 'raw_meta';
    update_post_meta($page_id, '_elementor_data',          wp_slash($tree_json));
    update_post_meta($page_id, '_elementor_edit_mode',     'builder');
    update_post_meta($page_id, '_elementor_page_settings', ['hide_title'=>'yes']);
    update_post_meta($page_id, '_wp_page_template',        'elementor_header_footer');
    update_post_meta($page_id, '_elementor_version',       defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : '4.0.1');
    update_post_meta($page_id, '_elementor_template_type', 'wp-page');

    return ['id'=>$page_id,'slug'=>$slug,'method'=>$method,
            'link'=>get_permalink($page_id),
            'edit'=>admin_url("post.php?post={$page_id}&action=elementor")];
}

/* ── Delete Pages ────────────────────────────────────────────── */
function seoroom_delete_pages($req) {
    if (!seoroom_auth($req)) return new WP_Error('unauthorized','Bad key',['status'=>401]);
    $ids = $req->get_param('ids');
    if (empty($ids)||!is_array($ids)) return new WP_Error('missing_ids','ids array required',['status'=>400]);
    $deleted = [];
    foreach ($ids as $id) { $id=intval($id); if($id>0){wp_trash_post($id);$deleted[]=$id;} }
    return ['trashed'=>$deleted,'count'=>count($deleted)];
}

/* ── List Pages ──────────────────────────────────────────────── */
function seoroom_list_pages($req) {
    if (!seoroom_auth($req)) return new WP_Error('unauthorized','Bad key',['status'=>401]);
    $pages = get_posts(['post_type'=>'page','post_status'=>['draft','publish'],'numberposts'=>100]);
    $r = [];
    foreach ($pages as $p) $r[] = ['id'=>$p->ID,'title'=>$p->post_title,'status'=>$p->post_status];
    return $r;
}

/* ── Read Meta (debug) ───────────────────────────────────────── */
function seoroom_read_meta($req) {
    if (!seoroom_auth($req)) return new WP_Error('unauthorized','Bad key',['status'=>401]);
    $id   = intval($req['id']);
    $post = get_post($id);
    if (!$post) return new WP_Error('not_found','Not found',['status'=>404]);
    $raw     = get_post_meta($id, '_elementor_data', true);
    $ps      = get_post_meta($id, '_elementor_page_settings', true);
    $decoded = is_string($raw) ? json_decode($raw, true) : null;
    return [
        'id'=>$id, 'title'=>$post->post_title,
        'edit_mode'      => get_post_meta($id, '_elementor_edit_mode', true),
        'version'        => get_post_meta($id, '_elementor_version', true),
        'template'       => get_post_meta($id, '_wp_page_template', true),
        'template_type'  => get_post_meta($id, '_elementor_template_type', true),
        'ps_type'        => gettype($ps),
        'ps_value'       => $ps,
        'data_length'    => is_string($raw) ? strlen($raw) : 0,
        'data_valid'     => $decoded !== null,
        'data_error'     => json_last_error_msg(),
        'data_sections'  => $decoded ? count($decoded) : 0,
        'data_first_500' => is_string($raw) ? substr($raw, 0, 500) : '',
        'has_bad_settings'=> is_string($raw) && strpos($raw,'"settings":[]') !== false,
    ];
}

/* ── Fix Page ────────────────────────────────────────────────── */
function seoroom_fix_page($req) {
    if (!seoroom_auth($req)) return new WP_Error('unauthorized','Bad key',['status'=>401]);
    $id   = intval($req['id']);
    $post = get_post($id);
    if (!$post) return new WP_Error('not_found','Not found',['status'=>404]);
    $fixes = [];

    // 1. Fix page_settings (must be PHP array, not JSON string)
    $ps = get_post_meta($id, '_elementor_page_settings', true);
    if (is_string($ps)) {
        $d = json_decode($ps, true);
        update_post_meta($id, '_elementor_page_settings', is_array($d)&&!empty($d) ? $d : ['hide_title'=>'yes']);
        $fixes[] = 'page_settings: fixed (was JSON string, now PHP array)';
    } else {
        $fixes[] = 'page_settings: OK ('.gettype($ps).')';
    }

    // 2. Fix empty settings arrays [] → {}
    $raw = get_post_meta($id, '_elementor_data', true);
    if (is_string($raw) && strpos($raw, '"settings":[]') !== false) {
        $count = substr_count($raw, '"settings":[]');
        $raw   = str_replace('"settings":[]', '"settings":{}', $raw);
        update_post_meta($id, '_elementor_data', wp_slash($raw));
        $fixes[] = "elementor_data: fixed {$count} empty settings [] → {}";
    }

    // 3. Validate JSON
    $decoded = is_string($raw) ? json_decode($raw, true) : null;
    if ($decoded === null) {
        $fixes[] = 'WARNING: elementor_data not valid JSON — '.json_last_error_msg();
    } else {
        $fixes[] = 'elementor_data: valid JSON, '.count($decoded).' sections';
    }

    // 4. Ensure required meta fields
    if (!get_post_meta($id, '_elementor_edit_mode', true)) {
        update_post_meta($id, '_elementor_edit_mode', 'builder');
        $fixes[] = 'Added _elementor_edit_mode';
    }
    if (!get_post_meta($id, '_elementor_version', true)) {
        $v = defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : '4.0.1';
        update_post_meta($id, '_elementor_version', $v);
        $fixes[] = 'Added _elementor_version: '.$v;
    }

    return ['id'=>$id, 'fixes'=>$fixes, 'try_edit'=>admin_url("post.php?post={$id}&action=elementor")];
}

/* ── Test Minimal ────────────────────────────────────────────── */
function seoroom_test_minimal($req) {
    if (!seoroom_auth($req)) return new WP_Error('unauthorized','Bad key',['status'=>401]);
    $admins  = get_users(['role'=>'administrator','number'=>1]);
    $page_id = wp_insert_post([
        'post_title'=>'Elementor Test '.date('H:i'),
        'post_status'=>'draft','post_type'=>'page',
        'post_author'=>$admins ? $admins[0]->ID : 1,
    ], true);
    if (is_wp_error($page_id)) return $page_id;

    $id1 = substr(md5(uniqid('s',true)),0,7);
    $id2 = substr(md5(uniqid('c',true)),0,7);
    $id3 = substr(md5(uniqid('w',true)),0,7);
    $tree = '[{"id":"'.$id1.'","elType":"section","settings":{},"elements":[{"id":"'.$id2.'","elType":"column","settings":{"_column_size":100},"elements":[{"id":"'.$id3.'","elType":"widget","widgetType":"heading","settings":{"title":"Elementor Works!","header_size":"h1","align":"center"},"elements":[]}]}]}]';
    $elements = json_decode($tree, true);

    $native = seoroom_native_save($page_id, $elements, ['hide_title'=>'yes']);
    if ($native === true) {
        $method = 'elementor_native';
    } else {
        $method = 'raw_meta';
        update_post_meta($page_id, '_elementor_data',          wp_slash($tree));
        update_post_meta($page_id, '_elementor_edit_mode',     'builder');
        update_post_meta($page_id, '_elementor_page_settings', ['hide_title'=>'yes']);
        update_post_meta($page_id, '_wp_page_template',        'elementor_header_footer');
        update_post_meta($page_id, '_elementor_version',       defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : '4.0.1');
        update_post_meta($page_id, '_elementor_template_type', 'wp-page');
    }

    return ['id'=>$page_id,'method'=>$method,'edit'=>admin_url("post.php?post={$page_id}&action=elementor")];
}

/* ── Extract Widgets — returns full settings for matching widgets ── */
function seoroom_extract_widgets($req) {
    if (!seoroom_auth($req)) return new WP_Error('unauthorized','Bad key',['status'=>401]);
    $id   = intval($req['id']);
    $post = get_post($id);
    if (!$post) return new WP_Error('not_found','Not found',['status'=>404]);
    $raw = get_post_meta($id, '_elementor_data', true);
    if (!is_string($raw)) return new WP_Error('no_data','No elementor data',['status'=>404]);
    $decoded = json_decode($raw, true);
    if (!$decoded) return new WP_Error('bad_json','Invalid JSON',['status'=>500]);

    $type = $req->get_param('type'); // e.g. 'form', 'heading'
    $found = [];
    // Recursive search
    $search = function($elements) use (&$search, &$found, $type) {
        foreach ($elements as $el) {
            if (!empty($el['widgetType']) && (!$type || $el['widgetType'] === $type)) {
                $found[] = $el;
            }
            if (!empty($el['elements'])) $search($el['elements']);
        }
    };
    $search($decoded);
    return ['page_id'=>$id, 'widget_type'=>$type, 'count'=>count($found), 'widgets'=>$found];
}
