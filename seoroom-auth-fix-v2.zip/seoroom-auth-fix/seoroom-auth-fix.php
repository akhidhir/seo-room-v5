<?php
/**
 * Plugin Name: SEO Room Auth Fix
 * Description: Fixes REST API Application Password auth on hosts that strip the Authorization header.
 * Version: 2.0
 * Author: SEO Room
 */

// Try multiple fallback sources for the Authorization header
add_action('init', function() {
    // Source 1: REDIRECT variable (Apache mod_rewrite)
    if (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $_SERVER['HTTP_AUTHORIZATION'] = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    }

    // Source 2: Custom header X-WP-Authorization (bypasses most header stripping)
    if (empty($_SERVER['HTTP_AUTHORIZATION']) && !empty($_SERVER['HTTP_X_WP_AUTHORIZATION'])) {
        $_SERVER['HTTP_AUTHORIZATION'] = $_SERVER['HTTP_X_WP_AUTHORIZATION'];
    }

    // Source 3: CGI workaround
    if (empty($_SERVER['HTTP_AUTHORIZATION'])) {
        $headers = function_exists('getallheaders') ? getallheaders() : [];
        foreach ($headers as $k => $v) {
            if (strtolower($k) === 'authorization') {
                $_SERVER['HTTP_AUTHORIZATION'] = $v;
                break;
            }
            if (strtolower($k) === 'x-wp-authorization') {
                $_SERVER['HTTP_AUTHORIZATION'] = $v;
                break;
            }
        }
    }

    // Parse Basic auth into PHP_AUTH vars
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        $parts = explode(' ', $_SERVER['HTTP_AUTHORIZATION'], 2);
        if (count($parts) === 2 && strtolower($parts[0]) === 'basic') {
            $decoded = base64_decode($parts[1]);
            if ($decoded && strpos($decoded, ':') !== false) {
                list($user, $pass) = explode(':', $decoded, 2);
                $_SERVER['PHP_AUTH_USER'] = $user;
                $_SERVER['PHP_AUTH_PW'] = $pass;
            }
        }
    }
}, 1);
