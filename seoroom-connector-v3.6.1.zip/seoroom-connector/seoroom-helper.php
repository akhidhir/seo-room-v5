<?php
/**
 * Plugin Name: SEO Room Connector
 * Description: Connects WordPress to the SEO Room Dashboard — Yoast meta access, CWV auto-fix, schema injection, and universal cache purge. Required by SEO Room Dashboard.
 * Version: 3.6.1
 * Author: The SEO Room
 */

if (!defined('ABSPATH')) exit;

// ============================================================
// PUSH-MODE CONNECTOR — sends page data TO the dashboard
// Bypasses Cloudflare since requests go outbound from WordPress
// ============================================================

// Settings: Dashboard URL + Push Token (shown on plugin page via Settings link)
add_action('admin_menu', function() {
    add_menu_page('SEO Room Connector', 'SEO Room', 'manage_options', 'seoroom-connector', 'seoroom_settings_page', 'dashicons-chart-area', 80);
});

// Add "Settings" link on the Plugins page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links) {
    $settings_link = '<a href="admin.php?page=seoroom-connector">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
});

add_action('admin_init', function() {
    register_setting('seoroom_settings', 'seoroom_dashboard_url');
    register_setting('seoroom_settings', 'seoroom_push_token');
    register_setting('seoroom_settings', 'seoroom_project_id');
});

// AJAX handler for Test Connection
add_action('wp_ajax_seoroom_test_connection', function() {
    check_ajax_referer('seoroom_test_connection', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $dashboard_url = rtrim(get_option('seoroom_dashboard_url', ''), '/');
    $project_id = get_option('seoroom_project_id', '');
    $token = get_option('seoroom_push_token', '');

    if (!$dashboard_url) wp_send_json_error('Dashboard URL not set');
    if (!$project_id) wp_send_json_error('Project ID not set');
    if (!$token) wp_send_json_error('Push Token not set');

    $response = wp_remote_get("{$dashboard_url}/api/connector-push/{$project_id}/test", [
        'timeout' => 15,
        'headers' => ['Authorization' => 'Bearer ' . $token],
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error('Connection failed: ' . $response->get_error_message());
    }

    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($code === 200 && !empty($body['success'])) {
        $name = $body['project']['name'] ?? '';
        $domain = $body['project']['domain'] ?? '';
        wp_send_json_success("Connected! Project: {$name} ({$domain})");
    } elseif ($code === 401) {
        wp_send_json_error('Invalid Push Token — does not match dashboard');
    } elseif ($code === 404) {
        wp_send_json_error('Project ID ' . $project_id . ' not found on dashboard');
    } else {
        $err = $body['error'] ?? "HTTP {$code}";
        wp_send_json_error('Failed: ' . $err);
    }
});

// AJAX push handler
add_action('wp_ajax_seoroom_ajax_push', function() {
    check_ajax_referer('seoroom_ajax_push', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Insufficient permissions');
    }
    $result = seoroom_push_audit_data();
    if ($result['success']) {
        wp_send_json_success([
            'pages' => $result['pages'],
            'schemas_found' => isset($result['schemas_found']) ? $result['schemas_found'] : 'n/a'
        ]);
    } else {
        wp_send_json_error($result['error']);
    }
});


function seoroom_settings_page() {
    $nonce = wp_create_nonce('seoroom_test_connection');
    ?>
    <div class="wrap">
        <h1>SEO Room Connector</h1>
        <form method="post" action="options.php">
            <?php settings_fields('seoroom_settings'); ?>
            <table class="form-table">
                <tr><th>Dashboard URL</th><td><input type="url" name="seoroom_dashboard_url" value="<?php echo esc_attr(get_option('seoroom_dashboard_url', 'https://seo-room-v5-production.up.railway.app')); ?>" class="regular-text" /></td></tr>
                <tr><th>Project ID</th><td><input type="number" name="seoroom_project_id" value="<?php echo esc_attr(get_option('seoroom_project_id', '')); ?>" class="small-text" /><p class="description">Find this on the dashboard under Settings → Projects (shown as ID badge)</p></td></tr>
                <tr><th>Push Token</th><td><input type="text" name="seoroom_push_token" value="<?php echo esc_attr(get_option('seoroom_push_token', '')); ?>" class="regular-text" /><p class="description">Must match CONNECTOR_PUSH_TOKEN env var on dashboard</p></td></tr>
            </table>
            <?php submit_button(); ?>
        </form>

        <hr>
        <h2>Test Connection</h2>
        <p>Verify the dashboard URL, project ID, and push token are correct:</p>
        <button type="button" id="seoroom-test-btn" class="button button-secondary">
            <span id="seoroom-test-label">Test Connection</span>
        </button>
        <span id="seoroom-test-result" style="margin-left: 12px; font-weight: 600;"></span>

        <script>
        document.getElementById('seoroom-test-btn').addEventListener('click', function() {
            var btn = this;
            var label = document.getElementById('seoroom-test-label');
            var result = document.getElementById('seoroom-test-result');
            btn.disabled = true;
            label.textContent = 'Testing...';
            result.textContent = '';
            result.style.color = '';

            var data = new FormData();
            data.append('action', 'seoroom_test_connection');
            data.append('nonce', '<?php echo $nonce; ?>');

            fetch(ajaxurl, { method: 'POST', body: data })
                .then(function(r) { return r.json(); })
                .then(function(r) {
                    if (r.success) {
                        result.textContent = '✓ ' + r.data;
                        result.style.color = '#00a32a';
                    } else {
                        result.textContent = '✗ ' + (r.data || 'Unknown error');
                        result.style.color = '#d63638';
                    }
                })
                .catch(function(e) {
                    result.textContent = '✗ ' + e.message;
                    result.style.color = '#d63638';
                })
                .finally(function() {
                    btn.disabled = false;
                    label.textContent = 'Test Connection';
                });
        });
        </script>

        <hr>
        <h2>Push Audit Data</h2>
        <?php
        $last_push = get_option('seoroom_last_push', '');
        $next_cron = wp_next_scheduled('seoroom_push_cron');
        ?>
        <table class="form-table">
            <tr><th>Last Push</th><td id="seoroom-last-push"><?php echo $last_push ? '<strong style="color:#00a32a">' . esc_html($last_push) . '</strong>' : '<span style="color:#d63638">Never pushed</span>'; ?></td></tr>
            <tr><th>Auto-Push Schedule</th><td>Every 6 hours<?php if ($next_cron) echo ' — next: ' . esc_html(date('Y-m-d H:i:s', $next_cron)); ?></td></tr>
        </table>
        <p>Push all page audit data (meta, schema, links, images) to the dashboard now:</p>
        <button type="button" id="seoroom-push-btn" class="button button-primary">
            <span id="seoroom-push-label">Push Now</span>
        </button>
        <div id="seoroom-push-result" style="margin-top:12px;padding:10px;display:none;border-radius:4px;font-weight:bold;"></div>
        <?php $push_nonce = wp_create_nonce('seoroom_ajax_push'); ?>
        <script>
        document.getElementById('seoroom-push-btn').addEventListener('click', function() {
            var btn = this;
            var label = document.getElementById('seoroom-push-label');
            var result = document.getElementById('seoroom-push-result');
            btn.disabled = true;
            label.textContent = 'Pushing... (this may take 1-2 minutes)';
            result.style.display = 'none';
            result.textContent = '';

            var data = new FormData();
            data.append('action', 'seoroom_ajax_push');
            data.append('nonce', '<?php echo $push_nonce; ?>');

            fetch(ajaxurl, { method: 'POST', body: data })
                .then(function(r) { return r.json(); })
                .then(function(r) {
                    result.style.display = 'block';
                    if (r.success) {
                        result.style.background = '#d4edda';
                        result.style.color = '#155724';
                        result.style.border = '1px solid #c3e6cb';
                        result.innerHTML = '&#10003; Push successful! ' + r.data.pages + ' pages sent to dashboard.<br><small>Schemas detected: ' + (r.data.schemas_found || 'unknown') + '</small>';
                        var lp = document.getElementById('seoroom-last-push');
                        if (lp) lp.innerHTML = '<strong style="color:#00a32a">Just now (' + new Date().toLocaleString() + ')</strong>';
                    } else {
                        result.style.background = '#f8d7da';
                        result.style.color = '#721c24';
                        result.style.border = '1px solid #f5c6cb';
                        result.innerHTML = '&#10007; Push failed: ' + (r.data || 'Unknown error');
                    }
                })
                .catch(function(e) {
                    result.style.display = 'block';
                    result.style.background = '#f8d7da';
                    result.style.color = '#721c24';
                    result.style.border = '1px solid #f5c6cb';
                    result.innerHTML = '&#10007; Request failed: ' + e.message + '<br><small>This usually means PHP timed out. Check your hosting error logs.</small>';
                })
                .finally(function() {
                    btn.disabled = false;
                    label.textContent = 'Push Now';
                });
        });
        </script>
    </div>
    <?php
}
// Push audit data to dashboard
function seoroom_push_audit_data() {
    // Allow enough time for large sites (143+ pages)
    @set_time_limit(300);
    @ini_set('max_execution_time', '300');

    $dashboard_url = rtrim(get_option('seoroom_dashboard_url', ''), '/');
    $project_id = get_option('seoroom_project_id', '');
    $token = get_option('seoroom_push_token', '');

    if (!$dashboard_url || !$project_id || !$token) {
        return ['success' => false, 'error' => 'Missing dashboard URL, project ID, or push token'];
    }

    // Reuse existing page-audit logic
    $audit_data = seoroom_page_audit();
    if (is_wp_error($audit_data)) {
        return ['success' => false, 'error' => $audit_data->get_error_message()];
    }
    $data = $audit_data->get_data();

    $response = wp_remote_post("{$dashboard_url}/api/connector-push/{$project_id}", [
        'timeout' => 120,
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token,
        ],
        'body' => wp_json_encode($data),
    ]);

    if (is_wp_error($response)) {
        return ['success' => false, 'error' => $response->get_error_message()];
    }

    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($code === 200 && !empty($body['success'])) {
        update_option('seoroom_last_push', current_time('mysql'));
        // Count how many pages have schemas
        $with_schema = 0;
        if (isset($data['pages']) && is_array($data['pages'])) {
            foreach ($data['pages'] as $pg) {
                if (!empty($pg['schemas'])) $with_schema++;
            }
        }
        return ['success' => true, 'pages' => count($data['pages'] ?? []), 'schemas_found' => $with_schema . '/' . count($data['pages'] ?? []) . ' pages with schema'];
    }

    return ['success' => false, 'error' => "HTTP {$code}: " . ($body['error'] ?? 'Unknown error')];
}

// WP-Cron: auto-push every 6 hours
add_action('wp', function() {
    if (!wp_next_scheduled('seoroom_push_cron')) {
        wp_schedule_event(time(), 'sixhours', 'seoroom_push_cron');
    }
});

add_filter('cron_schedules', function($schedules) {
    $schedules['sixhours'] = ['interval' => 21600, 'display' => 'Every 6 Hours'];
    return $schedules;
});

add_action('seoroom_push_cron', 'seoroom_push_audit_data');

add_action('init', function() {
    $post_types = ['page', 'post'];
    $meta_keys = [
        '_yoast_wpseo_title',
        '_yoast_wpseo_metadesc',
        '_yoast_wpseo_focuskw',
        '_yoast_wpseo_linkdex',
        '_yoast_wpseo_content_score',
        '_elementor_data',
        '_elementor_css',
        '_seoroom_schema',
    ];

    foreach ($post_types as $type) {
        foreach ($meta_keys as $key) {
            register_post_meta($type, $key, [
                'show_in_rest'  => true,
                'single'        => true,
                'type'          => 'string',
                'auth_callback' => function() { return current_user_can('edit_posts'); },
            ]);
        }
    }
});

// Also register without underscore prefix (some Yoast versions use both)
add_action('init', function() {
    $post_types = ['page', 'post'];
    $meta_keys = [
        'yoast_wpseo_title',
        'yoast_wpseo_metadesc',
        'yoast_wpseo_focuskw',
    ];

    foreach ($post_types as $type) {
        foreach ($meta_keys as $key) {
            register_post_meta($type, $key, [
                'show_in_rest'  => true,
                'single'        => true,
                'type'          => 'string',
                'auth_callback' => function() { return current_user_can('edit_posts'); },
            ]);
        }
    }
});

// Expose yoast_head_json in REST API responses (already done by Yoast, but ensure it)
add_filter('rest_prepare_page', 'seoroom_add_yoast_to_rest', 10, 3);
add_filter('rest_prepare_post', 'seoroom_add_yoast_to_rest', 10, 3);

function seoroom_add_yoast_to_rest($response, $post, $request) {
    // Add raw Yoast meta for easy access
    $response->data['seoroom_yoast'] = [
        'title'         => get_post_meta($post->ID, '_yoast_wpseo_title', true),
        'description'   => get_post_meta($post->ID, '_yoast_wpseo_metadesc', true),
        'focus_keyword' => get_post_meta($post->ID, '_yoast_wpseo_focuskw', true),
        'seo_score'     => get_post_meta($post->ID, '_yoast_wpseo_linkdex', true),
        'content_score' => get_post_meta($post->ID, '_yoast_wpseo_content_score', true),
    ];
    return $response;
}

// REST endpoint: /wp-json/seoroom/v1/yoast-scores
add_action('rest_api_init', function() {
    register_rest_route('seoroom/v1', '/yoast-scores', [
        'methods'  => 'GET',
        'callback' => 'seoroom_yoast_scores',
        'permission_callback' => function() { return current_user_can('edit_posts'); },
    ]);
});

function seoroom_yoast_scores() {
    $results = [];
    $post_types = ['page', 'post'];
    foreach ($post_types as $type) {
        $posts = get_posts([
            'post_type'      => $type,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
        ]);
        foreach ($posts as $p) {
            $results[] = [
                'id'            => $p->ID,
                'title'         => $p->post_title,
                'type'          => $type,
                'focus_keyword' => get_post_meta($p->ID, '_yoast_wpseo_focuskw', true),
                'seo_score'     => get_post_meta($p->ID, '_yoast_wpseo_linkdex', true),
                'content_score' => get_post_meta($p->ID, '_yoast_wpseo_content_score', true),
                'meta_title'    => get_post_meta($p->ID, '_yoast_wpseo_title', true),
                'meta_desc'     => get_post_meta($p->ID, '_yoast_wpseo_metadesc', true),
            ];
        }
    }
    return rest_ensure_response($results);
}

// ============================================================
// SCHEMA INJECTION (v3.0)
// Reads _seoroom_schema post meta and outputs it as JSON-LD in <head>.
// This is the ONLY reliable way to inject schema on Elementor sites,
// since Elementor bypasses post_content and widget areas.
// ============================================================

add_action('wp_head', function() {
    if (!is_singular()) return; // Only on single pages/posts
    $post_id = get_the_ID();
    if (!$post_id) return;

    $schema = get_post_meta($post_id, '_seoroom_schema', true);
    if (empty($schema)) return;

    // Validate it's proper JSON
    $decoded = json_decode($schema);
    if (json_last_error() !== JSON_ERROR_NONE) return;

    // Re-encode to ensure clean output (no XSS)
    $clean = wp_json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if (!$clean) return;

    echo "\n<!-- SEO Room Schema -->\n";
    echo '<script type="application/ld+json">' . $clean . '</script>' . "\n";
}, 5); // Priority 5 = early in <head>, before CWV fixes

// ============================================================
// UNIVERSAL CACHE PURGE (v3.0)
// Detects whatever caching plugin is active and purges it.
// Plugin-independent — works with any combination of caches.
// ============================================================

add_action('rest_api_init', function() {
    register_rest_route('seoroom/v1', '/purge-cache', [
        'methods'  => 'POST',
        'callback' => 'seoroom_purge_cache',
        'permission_callback' => function() { return current_user_can('manage_options'); },
    ]);
});

function seoroom_purge_cache($request) {
    $url = sanitize_text_field($request->get_param('url') ?: '');
    $purged = [];
    $errors = [];

    // 1. WordPress object cache
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
        $purged[] = 'wp_object_cache';
    }

    // 2. BerqWP
    if (class_exists('BerqWP') || defined('STARTER_STARTER_FILE') || defined('STARTER_STARTER_DIR')) {
        // BerqWP uses its own purge mechanism
        if (function_exists('starter_starter_purge_cache')) {
            starter_starter_purge_cache();
            $purged[] = 'berqwp';
        } elseif (class_exists('starter_starter_cache') && method_exists('starter_starter_cache', 'purge_all')) {
            starter_starter_cache::purge_all();
            $purged[] = 'berqwp';
        } else {
            // Try clearing BerqWP options/transients that trigger rebuild
            delete_transient('berqwp_cache');
            delete_option('starter_starter_cache_version');
            // BerqWP stores cache in uploads/starter-starter/ — flag for rebuild
            $upload_dir = wp_upload_dir();
            $cache_dir = $upload_dir['basedir'] . '/starter-starter/';
            if (is_dir($cache_dir)) {
                seoroom_delete_directory($cache_dir);
                $purged[] = 'berqwp_files';
            }
            // Also try their CDN purge if available
            if (class_exists('starter_starter_cdn') && method_exists('starter_starter_cdn', 'purge')) {
                starter_starter_cdn::purge();
                $purged[] = 'berqwp_cdn';
            }
        }
    }

    // 3. WP Rocket
    if (function_exists('rocket_clean_domain')) {
        if ($url) {
            rocket_clean_files([$url]);
        } else {
            rocket_clean_domain();
        }
        $purged[] = 'wp_rocket';
    }

    // 4. W3 Total Cache
    if (function_exists('w3tc_flush_all')) {
        w3tc_flush_all();
        $purged[] = 'w3_total_cache';
    } elseif (function_exists('w3tc_flush_posts')) {
        w3tc_flush_posts();
        $purged[] = 'w3_total_cache_posts';
    }

    // 5. WP Super Cache
    if (function_exists('wp_cache_clear_cache')) {
        wp_cache_clear_cache();
        $purged[] = 'wp_super_cache';
    }

    // 6. LiteSpeed Cache
    if (class_exists('LiteSpeed_Cache_API') || defined('LSCWP_V')) {
        if (has_action('litespeed_purge_all')) {
            do_action('litespeed_purge_all');
            $purged[] = 'litespeed';
        }
    }

    // 7. Autoptimize
    if (class_exists('autoptimizeCache')) {
        autoptimizeCache::clearall();
        $purged[] = 'autoptimize';
    }

    // 8. WP Fastest Cache
    if (function_exists('wpfc_clear_all_cache')) {
        wpfc_clear_all_cache(true);
        $purged[] = 'wp_fastest_cache';
    } elseif (class_exists('WpFastestCache') && method_exists('WpFastestCache', 'deleteCache')) {
        $wpfc = new WpFastestCache();
        $wpfc->deleteCache(true);
        $purged[] = 'wp_fastest_cache';
    }

    // 9. Breeze (Cloudways)
    if (class_exists('Breeze_PurgeCache')) {
        Breeze_PurgeCache::breeze_cache_flush();
        $purged[] = 'breeze';
    } elseif (has_action('breeze_clear_all_cache')) {
        do_action('breeze_clear_all_cache');
        $purged[] = 'breeze';
    }

    // 10. Hummingbird
    if (has_action('wphb_clear_page_cache')) {
        do_action('wphb_clear_page_cache');
        $purged[] = 'hummingbird';
    }

    // 11. SG Optimizer (SiteGround)
    if (function_exists('sg_cachepress_purge_cache')) {
        sg_cachepress_purge_cache();
        $purged[] = 'sg_optimizer';
    }

    // 12. Kinsta Cache
    if (class_exists('Developer_Kinsta') || defined('KINSTAMU_VERSION')) {
        if (has_action('developer_kinsta_purge_all_caches')) {
            do_action('developer_kinsta_purge_all_caches');
            $purged[] = 'kinsta';
        }
    }

    // 13. Cloudflare (via plugin)
    if (class_exists('CF\WordPress\Hooks') && has_action('cloudflare_purge_everything')) {
        do_action('cloudflare_purge_everything');
        $purged[] = 'cloudflare';
    }

    // 14. Comet Cache / ZenCache
    if (class_exists('comet_cache')) {
        comet_cache::clear();
        $purged[] = 'comet_cache';
    } elseif (class_exists('zencache')) {
        zencache::clear();
        $purged[] = 'zencache';
    }

    // 15. Cache Enabler
    if (has_action('cache_enabler_clear_complete_cache')) {
        do_action('cache_enabler_clear_complete_cache');
        $purged[] = 'cache_enabler';
    } elseif (class_exists('Cache_Enabler')) {
        Cache_Enabler::clear_total_cache();
        $purged[] = 'cache_enabler';
    }

    // 16. Nginx Helper (FastCGI / Redis)
    if (has_action('rt_nginx_helper_purge_all')) {
        do_action('rt_nginx_helper_purge_all');
        $purged[] = 'nginx_helper';
    }

    // 17. Redis Object Cache
    if (function_exists('wp_cache_flush')) {
        // Already called above, but also try Redis-specific
        if (class_exists('Redis') || class_exists('Predis\Client')) {
            $purged[] = 'redis_object_cache';
        }
    }

    // 18. Swift Performance
    if (class_exists('Swift_Performance_Cache')) {
        Swift_Performance_Cache::clear_all_cache();
        $purged[] = 'swift_performance';
    }

    // 19. Powered Cache
    if (function_exists('powered_cache_flush')) {
        powered_cache_flush();
        $purged[] = 'powered_cache';
    }

    // 20. Generic: fire common cache-clearing hooks other plugins may listen to
    if (has_action('cachify_flush_cache')) {
        do_action('cachify_flush_cache');
        $purged[] = 'cachify';
    }

    // Always try the generic WP hooks that many plugins listen on
    do_action('clean_post_cache');
    do_action('switch_theme'); // Many cache plugins purge on theme switch event

    // Report what we found and purged
    $detected = seoroom_detect_cache_plugins();

    return rest_ensure_response([
        'success'  => true,
        'purged'   => $purged,
        'detected' => $detected,
        'message'  => empty($purged)
            ? 'No known cache plugins detected. WP object cache flushed.'
            : 'Purged: ' . implode(', ', $purged),
    ]);
}

// Detect which cache plugins are active (for reporting)
function seoroom_detect_cache_plugins() {
    $detected = [];
    if (class_exists('BerqWP') || defined('STARTER_STARTER_FILE') || defined('STARTER_STARTER_DIR')) $detected[] = 'BerqWP';
    if (function_exists('rocket_clean_domain')) $detected[] = 'WP Rocket';
    if (function_exists('w3tc_flush_all') || function_exists('w3tc_flush_posts')) $detected[] = 'W3 Total Cache';
    if (function_exists('wp_cache_clear_cache') && !function_exists('rocket_clean_domain')) $detected[] = 'WP Super Cache';
    if (class_exists('LiteSpeed_Cache_API') || defined('LSCWP_V')) $detected[] = 'LiteSpeed Cache';
    if (class_exists('autoptimizeCache')) $detected[] = 'Autoptimize';
    if (class_exists('WpFastestCache')) $detected[] = 'WP Fastest Cache';
    if (class_exists('Breeze_PurgeCache')) $detected[] = 'Breeze';
    if (function_exists('sg_cachepress_purge_cache')) $detected[] = 'SG Optimizer';
    if (class_exists('Swift_Performance_Cache')) $detected[] = 'Swift Performance';
    if (class_exists('comet_cache')) $detected[] = 'Comet Cache';
    if (class_exists('Cache_Enabler')) $detected[] = 'Cache Enabler';

    // Check if BerqWP has files in uploads
    $upload_dir = wp_upload_dir();
    if (is_dir($upload_dir['basedir'] . '/starter-starter/')) $detected[] = 'BerqWP (file cache)';
    if (is_dir($upload_dir['basedir'] . '/cache/')) $detected[] = 'File-based cache';

    return array_unique($detected);
}

// Helper: recursively delete a directory
function seoroom_delete_directory($dir) {
    if (!is_dir($dir)) return;
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($files as $file) {
        if ($file->isDir()) {
            @rmdir($file->getRealPath());
        } else {
            @unlink($file->getRealPath());
        }
    }
    @rmdir($dir);
}


// ============================================================
// CWV AUTO-FIX SYSTEM (v2.0)
// Applies performance fixes via WordPress hooks — no theme changes.
// All fixes are stored in wp_options and can be rolled back instantly.
// ============================================================

define('SEOROOM_CWV_OPTION', 'seoroom_cwv_fixes');
define('SEOROOM_CWV_HISTORY', 'seoroom_cwv_history');

// Get active fixes
function seoroom_get_fixes() {
    return get_option(SEOROOM_CWV_OPTION, []);
}

// Save fixes
function seoroom_save_fixes($fixes) {
    update_option(SEOROOM_CWV_OPTION, $fixes);
}

// Add to history for rollback
function seoroom_log_history($action, $fix_data) {
    $history = get_option(SEOROOM_CWV_HISTORY, []);
    $history[] = [
        'action'    => $action,
        'fix'       => $fix_data,
        'timestamp' => current_time('mysql'),
    ];
    // Keep last 200 entries
    if (count($history) > 200) $history = array_slice($history, -200);
    update_option(SEOROOM_CWV_HISTORY, $history);
}

// ---- REST API ENDPOINTS ----

add_action('rest_api_init', function() {
    // Apply a CWV fix
    register_rest_route('seoroom/v1', '/cwv-fix', [
        'methods'  => 'POST',
        'callback' => 'seoroom_apply_cwv_fix',
        'permission_callback' => function() { return current_user_can('edit_posts'); },
    ]);

    // List active fixes
    register_rest_route('seoroom/v1', '/cwv-fixes', [
        'methods'  => 'GET',
        'callback' => 'seoroom_list_cwv_fixes',
        'permission_callback' => function() { return current_user_can('edit_posts'); },
    ]);

    // Rollback a fix
    register_rest_route('seoroom/v1', '/cwv-fix/rollback', [
        'methods'  => 'POST',
        'callback' => 'seoroom_rollback_cwv_fix',
        'permission_callback' => function() { return current_user_can('edit_posts'); },
    ]);

    // Rollback ALL fixes
    register_rest_route('seoroom/v1', '/cwv-fix/rollback-all', [
        'methods'  => 'POST',
        'callback' => 'seoroom_rollback_all_cwv_fixes',
        'permission_callback' => function() { return current_user_can('edit_posts'); },
    ]);

    // Get fix history
    register_rest_route('seoroom/v1', '/cwv-history', [
        'methods'  => 'GET',
        'callback' => function() { return rest_ensure_response(get_option(SEOROOM_CWV_HISTORY, [])); },
        'permission_callback' => function() { return current_user_can('edit_posts'); },
    ]);
});

function seoroom_apply_cwv_fix($request) {
    $fix_type = sanitize_text_field($request->get_param('fix_type'));
    $params   = $request->get_param('params') ?: [];
    $page_url = sanitize_text_field($request->get_param('page_url') ?: '');

    $valid_types = [
        'preconnect',        // Add preconnect hint for a domain
        'preload_resource',  // Preload a critical resource (font, image, CSS)
        'fetchpriority',     // Add fetchpriority="high" to LCP image
        'font_display_swap', // Add font-display:swap to Google Fonts
        'defer_script',      // Defer a specific script
        'delay_script',      // Delay a third-party script until interaction
        'image_dimensions',  // Add width/height to images missing dimensions
        'lazy_load',         // Add loading="lazy" to offscreen images
        'critical_css',      // Inline critical CSS
        'remove_unused_css', // Remove a specific CSS file on specific pages
        'dns_prefetch',      // DNS prefetch for third-party domains
        'custom_snippet',    // Custom PHP/HTML snippet (for edge cases)
    ];

    if (!in_array($fix_type, $valid_types)) {
        return new WP_Error('invalid_type', 'Invalid fix type: ' . $fix_type, ['status' => 400]);
    }

    // Sanitize params
    $clean_params = [];
    foreach ($params as $k => $v) {
        $clean_params[sanitize_text_field($k)] = is_array($v) ? array_map('sanitize_text_field', $v) : sanitize_text_field($v);
    }

    $fix = [
        'id'         => 'cwv_' . wp_generate_uuid4(),
        'fix_type'   => $fix_type,
        'params'     => $clean_params,
        'page_url'   => $page_url,
        'applied_at' => current_time('mysql'),
        'active'     => true,
    ];

    $fixes = seoroom_get_fixes();
    $fixes[] = $fix;
    seoroom_save_fixes($fixes);
    seoroom_log_history('applied', $fix);

    return rest_ensure_response([
        'success' => true,
        'fix_id'  => $fix['id'],
        'message' => "Applied {$fix_type} fix",
    ]);
}

function seoroom_list_cwv_fixes() {
    return rest_ensure_response(seoroom_get_fixes());
}

function seoroom_rollback_cwv_fix($request) {
    $fix_id = sanitize_text_field($request->get_param('fix_id'));
    $fixes = seoroom_get_fixes();
    $removed = null;

    $fixes = array_values(array_filter($fixes, function($f) use ($fix_id, &$removed) {
        if ($f['id'] === $fix_id) { $removed = $f; return false; }
        return true;
    }));

    if (!$removed) {
        return new WP_Error('not_found', 'Fix not found', ['status' => 404]);
    }

    seoroom_save_fixes($fixes);
    seoroom_log_history('rolled_back', $removed);

    return rest_ensure_response(['success' => true, 'message' => "Rolled back fix {$fix_id}"]);
}

function seoroom_rollback_all_cwv_fixes() {
    $fixes = seoroom_get_fixes();
    seoroom_save_fixes([]);
    seoroom_log_history('rolled_back_all', ['count' => count($fixes)]);
    return rest_ensure_response(['success' => true, 'message' => 'All CWV fixes rolled back', 'count' => count($fixes)]);
}

// ---- APPLY FIXES VIA WORDPRESS HOOKS ----

// Preconnect, DNS prefetch, preload, font-display, fetchpriority, critical CSS
add_action('wp_head', function() {
    $fixes = seoroom_get_fixes();
    if (empty($fixes)) return;

    $current_url = home_url($_SERVER['REQUEST_URI']);

    foreach ($fixes as $fix) {
        if (!$fix['active']) continue;
        // Page-specific fixes: only apply on matching page
        if (!empty($fix['page_url']) && strpos($current_url, rtrim($fix['page_url'], '/')) === false) continue;

        $p = $fix['params'];

        switch ($fix['fix_type']) {
            case 'preconnect':
                if (!empty($p['domain'])) {
                    $domain = esc_url($p['domain']);
                    $crossorigin = !empty($p['crossorigin']) ? ' crossorigin' : '';
                    echo "<link rel=\"preconnect\" href=\"{$domain}\"{$crossorigin}>\n";
                }
                break;

            case 'dns_prefetch':
                if (!empty($p['domain'])) {
                    echo '<link rel="dns-prefetch" href="' . esc_url($p['domain']) . "\">\n";
                }
                break;

            case 'preload_resource':
                if (!empty($p['url']) && !empty($p['as'])) {
                    $url = esc_url($p['url']);
                    $as = esc_attr($p['as']);
                    $type = !empty($p['type']) ? ' type="' . esc_attr($p['type']) . '"' : '';
                    $crossorigin = !empty($p['crossorigin']) ? ' crossorigin' : '';
                    echo "<link rel=\"preload\" href=\"{$url}\" as=\"{$as}\"{$type}{$crossorigin}>\n";
                }
                break;

            case 'font_display_swap':
                // Intercept Google Fonts and add &display=swap
                echo "<style>/* seoroom: font-display fix */\n";
                echo "@font-face { font-display: swap !important; }\n";
                echo "</style>\n";
                break;

            case 'critical_css':
                if (!empty($p['css'])) {
                    echo '<style id="seoroom-critical-css">' . wp_strip_all_tags($p['css']) . "</style>\n";
                }
                break;

            case 'custom_snippet':
                if (!empty($p['html'])) {
                    $location = !empty($p['location']) ? $p['location'] : 'head';
                    if ($location === 'head') {
                        // Output in <head> — allow JSON-LD script tags and link tags
                        echo "<!-- seoroom custom snippet -->\n";
                        echo $p['html'] . "\n";
                    }
                }
                break;
        }
    }
}, 1); // Priority 1 = very early in <head>

// Custom snippets in footer
add_action('wp_footer', function() {
    $fixes = seoroom_get_fixes();
    if (empty($fixes)) return;
    $current_url = home_url($_SERVER['REQUEST_URI']);
    foreach ($fixes as $fix) {
        if (!$fix['active'] || $fix['fix_type'] !== 'custom_snippet') continue;
        if (!empty($fix['page_url']) && strpos($current_url, rtrim($fix['page_url'], '/')) === false) continue;
        $p = $fix['params'];
        $location = !empty($p['location']) ? $p['location'] : 'head';
        if ($location === 'footer' && !empty($p['html'])) {
            echo "<!-- seoroom custom snippet -->\n";
            echo $p['html'] . "\n";
        }
    }
}, 99);

// Fetchpriority + image dimensions via content filter
add_filter('the_content', function($content) {
    $fixes = seoroom_get_fixes();
    if (empty($fixes)) return $content;

    $current_url = home_url($_SERVER['REQUEST_URI']);

    foreach ($fixes as $fix) {
        if (!$fix['active']) continue;
        if (!empty($fix['page_url']) && strpos($current_url, rtrim($fix['page_url'], '/')) === false) continue;

        $p = $fix['params'];

        switch ($fix['fix_type']) {
            case 'fetchpriority':
                // Add fetchpriority="high" to the first image or a specific image
                if (!empty($p['image_src'])) {
                    $src = preg_quote($p['image_src'], '/');
                    $content = preg_replace(
                        '/(<img[^>]*src=["\'][^"\']*' . $src . '[^"\']*["\'][^>]*)>/i',
                        '$1 fetchpriority="high">',
                        $content, 1
                    );
                } else {
                    // Add to first image
                    $content = preg_replace(
                        '/(<img\b)(?![^>]*fetchpriority)/i',
                        '$1 fetchpriority="high"',
                        $content, 1
                    );
                }
                break;

            case 'image_dimensions':
                // Add width/height to images that are missing them
                if (!empty($p['image_src']) && !empty($p['width']) && !empty($p['height'])) {
                    $src = preg_quote($p['image_src'], '/');
                    $w = intval($p['width']);
                    $h = intval($p['height']);
                    // Only add if not already present
                    $content = preg_replace(
                        '/(<img[^>]*src=["\'][^"\']*' . $src . '[^"\']*["\'])(?![^>]*\bwidth=)([^>]*>)/i',
                        '$1 width="' . $w . '" height="' . $h . '"$2',
                        $content
                    );
                }
                break;

            case 'lazy_load':
                // Add loading="lazy" to offscreen images (skip first 2 images)
                $img_count = 0;
                $content = preg_replace_callback('/<img\b([^>]*)>/i', function($match) use (&$img_count) {
                    $img_count++;
                    if ($img_count <= 2) return $match[0]; // Don't lazy-load above-fold images
                    if (stripos($match[1], 'loading=') !== false) return $match[0]; // Already has loading attr
                    return '<img' . $match[1] . ' loading="lazy">';
                }, $content);
                break;
        }
    }

    return $content;
}, 20);

// Defer/delay scripts
add_filter('script_loader_tag', function($tag, $handle, $src) {
    $fixes = seoroom_get_fixes();
    if (empty($fixes)) return $tag;

    foreach ($fixes as $fix) {
        if (!$fix['active']) continue;
        $p = $fix['params'];

        if ($fix['fix_type'] === 'defer_script') {
            // Match by handle name or URL pattern
            $match = (!empty($p['handle']) && $handle === $p['handle'])
                  || (!empty($p['url_pattern']) && strpos($src, $p['url_pattern']) !== false);
            if ($match && strpos($tag, 'defer') === false) {
                $tag = str_replace(' src=', ' defer src=', $tag);
            }
        }

        if ($fix['fix_type'] === 'delay_script') {
            // Delay until user interaction (click/scroll/keydown)
            $match = (!empty($p['handle']) && $handle === $p['handle'])
                  || (!empty($p['url_pattern']) && strpos($src, $p['url_pattern']) !== false);
            if ($match) {
                $tag = str_replace(' src=', ' data-seoroom-delay="true" data-src=', $tag);
                $tag = str_replace("type='text/javascript'", "type='text/plain'", $tag);
                $tag = str_replace('type="text/javascript"', 'type="text/plain"', $tag);
            }
        }
    }

    return $tag;
}, 10, 3);

// Remove unused CSS on specific pages
add_action('wp_enqueue_scripts', function() {
    $fixes = seoroom_get_fixes();
    if (empty($fixes)) return;

    $current_url = home_url($_SERVER['REQUEST_URI']);

    foreach ($fixes as $fix) {
        if (!$fix['active'] || $fix['fix_type'] !== 'remove_unused_css') continue;
        if (!empty($fix['page_url']) && strpos($current_url, rtrim($fix['page_url'], '/')) === false) continue;

        $p = $fix['params'];
        if (!empty($p['handle'])) {
            wp_dequeue_style($p['handle']);
            wp_deregister_style($p['handle']);
        }
    }
}, 100);

// Delayed script loader (inject once if any delay_script fixes exist)
add_action('wp_footer', function() {
    $fixes = seoroom_get_fixes();
    $has_delayed = false;
    foreach ($fixes as $fix) {
        if ($fix['active'] && $fix['fix_type'] === 'delay_script') { $has_delayed = true; break; }
    }
    if (!$has_delayed) return;

    echo '<script>
    (function(){
        var loaded = false;
        function loadDelayed() {
            if (loaded) return;
            loaded = true;
            document.querySelectorAll("[data-seoroom-delay]").forEach(function(el) {
                var src = el.getAttribute("data-src");
                if (src) {
                    var s = document.createElement("script");
                    s.src = src;
                    s.defer = true;
                    document.body.appendChild(s);
                }
            });
        }
        ["click","scroll","keydown","mousemove","touchstart"].forEach(function(e) {
            document.addEventListener(e, loadDelayed, {once:true,passive:true});
        });
        setTimeout(loadDelayed, 5000);
    })();
    </script>';
}, 99);

// ============================================================
// PAGE AUDIT ENDPOINT (v3.1)
// Returns full on-page SEO data for all published pages/posts.
// Runs inside WordPress so Cloudflare never blocks it.
// The dashboard calls this instead of crawling externally.
// ============================================================

add_action('rest_api_init', function() {
    register_rest_route('seoroom/v1', '/page-audit', [
        'methods'  => 'GET',
        'callback' => 'seoroom_page_audit',
        'permission_callback' => function() { return current_user_can('edit_posts'); },
    ]);
});

function seoroom_page_audit() {
    @set_time_limit(300);
    @ini_set('max_execution_time', '300');

    // Increase limits for large sites
    @set_time_limit(120);
    @ini_set('memory_limit', '512M');

    $results = [];
    $post_types = ['page', 'post'];
    $home_url = get_home_url();
    $domain = wp_parse_url($home_url, PHP_URL_HOST);

    foreach ($post_types as $type) {
        $posts = get_posts([
            'post_type'      => $type,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
        ]);

        foreach ($posts as $p) {
            $permalink = get_permalink($p->ID);
            $slug = trim(str_replace($home_url, '', $permalink), '/');
            if (empty($slug)) $slug = '/';

            // Render content through WP filters (Elementor, Gutenberg, shortcodes)
            $content = apply_filters('the_content', $p->post_content);

            // Build HTML with head meta for schema/og detection
            $html = seoroom_build_page_html($p, $content);

            // Meta title from Yoast
            $meta_title = '';
            $yoast_title = get_post_meta($p->ID, '_yoast_wpseo_title', true);
            if (!empty($yoast_title) && function_exists('wpseo_replace_vars')) {
                $meta_title = wpseo_replace_vars($yoast_title, $p);
            }
            if (empty($meta_title)) $meta_title = $p->post_title;

            // Meta description from Yoast
            $meta_desc = '';
            $yoast_desc = get_post_meta($p->ID, '_yoast_wpseo_metadesc', true);
            if (!empty($yoast_desc) && function_exists('wpseo_replace_vars')) {
                $meta_desc = wpseo_replace_vars($yoast_desc, $p);
            }

            // H1s
            $h1s = [];
            if (preg_match_all('/<h1[^>]*>([\s\S]*?)<\/h1>/i', $html, $m)) {
                foreach ($m[1] as $h) { $c = trim(strip_tags($h)); if ($c) $h1s[] = $c; }
            }

            // H2s
            $h2s = [];
            if (preg_match_all('/<h2[^>]*>([\s\S]*?)<\/h2>/i', $html, $m)) {
                foreach ($m[1] as $h) { $c = trim(strip_tags($h)); if ($c) $h2s[] = $c; }
            }

            // Images
            $images_total = 0;
            $images_without_alt = 0;
            $missing_alt_details = [];
            if (preg_match_all('/<img[^>]*>/i', $html, $img_matches)) {
                foreach ($img_matches[0] as $img) {
                    $images_total++;
                    $alt = '';
                    if (preg_match('/alt=["\']([^"\']*?)["\']/i', $img, $am)) $alt = $am[1];
                    if (empty(trim($alt))) {
                        $images_without_alt++;
                        $src = '';
                        if (preg_match('/src=["\']([^"\']*?)["\']/i', $img, $sm)) $src = $sm[1];
                        $missing_alt_details[] = $src;
                    }
                }
            }

            // Links
            $internal = 0; $external = 0;
            if (preg_match_all('/<a[^>]*href=["\']([^"\'#]*?)["\']/i', $html, $lm)) {
                foreach ($lm[1] as $href) {
                    if (preg_match('/^(mailto:|tel:|javascript:)/', $href)) continue;
                    if (strpos($href, $domain) !== false || strpos($href, '/') === 0) $internal++;
                    elseif (strpos($href, 'http') === 0) $external++;
                }
            }

            // Schema
            $schemas = [];
            $schema_sources = [];
            if (preg_match_all('/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>([\s\S]*?)<\/script>/i', $html, $sm)) {
                foreach ($sm[1] as $json_str) {
                    $parsed = json_decode($json_str, true);
                    if (!$parsed) continue;
                    $source = (strpos($json_str, 'SEO Room') !== false) ? 'seoroom' : ((strpos($json_str, 'yoast') !== false) ? 'yoast' : 'other');
                    if (isset($parsed['@type'])) {
                        foreach ((array)$parsed['@type'] as $t) { $schemas[] = $t; $schema_sources[] = ['type' => $t, 'source' => $source]; }
                    }
                    if (isset($parsed['@graph']) && is_array($parsed['@graph'])) {
                        foreach ($parsed['@graph'] as $g) {
                            if (isset($g['@type'])) {
                                foreach ((array)$g['@type'] as $t) { $schemas[] = $t; $schema_sources[] = ['type' => $t, 'source' => $source]; }
                            }
                        }
                    }
                }
            }
            // Also check _seoroom_schema meta
            $sr_schema = get_post_meta($p->ID, '_seoroom_schema', true);
            if (!empty($sr_schema)) {
                $parsed = json_decode($sr_schema, true);
                if ($parsed && isset($parsed['@type'])) {
                    foreach ((array)$parsed['@type'] as $t) {
                        if (!in_array($t, $schemas)) { $schemas[] = $t; $schema_sources[] = ['type' => $t, 'source' => 'seoroom']; }
                    }
                }
            }

            // Canonical
            $canonical = null;
            if (preg_match('/<link[^>]*rel=["\']canonical["\'][^>]*href=["\']([^"\']*?)["\']/i', $html, $cm)) $canonical = $cm[1];

            // Robots meta
            $robots_meta = '';
            if (preg_match('/<meta[^>]*name=["\']robots["\'][^>]*content=["\']([^"\']*?)["\']/i', $html, $rm)) $robots_meta = $rm[1];

            // Open Graph
            $has_og = (bool)preg_match('/<meta[^>]*property=["\']og:/i', $html);

            // Word count
            $text = strip_tags(preg_replace('/<script[\s\S]*?<\/script>/i', '', preg_replace('/<style[\s\S]*?<\/style>/i', '', $html)));
            $word_count = str_word_count(preg_replace('/\s+/', ' ', trim($text)));

            // FAQ detection
            $question_headings = preg_match_all('/<h[2-4][^>]*>[^<]*\?[^<]*<\/h[2-4]>/i', $html);
            $has_faq_section = (bool)(
                preg_match('/<h[1-4][^>]*>[^<]*(faq|frequently asked|common questions)[^<]*<\/h[1-4]>/i', $html) ||
                preg_match('/<(section|div)[^>]*(id|class)="[^"]*faq[^"]*"[^>]*>/i', $html)
            );

            $results[] = [
                'url'              => $permalink,
                'path'             => '/' . ltrim($slug, '/'),
                'title'            => $p->post_title,
                'post_type'        => $type,
                'post_id'          => $p->ID,
                'statusCode'       => 200,
                'elapsed'          => 0,
                'finalUrl'         => $permalink,
                'wasRedirected'    => false,
                'metaTitle'        => $meta_title,
                'metaTitleLength'  => mb_strlen($meta_title),
                'metaDesc'         => $meta_desc,
                'metaDescLength'   => mb_strlen($meta_desc),
                'h1s'              => $h1s,
                'h2s'              => $h2s,
                'wordCount'        => $word_count,
                'images'           => $images_total,
                'imagesWithoutAlt' => $images_without_alt,
                'imagesMissingAlt' => $missing_alt_details,
                'internalLinks'    => $internal,
                'externalLinks'    => $external,
                'schemas'          => array_values(array_unique($schemas)),
                'schemaSources'    => $schema_sources,
                'canonical'        => $canonical,
                'hasViewport'      => true,
                'robotsMeta'       => $robots_meta,
                'isNoindex'        => (strpos($robots_meta, 'noindex') !== false),
                'isHttps'          => (strpos($permalink, 'https://') === 0),
                'hasHreflang'      => false,
                'hasOG'            => $has_og,
                'questionHeadings' => $question_headings ?: 0,
                'hasFAQSection'    => $has_faq_section,
                'focusKeyword'     => get_post_meta($p->ID, '_yoast_wpseo_focuskw', true),
                'seoScore'         => get_post_meta($p->ID, '_yoast_wpseo_linkdex', true),
                'contentScore'     => get_post_meta($p->ID, '_yoast_wpseo_content_score', true),
            ];
        }
    }

    return rest_ensure_response([
        'success'  => true,
        'total'    => count($results),
        'home_url' => $home_url,
        'pages'    => $results,
    ]);
}

function seoroom_build_page_html($post, $content) {
    $meta_title = get_post_meta($post->ID, '_yoast_wpseo_title', true);
    if (!empty($meta_title) && function_exists('wpseo_replace_vars')) {
        $meta_title = wpseo_replace_vars($meta_title, $post);
    }
    if (empty($meta_title)) $meta_title = $post->post_title;

    $meta_desc = get_post_meta($post->ID, '_yoast_wpseo_metadesc', true);
    if (!empty($meta_desc) && function_exists('wpseo_replace_vars')) {
        $meta_desc = wpseo_replace_vars($meta_desc, $post);
    }

    $html = '<html><head>';
    $html .= '<title>' . esc_html($meta_title) . '</title>';
    if (!empty($meta_desc)) $html .= '<meta name="description" content="' . esc_attr($meta_desc) . '">';
    $html .= '<link rel="canonical" href="' . esc_url(get_permalink($post->ID)) . '">';
    $html .= '<meta name="viewport" content="width=device-width, initial-scale=1">';

    // SEO Room schema (from _seoroom_schema meta)
    $schema = get_post_meta($post->ID, '_seoroom_schema', true);
    if (!empty($schema)) {
        $decoded = json_decode($schema);
        if ($decoded) {
            $html .= '<script type="application/ld+json">' . wp_json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
        }
    }

    // Yoast schema — Method 1: Meta_Surface (Yoast 20+, works in REST/cron)
    $yoast_captured = false;
    if (function_exists('YoastSEO') && class_exists('\Yoast\WP\SEO\Surfaces\Meta_Surface')) {
        try {
            $surface = YoastSEO()->classes->get('Yoast\WP\SEO\Surfaces\Meta_Surface');
            if ($surface) {
                $meta = $surface->for_post($post->ID);
                if ($meta && isset($meta->schema)) {
                    // schema property contains the full JSON-LD object
                    $schema_output = $meta->schema;
                    if (is_object($schema_output) || is_array($schema_output)) {
                        $html .= '<script type="application/ld+json">' . wp_json_encode($schema_output, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
                        $yoast_captured = true;
                    } elseif (is_string($schema_output) && !empty($schema_output)) {
                        $html .= '<script type="application/ld+json">' . $schema_output . '</script>';
                        $yoast_captured = true;
                    }
                }
                // Also try ->head for full output including OG tags
                if (!$yoast_captured && $meta) {
                    $head_val = null;
                    if (isset($meta->head) && is_string($meta->head) && !empty($meta->head)) {
                        $head_val = $meta->head;
                    } elseif (method_exists($meta, 'get_head')) {
                        $h = $meta->get_head();
                        $head_val = is_string($h) ? $h : (is_object($h) && method_exists($h, '__toString') ? (string)$h : null);
                    }
                    if (!empty($head_val)) {
                        $html .= $head_val;
                        $yoast_captured = true;
                    }
                }
            }
        } catch (\Throwable $e) {
            // Log but don't crash
            error_log('[SEO Room Connector] Meta_Surface error for post ' . $post->ID . ': ' . $e->getMessage());
        }
    }

    // Method 2: Yoast REST API field (yoast_head) — read from post meta cache
    if (!$yoast_captured) {
        // Yoast stores rendered head in transient or generates on REST request
        // Try the wpseo_head action with proper setup
        if (function_exists('wpseo_head')) {
            try {
                $old_post = $GLOBALS['post'] ?? null;
                $old_query = $GLOBALS['wp_query'] ?? null;
                $GLOBALS['post'] = $post;
                setup_postdata($post);

                // Set up a fake query so Yoast thinks we're on a singular page
                $fake_query = new \WP_Query(['p' => $post->ID, 'post_type' => $post->post_type]);
                $GLOBALS['wp_query'] = $fake_query;

                ob_start();
                do_action('wpseo_head');
                $yoast_head = ob_get_clean();

                $GLOBALS['wp_query'] = $old_query;
                wp_reset_postdata();
                if ($old_post) $GLOBALS['post'] = $old_post;

                if (!empty(trim($yoast_head))) {
                    $html .= $yoast_head;
                    $yoast_captured = true;
                }
            } catch (\Throwable $e) {
                error_log('[SEO Room Connector] wpseo_head error for post ' . $post->ID . ': ' . $e->getMessage());
            }
        }
    }

    // Method 3: Read Yoast's schema directly from its internal format
    if (!$yoast_captured) {
        // At minimum, detect that Yoast IS active and generate a basic WebPage schema
        if (class_exists('WPSEO_Options') || defined('WPSEO_VERSION')) {
            $page_type = get_post_meta($post->ID, '_yoast_wpseo_schema_page_type', true) ?: 'WebPage';
            $basic_schema = [
                '@context' => 'https://schema.org',
                '@type' => $page_type,
                'name' => $meta_title,
                'url' => get_permalink($post->ID),
            ];
            if (!empty($meta_desc)) $basic_schema['description'] = $meta_desc;
            $html .= '<script type="application/ld+json">' . wp_json_encode($basic_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
        }
    }

    // OG tags from Yoast meta
    $og_title = get_post_meta($post->ID, '_yoast_wpseo_opengraph-title', true);
    $og_desc = get_post_meta($post->ID, '_yoast_wpseo_opengraph-description', true);
    $og_img = get_post_meta($post->ID, '_yoast_wpseo_opengraph-image', true);
    if (!empty($og_title) || !empty($og_desc) || !empty($og_img) || !$yoast_captured) {
        // If Yoast head wasn't captured, add OG manually
        $og_t = !empty($og_title) ? $og_title : $meta_title;
        $og_d = !empty($og_desc) ? $og_desc : $meta_desc;
        $html .= '<meta property="og:title" content="' . esc_attr($og_t) . '">';
        if (!empty($og_d)) $html .= '<meta property="og:description" content="' . esc_attr($og_d) . '">';
        if (!empty($og_img)) $html .= '<meta property="og:image" content="' . esc_url($og_img) . '">';
        $html .= '<meta property="og:url" content="' . esc_url(get_permalink($post->ID)) . '">';
    }

    $html .= '</head><body>';
    $html .= $content;
    $html .= '</body></html>';

    return $html;
}
