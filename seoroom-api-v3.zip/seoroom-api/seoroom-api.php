<?php
/**
 * Plugin Name: SEO Room API
 * Description: Custom REST endpoints for SEO Room Dashboard.
 * Version: 3.0
 * Author: SEO Room
 */
defined('ABSPATH') || exit;
define('SEOROOM_API_KEY', 'sr_2026_kX9mNpQ4wR7vBz');

add_action('rest_api_init', function() {
    register_rest_route('seoroom/v1', '/test', ['methods'=>'GET','callback'=>function($r){
        if($r->get_param('api_key')!==SEOROOM_API_KEY)return new WP_Error('unauthorized','Bad key',['status'=>401]);
        return ['ok'=>true,'elementor'=>defined('ELEMENTOR_VERSION')?ELEMENTOR_VERSION:'no'];
    },'permission_callback'=>'__return_true']);

    register_rest_route('seoroom/v1', '/create-page', ['methods'=>'POST','callback'=>'seoroom_create_page','permission_callback'=>'__return_true']);
    register_rest_route('seoroom/v1', '/delete-pages', ['methods'=>'POST','callback'=>'seoroom_delete_pages','permission_callback'=>'__return_true']);
    register_rest_route('seoroom/v1', '/list-pages', ['methods'=>'GET','callback'=>'seoroom_list_pages','permission_callback'=>'__return_true']);
});

function seoroom_create_page($req) {
    if($req->get_param('api_key')!==SEOROOM_API_KEY)return new WP_Error('unauthorized','Bad key',['status'=>401]);
    $title=sanitize_text_field($req->get_param('title')?:'New Page');
    $slug=sanitize_title($req->get_param('slug')?:$title);
    $tree=$req->get_param('tree');
    if(empty($tree))return new WP_Error('missing_tree','tree required',['status'=>400]);
    $admins=get_users(['role'=>'administrator','number'=>1]);
    $page_id=wp_insert_post(['post_title'=>$title,'post_name'=>$slug,'post_status'=>'draft','post_type'=>'page','post_author'=>$admins?$admins[0]->ID:1],true);
    if(is_wp_error($page_id))return $page_id;
    $tree_json=is_string($tree)?$tree:wp_json_encode($tree);
    update_post_meta($page_id,'_elementor_data',wp_slash($tree_json));
    update_post_meta($page_id,'_elementor_edit_mode','builder');
    update_post_meta($page_id,'_elementor_page_settings',wp_json_encode(['hide_title'=>'yes']));
    update_post_meta($page_id,'_wp_page_template','elementor_header_footer');
    update_post_meta($page_id,'_elementor_version',defined('ELEMENTOR_VERSION')?ELEMENTOR_VERSION:'3.0.0');
    update_post_meta($page_id,'_elementor_template_type','wp-page');
    return ['id'=>$page_id,'slug'=>$slug,'link'=>get_permalink($page_id),'edit'=>admin_url("post.php?post={$page_id}&action=elementor")];
}

function seoroom_delete_pages($req) {
    if($req->get_param('api_key')!==SEOROOM_API_KEY)return new WP_Error('unauthorized','Bad key',['status'=>401]);
    $ids=$req->get_param('ids');
    if(empty($ids)||!is_array($ids))return new WP_Error('missing_ids','ids array required',['status'=>400]);
    $deleted=[];
    foreach($ids as $id){
        $id=intval($id);
        if($id>0){
            wp_trash_post($id);
            $deleted[]=$id;
        }
    }
    return ['trashed'=>$deleted,'count'=>count($deleted)];
}

function seoroom_list_pages($req) {
    if($req->get_param('api_key')!==SEOROOM_API_KEY)return new WP_Error('unauthorized','Bad key',['status'=>401]);
    $pages=get_posts(['post_type'=>'page','post_status'=>['draft','publish'],'numberposts'=>100,'orderby'=>'date','order'=>'DESC']);
    $result=[];
    foreach($pages as $p){
        $result[]=['id'=>$p->ID,'title'=>$p->post_title,'status'=>$p->post_status,'slug'=>$p->post_name,'date'=>$p->post_date];
    }
    return $result;
}
