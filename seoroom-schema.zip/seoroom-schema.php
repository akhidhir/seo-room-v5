<?php
/**
 * Plugin Name: SEO Room
 * Description: Schema markup output + safe speed optimizations, managed by the SEO Room dashboard.
 * Version: 1.1.0
 * Author: The SEO Room
 * License: GPL-2.0+
 */
if (!defined('ABSPATH')) exit;

add_action('init', function() {
    register_post_meta('', '_seoroom_schema', [
        'show_in_rest' => true, 'single' => true, 'type' => 'string',
        'auth_callback' => function() { return current_user_can('edit_posts'); }
    ]);
    register_post_meta('', '_seoroom_speed', [
        'show_in_rest' => true, 'single' => true, 'type' => 'string',
        'auth_callback' => function() { return current_user_can('edit_posts'); }
    ]);
});

// Schema output
add_action('wp_head', function() {
    if (!is_singular()) return;
    $schema = get_post_meta(get_the_ID(), '_seoroom_schema', true);
    if ($schema) echo "\n<!-- SEO Room Schema -->\n<script type=\"application/ld+json\">\n" . $schema . "\n</script>\n<!-- /SEO Room Schema -->\n";
}, 1);

// Speed hints output
add_action('wp_head', function() {
    if (!is_singular()) return;
    $raw = get_post_meta(get_the_ID(), '_seoroom_speed', true);
    if (!$raw) return;
    $speed = json_decode($raw, true);
    if (!$speed) return;
    echo "\n<!-- SEO Room Speed -->\n";
    if (!empty($speed['preconnects']) && is_array($speed['preconnects'])) {
        foreach ($speed['preconnects'] as $url) { echo "<link rel=\"preconnect\" href=\"" . esc_url($url) . "\" crossorigin />\n"; }
    }
    if (!empty($speed['dns_prefetch']) && is_array($speed['dns_prefetch'])) {
        foreach ($speed['dns_prefetch'] as $url) { echo "<link rel=\"dns-prefetch\" href=\"" . esc_url($url) . "\" />\n"; }
    }
    if (!empty($speed['preload_image'])) { echo "<link rel=\"preload\" as=\"image\" href=\"" . esc_url($speed['preload_image']) . "\" />\n"; }
    if (!empty($speed['font_display_swap'])) { echo "<style>@font-face{font-display:swap!important}</style>\n"; }
    echo "<!-- /SEO Room Speed -->\n";
}, 1);

// Lazy load iframes
add_filter('the_content', function($content) {
    if (is_admin() || !is_singular()) return $content;
    return preg_replace('/<iframe(?![^>]*loading=)([^>]*)>/i', '<iframe loading="lazy"$1>', $content);
});
